<?php
namespace Elementor;
class FeaturedSolutionsWidget extends Widget_Base{
    public function get_name(){
        return "featured-solutions-widget";
    }
    public function get_title(){
        return "Featured Solutions";
    }
    public function get_icon(){
        return "eicon-favorite";
    }
    public function get_categories(){
        return ['albioncategory'];
    }

    protected function _register_controls(){
        // Tab content controls
        $this-> start_controls_section(
            'section_content',
            [
                'label'=>esc_html__('Content', 'albion-toolkit'),
                'tab'=> Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'section_title',
            [
                'label'=>esc_html__('Title', 'albion-toolkit'),
                'type'=>Controls_Manager:: WYSIWYG,
                'description' => esc_html__('This text editor for h1 to h6 html tag','albion-toolkit'),
            ]
        );

        $this->add_control(
            'section_desc',
            [
                'label'=>esc_html__('Description', 'albion-toolkit'),
                'type'=>Controls_Manager:: WYSIWYG,
                'description' => esc_html__('This text editor for p, ul - ol list tag','albion-toolkit'),
            ]
        );

        $this->add_control(
            'count',
            [
                'label' => esc_html__( 'Post Per Page', 'albion-toolkit' ),
                'default' => esc_html__( '3', 'albion-toolkit' ),
                'type' => Controls_Manager::TEXT,
                'description' => esc_html__('if you went to see all post type -1','albion-toolkit')
            ]
        );

        $this->add_control(
            'cat_name',
            [
                'label' => esc_html__( 'Select Category', 'albion-toolkit' ),
                'type' => Controls_Manager::SELECT,
                'options' => albion_toolkit_get_service_cat_list(),
            ]
        );
    
        $this->add_control(
            'order',
            [
                'label' => esc_html__( 'Select Order', 'albion-toolkit' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'DESC'  => esc_html__( 'DESC', 'albion-toolkit' ),
                    'ASC'  => esc_html__( 'ASC', 'albion-toolkit' ),
                ],
                'default' => 'DESC',
            ]
        );

        $this->add_control(
            'learn_more_text',
            [
                'label' => esc_html__( 'Learn More Text', 'albion-toolkit' ),
                'type' => Controls_Manager::TEXT,
                'default' => 'Read More',
            ]
        );

        $this->add_control(
			'service_shape',
			[
				'label' => esc_html__( 'Show Shapes', 'albion-toolkit' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'albion-toolkit' ),
				'label_off' => esc_html__( 'Hide', 'albion-toolkit' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
        );

        $this-> end_controls_section();

        // End Tab content controls

        // Start Style content controls
        $this-> start_controls_section(
            'content_style',
            [
                'label'=>esc_html__('Content', 'albion-toolkit'),
                'tab'=> Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
			'title_style',
			[
				'label' => esc_html__( 'Title', 'albion-toolkit' ),
                'type' => Controls_Manager::HEADING,
			]
        );

        $this->add_control(
            'title_color',
            [
                'label' => esc_html__( 'Color', 'albion-toolkit' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .section-title h2' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_responsive_control(
			'title_font_size',
			[
				'label' => esc_html__( 'Font Size', 'albion-toolkit' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 60,
					],
                ],
                'devices' => [ 'desktop', 'tablet', 'mobile' ],
                'unit' => 'px',
				'selectors' => [
					'{{WRAPPER}} .section-title h2' => 'font-size: {{SIZE}}{{UNIT}}',
                ],
			]
        );

        $this->add_control(
			'desc_style',
			[
				'label' => esc_html__( 'Description', 'albion-toolkit' ),
                'type' => Controls_Manager::HEADING,
			]
        );

        $this->add_control(
            'desc_color',
            [
                'label' => esc_html__( 'Color', 'albion-toolkit' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .section-title p' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_responsive_control(
			'desc_size',
			[
				'label' => esc_html__( 'Font Size', 'albion-toolkit' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 30,
					],
                ],
                'devices' => [ 'desktop', 'tablet', 'mobile' ],
                'unit' => 'px',
				'selectors' => [
					'{{WRAPPER}} .section-title p' => 'font-size: {{SIZE}}{{UNIT}}',
                ],
			]
        );

        $this->add_control(
			'card_style',
			[
				'label' => esc_html__( 'Featured Card', 'albion-toolkit' ),
				'type' => Controls_Manager::HEADING,
			]
        );

        $this->add_control(
            'service_title',
            [
                'label' => esc_html__( 'Title Color', 'albion-toolkit' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .single-featured-solutions-box h3 a' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_responsive_control(
			'service_title_size',
			[
				'label' => esc_html__( 'Font Size', 'albion-toolkit' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 30,
					],
                ],
                'devices' => [ 'desktop', 'tablet', 'mobile' ],
                'unit' => 'px',
				'selectors' => [
					'{{WRAPPER}} .single-featured-solutions-box h3' => 'font-size: {{SIZE}}{{UNIT}}',
                ],
			]
        );

        $this->add_control(
            'service_para',
            [
                'label' => esc_html__( 'Content Color', 'albion-toolkit' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .single-featured-solutions-box p' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_responsive_control(
			'service_para_size',
			[
				'label' => esc_html__( 'Content Font Size', 'albion-toolkit' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 20,
					],
                ],
                'devices' => [ 'desktop', 'tablet', 'mobile' ],
                'unit' => 'px',
				'selectors' => [
					'{{WRAPPER}} .single-featured-solutions-box p' => 'font-size: {{SIZE}}{{UNIT}}',
                ],
			]
        );

        $this-> end_controls_section();
        // End Style content controls

    }
    // Register control section end here

    protected function render()
    {
        // Retrieve all controls value
        $settings = $this->get_settings_for_display();

        if( $settings['cat_name'] != '' ):
            $args = array(
                'post_type' => 'service',
                'posts_per_page' => 3,
                'order' => $settings['order'],
                'tax_query' => array(
                    array(
                        'taxonomy' => 'service_cat',
                        'field' => 'slug',
                        'terms' => $settings['cat_name'],
                        'hide_empty' => false
                    )
                )
            );
        else:
            $args = array(
                'post_type' => 'service',
                'posts_per_page' => $settings['count'],
                'order' => $settings['order'],
            );
        endif;

        $services_array = new \WP_Query( $args ); ?>

        <!-- Start Featured Solutions Area -->
        <div class="featured-solutions-area ptb-110">
            <div class="container">
                <div class="section-title">
                    <div class="section-title">
                        <?php echo wp_kses_post($settings['section_title']); ?>
                        <?php echo wp_kses_post($settings['section_desc']); ?>
                    </div>
                </div>

                <div class="row">

                    <?php
                    $loop = 1;
                    while( $services_array->have_posts()): $services_array->the_post();
                        if( $loop == 3 ){ 
                            $colcls = "col-lg-4 col-md-6 col-sm-6 offset-lg-0 offset-md-3 offset-sm-3";
                        } else {
                            $colcls = "col-lg-4 col-md-6 col-sm-6";
                        } ?>
                        <div class="<?php echo esc_attr( $colcls ); ?>">
                            <div class="single-featured-solutions-box">
                                <div class="icon">
                                    <img src="<?php echo esc_url(get_the_post_thumbnail_url(get_the_ID(), 'full')); ?>" alt="<?php echo esc_attr__('icon image','albion-toolkit'); ?>">
                                </div>
                                <h3><a href="<?php echo esc_url(get_the_permalink(), 'albion-toolkit'); ?>"><?php the_title(); ?></a></h3>
                                <p><?php the_excerpt(); ?></p>

                                <a href="<?php echo esc_url(get_the_permalink( get_the_ID() )); ?>" class="learn-more-btn"> <?php echo esc_html( $settings['learn_more_text'] ); ?></a>
                            </div>
                        </div>
                    <?php
                    $loop++;
                    endwhile;
                    wp_reset_query(); ?>
                </div>
            </div>

            <?php if ( 'yes' === $settings['service_shape'] ) { ?>
                <div class="shape-img2">
                    <img src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/shape/2.svg' ); ?>" alt="<?php echo esc_attr__( 'About Shape', 'albion-toolkit' ); ?>">
                </div>
                <div class="shape-img3">
                    <img src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/shape/3.png' ); ?>" alt="<?php echo esc_attr__( 'About Shape', 'albion-toolkit' ); ?>">
                </div>
                <div class="shape-img5">
                    <img src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/shape/5.svg' ); ?>" alt="<?php echo esc_attr__( 'About Shape', 'albion-toolkit' ); ?>">
                </div>
                <div class="dot-shape1">
                    <img src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/shape/dot1.png' ); ?>" alt="<?php echo esc_attr__( 'About Shape', 'albion-toolkit' ); ?>">
                </div>
                <div class="dot-shape2">
                    <img src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/shape/dot3.png' ); ?>" alt="<?php echo esc_attr__( 'About Shape', 'albion-toolkit' ); ?>">
                </div>
            <?php } ?>
        </div>
        <?php
    }

    protected function _content_template() {}
}
Plugin::instance()->widgets_manager->register_widget_type( new FeaturedSolutionsWidget );