<?php
namespace Elementor;
class NewsletterWidget extends Widget_Base{
    public function get_name(){
        return "newsletter-widget";
    }
    public function get_title(){
        return "Free Trial Widget";
    }
    public function get_icon(){
        return "eicon-form-horizontal";
    }
    public function get_categories(){
        return ['albioncategory'];
    }

    protected function _register_controls(){
    
        $this-> start_controls_section(
            'albion_testimonial',
            [
                'label'=>esc_html__('Free Trial', 'albion-toolkit'),
                'tab'=> Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'choose_type',
            [
                'label' => esc_html__( 'Choose Style', 'albion-toolkit' ),
                'type' => Controls_Manager::SELECT,
                'label_block' => true,
                'options' => [
                    '1'  => esc_html__( 'Style 1', 'albion-toolkit' ),
                    '2' => esc_html__( 'Style 2', 'albion-toolkit' ),
                ],
                'default' => '1',
            ]
        );

        $this->add_control(
            'form_title', [
                'label' => esc_html__( 'Form Title', 'albion-toolkit' ),
                'type'=>Controls_Manager:: WYSIWYG,
                'description' => esc_html__('This text editor for h1 to h6 html tag','albion-toolkit'),
            ]
        );
        $this->add_control(
            'form_placeholder', [
                'label' => esc_html__( 'Form Placeholder Text', 'albion-toolkit' ),
                'type'=>Controls_Manager:: TEXT,
            ]
        );
        $this->add_control(
            'form_btn', [
                'label' => esc_html__( 'Form Button Text', 'albion-toolkit' ),
                'type'=>Controls_Manager:: TEXT,
            ]
        );

        $this->add_control(
            'form_desc', [
                'label' => esc_html__( 'Description', 'albion-toolkit' ),
                'type'=>Controls_Manager:: WYSIWYG,
                'description' => esc_html__('This text editor for p, ul - ol list tag','albion-toolkit'),
            ]
        );

        $this->add_control(
            'image',
            [
                'label' => esc_html__( 'Image', 'albion-toolkit' ),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Image_Size::get_type(),
            [
                'default' =>'full',
                'name' => 'imagesz',
            ]
        );

        $this->add_control(
            'bg_image',
            [
                'label' => esc_html__('Image', 'albion-toolkit' ),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'condition' => [
                    'choose_type' => '1',
                ]
            ]
        );
        $this->add_control(
			'section_color_img',
			[
				'label' => esc_html__( 'Color Image Show?', 'albion-toolkit' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'albion-toolkit' ),
				'label_off' => esc_html__( 'Hide', 'albion-toolkit' ),
				'return_value' => 'yes',
                'default' => 'yes',
                'condition' => [
                    'choose_type' => '1',
                ]
			]
        );
        $this->add_control(
			'section_shape',
			[
				'label' => esc_html__( 'Show Shapes', 'albion-toolkit' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'albion-toolkit' ),
				'label_off' => esc_html__( 'Hide', 'albion-toolkit' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
        );
        $this-> end_controls_section();

        // Start Style Controls
        $this-> start_controls_section(
            'newsletter_style',
            [
                'label'=>esc_html__('free Trial Style', 'albion-toolkit'),
                'tab'=> Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'title_style',
            [
                'label' => esc_html__( 'Form Title', 'albion-toolkit' ),
                'type' => Controls_Manager::HEADING,
            ]
        );

        $this->add_control(
            'title_color',
            [
                'label' => esc_html__( 'Color', 'albion-toolkit' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .free-trial-content h2, .free-trial-text h2' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_responsive_control(
            'font_sz',
            [
                'label' => esc_html__( 'Font Size', 'albion-toolkit' ),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 50,
                    ],
                ],
                'devices' => [ 'desktop', 'tablet', 'mobile' ],
                'unit' => 'px',
                'selectors' => [
                    '{{WRAPPER}} .free-trial-content h2, .free-trial-text h2' => 'font-size: {{SIZE}}{{UNIT}}',
                ],
            ]
        );

        $this->add_control(
            'placeholder_style',
            [
                'label' => esc_html__( 'Placeholder', 'albion-toolkit' ),
                'type' => Controls_Manager::HEADING,
            ]
        );
        $this->add_control(
            'placeholder_color',
            [
                'label' => esc_html__( 'Color', 'albion-toolkit' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .free-trial-content form .input-newsletter::placeholder, .free-trial-text form .input-newsletter::placeholder' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'inputfield_style',
            [
                'label' => esc_html__( 'Input Field', 'albion-toolkit' ),
                'type' => Controls_Manager::HEADING,
            ]
        );
        $this->add_control(
            'input_color',
            [
                'label' => esc_html__( 'Color', 'albion-toolkit' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .free-trial-content form .input-newsletter, .free-trial-text form .input-newsletter' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_control(
            'input_bgcolor',
            [
                'label' => esc_html__( 'Background Color', 'albion-toolkit' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .free-trial-content form .input-newsletter, .free-trial-text form .input-newsletter' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this-> add_control(
            'desc_style',
            [
                'label'=>esc_html__('Description', 'albion-toolkit'),
                'type'=> Controls_Manager::HEADING,
            ]
        );
        $this->add_control(
            'desc_color',
            [
                'label' => esc_html__( 'Color', 'albion-toolkit' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .free-trial-content p, .free-trial-text p' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_responsive_control(
            'descfont_sz',
            [
                'label' => esc_html__( 'Font Size', 'albion-toolkit' ),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 20,
                    ],
                ],
                'devices' => [ 'desktop', 'tablet', 'mobile' ],
                'unit' => 'px',
                'selectors' => [
                    '{{WRAPPER}} .free-trial-content p, .free-trial-text p' => 'font-size: {{SIZE}}{{UNIT}}',
                ],
            ]
        );
        
        $this-> add_control(
            'btn_style',
            [
                'label'=>esc_html__('Button', 'albion-toolkit'),
                'type'=> Controls_Manager::HEADING,
            ]
        );

        $this->add_control(
            'btn_color',
            [
                'label' => esc_html__( 'Text Color', 'albion-toolkit' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .free-trial-content form button, .free-trial-text form button' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_control(
            'btn_bgcolor',
            [
                'label' => esc_html__( 'Background Color', 'albion-toolkit' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .free-trial-content form button, .free-trial-text form button' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'btn_hover_color',
            [
                'label' => esc_html__( 'Text Hover Color', 'albion-toolkit' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .free-trial-content form button:hover, .free-trial-text form button:hover' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_control(
            'btn_hover_bg',
            [
                'label' => esc_html__( 'Hover Background ', 'albion-toolkit' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .free-trial-content form button:hover, .free-trial-text form button:hover' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this-> end_controls_section();
    }

    protected function render() 
    {
        $settings = $this->get_settings_for_display(); ?>

        <!-- Start Free Trial Area -->
        <?php if( $settings['choose_type'] == 1 ) { 
            if ( 'yes' === $settings['section_color_img'] ) { 
                $slidecls = "free-trial-bg";

            } else {
                $slidecls = "free-trial-bg-color";
            } 
            ?>
            <div class="free-trial-area <?php echo esc_attr( $slidecls ); ?>">
                <div class="row m-0">
                    <div class="col-lg-6 col-md-12 p-0">
                        <div class="free-trial-image" style="background-image: url(<?php echo esc_url( $settings['bg_image']['url']); ?> )">
                            <?php echo Group_Control_Image_Size::get_attachment_image_html($settings,'imagesz','image'); ?>
                        </div>
                    </div>

                    <div class="col-lg-6 col-md-12 p-0">
                        <div class="free-trial-content">
                            <?php echo wp_kses_post($settings['form_title']); ?>

                            <form class="newsletter-form" method="post" action="<?php echo get_bloginfo().'/?na=s' ?>" onsubmit="return newsletter_check(this)"><?php
                                if($settings['form_placeholder'] !='') { ?>
                                <input type="email" class="input-newsletter"
                                    placeholder="<?php echo esc_attr($settings['form_placeholder']); ?>"
                                    name="ne" required autocomplete="off"> <?php
                                } ?>
                                <?php
                                if($settings['form_btn'] !='') { ?>
                                    <button type="submit"> <?php echo esc_html($settings['form_btn']); ?> </button><?php
                                } ?>
                                
                            </form>

                            <?php echo wp_kses_post($settings['form_desc']); ?>
                        </div>
                    </div>
                </div>
            </div> <?php
        } else { ?>
            <div class="free-trial-section">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-lg-6 col-md-12">
                            <div class="free-trial-img">
                                <?php echo Group_Control_Image_Size::get_attachment_image_html($settings,'imagesz','image'); ?>
                            </div>
                        </div>

                        <div class="col-lg-6 col-md-12">
                            <div class="free-trial-text">
                                <?php echo wp_kses_post($settings['form_title']); ?>
                                <form class="newsletter-form" method="post" action="<?php echo get_bloginfo().'/?na=s' ?>" onsubmit="return newsletter_check(this)"><?php
                                    if($settings['form_placeholder'] !='') { ?>
                                    <input type="email" class="input-newsletter"
                                        placeholder="<?php echo esc_attr($settings['form_placeholder']); ?>"
                                        name="ne" required autocomplete="off"> <?php
                                    } ?>
                                    <?php
                                    if($settings['form_btn'] !='') { ?>
                                        <button type="submit"> <?php echo esc_html($settings['form_btn']); ?> </button><?php
                                    } ?>
                                </form>
                                <?php echo wp_kses_post($settings['form_desc']); ?>
                            </div>
                        </div>
                    </div>
                </div>
                
                <?php if ( 'yes' === $settings['section_shape'] ) { ?>
                    <div class="shape-img3">
                        <img src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/shape/3.png' ); ?>" alt="<?php echo esc_attr__( 'Shape', 'albion-toolkit' ); ?>">
                    </div>
                    <div class="dot-shape2">
                        <img src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/shape/dot3.png' ); ?>" alt="<?php echo esc_attr__( 'Shape', 'albion-toolkit' ); ?>">
                    </div><?php
                } ?>
            </div> 
        <?php } ?>
        <!-- End Free Trial Area -->
    <?php
    } 
    protected function _content_template() {}

}
Plugin::instance()->widgets_manager->register_widget_type( new NewsletterWidget );