<?php 
namespace Elementor;
class PostWidget extends Widget_Base{
    public function get_name(){
        return "post-widget";
    }
    public function get_title(){
        return "Posts";
    }
    public function get_icon(){
        return "eicon-post-list";
    }
    public function get_categories(){
        return ['albioncategory'];
    }

    protected function _register_controls(){

    // Section controls
    $this-> start_controls_section(
        'albion_section',
        [
            'label'=>esc_html__('Section', 'albion-toolkit'),
            'tab'=> Controls_Manager::TAB_CONTENT,
        ]
    );

    $this->add_control(
        'section_title',
        [
            'label'=>esc_html__('Title', 'albion-toolkit'),
            'type'=>Controls_Manager:: WYSIWYG,
            'description' => esc_html__('This text editor for h1 to h6 html tag','albion-toolkit'),
        ]
    );

    $this->add_control(
        'section_desc',
        [
            'label'=>esc_html__('Description', 'albion-toolkit'),
            'type'=>Controls_Manager:: WYSIWYG,
            'description' => esc_html__('This text editor for p, ul - ol list tag','albion-toolkit'),
        ]
    );

    $this->add_control(
        'post_shape',
        [
            'label' => esc_html__( 'Show Shapes', 'albion-toolkit' ),
            'type' => Controls_Manager::SWITCHER,
            'label_on' => esc_html__( 'Show', 'albion-toolkit' ),
            'label_off' => esc_html__( 'Hide', 'albion-toolkit' ),
            'return_value' => 'yes',
            'default' => 'yes',
        ]
    );
    $this-> end_controls_section();
    // End Section controls

    $this-> start_controls_section(
        'layout_section',
        [
            'label'=>esc_html__('Posts Content', 'albion-toolkit'),
            'tab'=> Controls_Manager::TAB_CONTENT,
        ]
    );

    $this->add_control(
        'count',
        [
            'label' => esc_html__( 'Post Per Page', 'albion-toolkit' ),
            'default' => esc_html__( '3', 'albion-toolkit' ),
            'type' => Controls_Manager::TEXT,
            'description' => esc_html__('if you went to see all post type -1','albion-toolkit')
        ]
    );

    $this->add_control(
        'order',
        [
            'label' => esc_html__( 'Select Order', 'albion-toolkit' ),
            'type' => Controls_Manager::SELECT,
            'options' => [
                'DESC'  => esc_html__( 'DESC', 'albion-toolkit' ),
                'ASC'  => esc_html__( 'ASC', 'albion-toolkit' ),
            ],
            'default' => 'DESC',
        ]
    );
    $this-> end_controls_section();

    // Start Style content controls
    $this-> start_controls_section(
        'heading_style',
        [
            'label'=>esc_html__('Section Heading', 'albion-toolkit'),
            'tab'=> Controls_Manager::TAB_STYLE,
        ]
    );

    $this->add_control(
        'title_style',
        [
            'label' => esc_html__( 'Title', 'albion-toolkit' ),
            'type' => Controls_Manager::HEADING,
        ]
    );

    $this->add_control(
        'title_color',
        [
            'label' => esc_html__( 'Color', 'albion-toolkit' ),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .section-title h2' => 'color: {{VALUE}}',
            ],
        ]
    );

    $this->add_responsive_control(
        'title_font_size',
        [
            'label' => esc_html__( 'Font Size', 'albion-toolkit' ),
            'type' => Controls_Manager::SLIDER,
            'range' => [
                'px' => [
                    'min' => 0,
                    'max' => 60,
                ],
            ],
            'devices' => [ 'desktop', 'tablet', 'mobile' ],
            'unit' => 'px',
            'selectors' => [
                '{{WRAPPER}} .section-title h2' => 'font-size: {{SIZE}}{{UNIT}}',
            ],
        ]
    );

    $this->add_control(
        'desc_style',
        [
            'label' => esc_html__( 'Description', 'albion-toolkit' ),
            'type' => Controls_Manager::HEADING,
        ]
    );

    $this->add_control(
        'desc_color',
        [
            'label' => esc_html__( 'Color', 'albion-toolkit' ),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .section-title p' => 'color: {{VALUE}}',
            ],
        ]
    );

    $this->add_responsive_control(
        'desc_size',
        [
            'label' => esc_html__( 'Font Size', 'albion-toolkit' ),
            'type' => Controls_Manager::SLIDER,
            'range' => [
                'px' => [
                    'min' => 0,
                    'max' => 30,
                ],
            ],
            'devices' => [ 'desktop', 'tablet', 'mobile' ],
            'unit' => 'px',
            'selectors' => [
                '{{WRAPPER}} .section-title p' => 'font-size: {{SIZE}}{{UNIT}}',
            ],
        ]
    );

    $this-> end_controls_section();

    // Start Style controls
    $this-> start_controls_section(
        'layout_style',
        [
            'label'=>esc_html__('Posts', 'albion-toolkit'),
            'tab'=> Controls_Manager::TAB_STYLE,
        ]
    );

    $this->add_control(
        'post_mata_info',
        [
            'label' => esc_html__( 'Post Meta', 'albion-toolkit' ),
            'type' => Controls_Manager::HEADING,
        ]
    );

    $this->add_control(
        'mata_info_color',
        [
            'label' => esc_html__( 'Color', 'albion-toolkit' ),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .single-blog-post .post-content .entry-meta ul li' => 'color: {{VALUE}}',
            ],
        ]
    );

    $this->add_responsive_control(
        'mata_info_sz',
        [
            'label' => esc_html__( 'Font Size', 'albion-toolkit' ),
            'type' => Controls_Manager::SLIDER,
            'range' => [
                'px' => [
                    'min' => 0,
                    'max' => 30,
                ],
            ],
            'devices' => [ 'desktop', 'tablet', 'mobile' ],
            'unit' => 'px',
            'selectors' => [
                '{{WRAPPER}} .single-blog-post .post-content .entry-meta ul li' => 'font-size: {{SIZE}}{{UNIT}}',
            ],
        ]
    );

    $this->add_control(
        'post_author',
        [
            'label' => esc_html__( 'Author', 'albion-toolkit' ),
            'type' => Controls_Manager::HEADING,
        ]
    );

    $this->add_control(
        'author_color',
        [
            'label' => esc_html__( 'Author Color', 'albion-toolkit' ),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .single-blog-post .post-content .entry-meta ul li a' => 'color: {{VALUE}}',
            ],
        ]
    );
    $this->add_control(
        'author_hcolor',
        [
            'label' => esc_html__( 'Author Hover Color', 'albion-toolkit' ),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .single-blog-post .post-content .entry-meta ul li a:hover' => 'color: {{VALUE}}',
            ],
        ]
    );

    $this->add_responsive_control(
        'author_font_sz',
        [
            'label' => esc_html__( 'Font Size', 'albion-toolkit' ),
            'type' => Controls_Manager::SLIDER,
            'range' => [
                'px' => [
                    'min' => 0,
                    'max' => 30,
                ],
            ],
            'devices' => [ 'desktop', 'tablet', 'mobile' ],
            'unit' => 'px',
            'selectors' => [
                '{{WRAPPER}} .single-blog-post .post-content .entry-meta ul li a' => 'font-size: {{SIZE}}{{UNIT}}',
            ],
        ]
    );

    $this->add_control(
        'post_title',
        [
            'label' => esc_html__( 'Post Title', 'albion-toolkit' ),
            'type' => Controls_Manager::HEADING,
        ]
    );
    $this->add_control(
        'post_title_color',
        [
            'label' => esc_html__( 'Color', 'albion-toolkit' ),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .single-blog-post .post-content h3 a' => 'color: {{VALUE}}',
            ],
        ]
    );
    $this->add_control(
        'post_title_hcolor',
        [
            'label' => esc_html__( 'Hover Color', 'albion-toolkit' ),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .single-blog-post .post-content h3 a:hover' => 'color: {{VALUE}}',
            ],
        ]
    );
    $this->add_responsive_control(
        'post_title_sz',
        [
            'label' => esc_html__( 'Font Size', 'albion-toolkit' ),
            'type' => Controls_Manager::SLIDER,
            'range' => [
                'px' => [
                    'min' => 0,
                    'max' => 40,
                ],
            ],
            'devices' => [ 'desktop', 'tablet', 'mobile' ],
            'unit' => 'px',
            'selectors' => [
                '{{WRAPPER}} .single-blog-post .post-content h3 ' => 'font-size: {{SIZE}}{{UNIT}}',
            ],
        ]
    );

    $this->add_control(
        'post_desc',
        [
            'label' => esc_html__( 'Description', 'albion-toolkit' ),
            'type' => Controls_Manager::HEADING,
        ]
    );
    $this->add_control(
        'post_desc_color',
        [
            'label' => esc_html__( 'Color', 'albion-toolkit' ),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .single-blog-post .post-content p' => 'color: {{VALUE}}',
            ],
        ]
    );
    $this->add_responsive_control(
        'post_desc_sz',
        [
            'label' => esc_html__( 'Font Size', 'albion-toolkit' ),
            'type' => Controls_Manager::SLIDER,
            'range' => [
                'px' => [
                    'min' => 0,
                    'max' => 20,
                ],
            ],
            'devices' => [ 'desktop', 'tablet', 'mobile' ],
            'unit' => 'px',
            'selectors' => [
                '{{WRAPPER}} .single-blog-post .post-content p' => 'font-size: {{SIZE}}{{UNIT}}',
            ],
        ]
    );

    $this->add_control(
        'post_readmore',
        [
            'label' => esc_html__( 'Read More', 'albion-toolkit' ),
            'type' => Controls_Manager::HEADING,
        ]
    );
    $this->add_control(
        'readmore_color',
        [
            'label' => esc_html__( 'Color', 'albion-toolkit' ),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .single-blog-post .post-content .learn-more-btn' => 'color: {{VALUE}}',
            ],
        ]
    );
    $this->add_control(
        'readmore_hcolor',
        [
            'label' => esc_html__( 'Hover Color', 'albion-toolkit' ),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .single-blog-post .post-content .learn-more-btn:hover' => 'color: {{VALUE}}',
            ],
        ]
    );
    $this->add_control(
        'border_hcolor',
        [
            'label' => esc_html__( 'Border Hover Color', 'albion-toolkit' ),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .learn-more-btn::before' => 'background-color: {{VALUE}}',
            ],
        ]
    );
    $this->add_responsive_control(
        'readmore_sz',
        [
            'label' => esc_html__( 'Font Size', 'albion-toolkit' ),
            'type' => Controls_Manager::SLIDER,
            'range' => [
                'px' => [
                    'min' => 0,
                    'max' => 30,
                ],
            ],
            'devices' => [ 'desktop', 'tablet', 'mobile' ],
            'unit' => 'px',
            'selectors' => [
                '{{WRAPPER}} .single-blog-post .post-content .learn-more-btn' => 'font-size: {{SIZE}}{{UNIT}}',
            ],
        ]
    );

    $this-> end_controls_section();
}

    protected function render() 
    {
        global $albion_opt;
        $settings = $this->get_settings_for_display(); ?>

        <!-- Start Blog Area -->
        <div class="blog-area ptb-110">
            <div class="container">
                <div class="section-title">
                    <?php echo wp_kses_post($settings['section_title']); ?>
                    <?php echo wp_kses_post($settings['section_desc']); ?>
                </div>

                <div class="row">
                    <?php
                    $args = array(
                        'orderby' => 'date',
                        'order' => $settings['order'],
                        'posts_per_page' => $settings['count'],
                        'ignore_sticky_posts' => 1,
                        'meta_key' => '_thumbnail_id'
                    );

                    $post_array = new \WP_Query( $args );
                    $loop = 1;
                    while($post_array->have_posts()): $post_array->the_post();
                    $id = get_the_ID();
                    $title = get_the_title(get_the_ID());
                    if($loop == 3 && $settings['count'] == 3){ 
                        $colcls = "col-lg-4 col-md-6 offset-lg-0 offset-md-3";
                    } else {
                        $colcls = "col-lg-4 col-md-6";
                    } ?>

                    <div class="<?php echo esc_attr($colcls); ?>">
                        <div class="single-blog-post home-blog-post">
                            <div class="entry-thumbnail">
                                <a href="<?php echo esc_url(get_the_permalink($id)); ?>"><img src="<?php echo esc_url(get_the_post_thumbnail_url($id, 'albion_card_thumb')); ?>" alt="<?php echo esc_attr__('blog image','albion-toolkit'); ?>"></a>
                            </div>

                            <div class="post-content">
                                <ul class="entry-meta">
                                    <li>
                                        <a href="<?php echo esc_url( get_author_posts_url( get_the_author_meta( 'ID' ), get_the_author_meta( 'user_nicename' ) ) ) ?>">
                                            <?php the_author() ?>
                                        </a>
                                    </li>
                                    <li><?php echo esc_html__(get_the_date('F d, Y'), 'albion-toolkit'); ?></li>
                                </ul>
                                
                                <h3><a href="<?php echo esc_url(get_the_permalink($id)); ?>"><?php echo esc_html($title); ?></a></h3>
                                <p><?php echo esc_html(wp_trim_words( get_the_excerpt(), 19, '...' )); ?></p>
                                <a href="<?php echo esc_url(get_the_permalink($id)); ?>" class="learn-more-btn"> <?php if(isset($albion_opt['post_read_more'] ) && !$albion_opt['post_read_more'] == ''){ echo esc_html($albion_opt['post_read_more']); }else{ echo esc_html__('Read More','albion-toolkit'); } ?> <i class="flaticon-add"></i></a> 
                            </div>
                        </div>
                    </div> 
                    <?php
                    $loop++;
                    endwhile;
                    wp_reset_query();
                    ?>
                </div>
            </div>
            
            <?php 
            if ( 'yes' === $settings['post_shape'] ) { ?>
            <div class="shape-img2">
                <img src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/shape/2.svg' ); ?>" alt="<?php echo esc_attr__( 'Shape', 'albion-toolkit' ); ?>">
            </div>
            <div class="shape-img3">
                <img src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/shape/3.png' ); ?>" alt="<?php echo esc_attr__( 'Shape', 'albion-toolkit' ); ?>">
            </div>
            <div class="shape-img4">
                <img src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/shape/4.svg' ); ?>" alt="<?php echo esc_attr__( 'Shape', 'albion-toolkit' ); ?>">
            </div>
            <div class="shape-img5">
                <img src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/shape/5.svg' ); ?>" alt="<?php echo esc_attr__( 'Shape', 'albion-toolkit' ); ?>">
            </div>
            <div class="shape-img7">
                <img src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/shape/3.png' ); ?>" alt="<?php echo esc_attr__( 'Shape', 'albion-toolkit' ); ?>">
            </div>
            <div class="dot-shape1">
                <img src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/shape/dot1.png' ); ?>" alt="<?php echo esc_attr__( 'Shape', 'albion-toolkit' ); ?>">
            </div>
            <div class="dot-shape2">
                <img src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/shape/dot3.png' ); ?>" alt="<?php echo esc_attr__( 'Shape', 'albion-toolkit' ); ?>">
            </div>
            <div class="dot-shape4">
                <img src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/shape/dot4.png' ); ?>" alt="<?php echo esc_attr__( 'Shape', 'albion-toolkit' ); ?>">
            </div>
            <div class="dot-shape5">
                <img src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/shape/dot5.png' ); ?>" alt="<?php echo esc_attr__( 'Shape', 'albion-toolkit' ); ?>">
            </div>
            <div class="dot-shape6">
                <img src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/shape/dot6.png' ); ?>" alt="<?php echo esc_attr__( 'Shape', 'albion-toolkit' ); ?>">
            </div><?php
            } ?>
        </div>
        <?php 
    }

    protected function _content_template() {}
}
Plugin::instance()->widgets_manager->register_widget_type( new PostWidget );