<?php
namespace Elementor;
class PricingWidget extends Widget_Base{
    public function get_name(){
        return "pricing-widget";
    }
    public function get_title(){
        return "Pricing Widget";
    }
    public function get_icon(){
        return "eicon-price-table";
    }
    public function get_categories(){
        return ['albioncategory'];
    }

    protected function _register_controls(){
        // Section controls
        $this-> start_controls_section(
            'albion_section',
            [
                'label'=>esc_html__('Section', 'albion-toolkit'),
                'tab'=> Controls_Manager::TAB_CONTENT,
            ]
        );
        $this->add_control(
            'choose_type',
            [
                'label' => esc_html__( 'Choose Style', 'albion-toolkit' ),
                'type' => Controls_Manager::SELECT,
                'label_block' => true,
                'options' => [
                    '1'  => esc_html__( 'Style 1', 'albion-toolkit' ),
                    '2' => esc_html__( 'Style 2', 'albion-toolkit' ),
                ],
                'default' => '1',
            ]
        );
        $this->add_control(
            'section_show',
            [
                'label' => esc_html__( 'Section Show?', 'albion-toolkit' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Show', 'albion-toolkit' ),
                'label_off' => esc_html__( 'Hide', 'albion-toolkit' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );
        $this->add_control(
            'section_title',
            [
                'label'=>esc_html__('Title', 'albion-toolkit'),
                'type'=>Controls_Manager:: WYSIWYG,
                'condition' => [
                    'section_show' => 'yes',
                ],
                'description' => esc_html__('This text editor for h1 to h6 html tag','albion-toolkit'),
            ]
        );
    
        $this->add_control(
            'section_desc',
            [
                'label'=>esc_html__('Description', 'albion-toolkit'),
                'type'=>Controls_Manager:: WYSIWYG,
                'condition' => [
                    'section_show' => 'yes',
                ],
                'description' => esc_html__('This text editor for p, ul - ol list tag','albion-toolkit'),
            ]
        );

        $this->add_control(
			'price_shape',
			[
				'label' => esc_html__( 'Show Shapes', 'albion-toolkit' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'albion-toolkit' ),
				'label_off' => esc_html__( 'Hide', 'albion-toolkit' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
        );
        $this-> end_controls_section();
        // End Section controls

        // Tab controls
        $this-> start_controls_section(
            'albion_pricing',
            [
                'label'=>esc_html__('Pricing Tab', 'albion-toolkit'),
                'tab'=> Controls_Manager::TAB_CONTENT,
            ]
        );
        $this->add_control(
            'monthly_plan_text', [
                'label' => esc_html__( 'Monthly Plan Text', 'albion-toolkit' ),
                'type'=>Controls_Manager:: TEXT,
                'default' => esc_html__( 'Monthly Plan', 'albion-toolkit' ),
            ]
        );

        $this->add_control(
            'yearly_plan_text', [
                'label' => esc_html__( 'Yearly Plan Text', 'albion-toolkit' ),
                'type'=>Controls_Manager:: TEXT,
                'default' => esc_html__( 'Yearly Plan', 'albion-toolkit' ),
            ]
        );
        $this-> end_controls_section();
        // End Tab controls

        // Monthly Plan controls
        $this-> start_controls_section(
            'albion_monthly_plan',
            [
                'label'=>esc_html__('Monthly Plan', 'albion-toolkit'),
                'tab'=> Controls_Manager::TAB_CONTENT,
                'condition' => [
                    'monthly_plan_text!' => '',
                ]           
                
            ]
        );

        $repeater = new Repeater();

        $repeater->add_control(
            'monthly_type', [
                'label' => esc_html__( 'Pricing Type', 'albion-toolkit' ),
                'type'=>Controls_Manager:: WYSIWYG,
                'description' => esc_html__('This text editor for h1 to h6 html tag','albion-toolkit'),
            ]
        );

        $repeater->add_control(
            'monthly_desc', [
                'label' => esc_html__( 'Description', 'albion-toolkit' ),
                'type'=>Controls_Manager:: TEXTAREA,
            ]
        );
        $repeater->add_control(
            'monthly_price', [
                'label' => esc_html__( 'Price Amount With Symbol', 'albion-toolkit' ),
                'type'=>Controls_Manager:: TEXT,
            ]
        );
        $repeater->add_control(
            'monthly_duration', [
                'label' => esc_html__( 'Price Duration', 'albion-toolkit' ),
                'type'=>Controls_Manager:: TEXT,
            ]
        );

        $repeater->add_control(
            'btn_text',
            [
                'label'=>esc_html__('Button Title', 'albion-toolkit'),
                'type'=>Controls_Manager:: TEXT,
            ]
        );

        $repeater->add_control(
            'link_type',
            [
                'label' => esc_html__( 'Link Type', 'albion-toolkit' ),
                'type' => Controls_Manager::SELECT,
                'label_block' => true,
                'options' => [
                    '1'  => esc_html__( 'Link To Page', 'albion-toolkit' ),
                    '2' => esc_html__( 'External Link', 'albion-toolkit' ),
                ],
            ]
        );

        $repeater->add_control(
            'link_to_page',
            [
                'label' => esc_html__( 'Link Page', 'albion-toolkit' ),
                'type' => Controls_Manager::SELECT,
                'label_block' => true,
                'options' => albion_toolkit_get_page_as_list(),
                'condition' => [
                    'link_type' => '1',
                ]
            ]
        );

        $repeater->add_control(
            'external_link',
            [
                'label'=>esc_html__('External Link', 'albion-toolkit'),
                'type'=>Controls_Manager:: TEXT,
                'condition' => [
                    'link_type' => '2',
                ]
            ]
        );
        $repeater->add_control(
            'mon_price_list', [
                'label' => esc_html__( 'Pricing List', 'albion-toolkit' ),
                'type'=>Controls_Manager:: WYSIWYG,
            ]
        );
        $repeater->add_control(
			'active_card',
			[
				'label' => esc_html__( 'Card active?', 'albion-toolkit' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'albion-toolkit' ),
				'label_off' => esc_html__( 'No', 'albion-toolkit' ),
				'return_value' => 'yes',
			]
		);

        $this->add_control(
            'all_monthly_plan',
            [
                'label' => esc_html__( 'Add Monthly Plan', 'albion-toolkit' ),
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
            ]
        );
        $this-> end_controls_section();
        // End Monthly Plan controls

        // Yearly Plan controls
        $this-> start_controls_section(
            'albion_yearly_plan',
            [
                'label'=>esc_html__('Yearly Plan', 'albion-toolkit'),
                'tab'=> Controls_Manager::TAB_CONTENT,
                'condition' => [
                    'yearly_plan_text!' => '',
                ]           
                
            ]
        );

        $repeater2 = new Repeater();

        $repeater2->add_control(
            'yearly_type', [
                'label' => esc_html__( 'Pricing Type', 'albion-toolkit' ),
                'type'=>Controls_Manager:: WYSIWYG,
                'description' => esc_html__('This text editor for h1 to h6 html tag','albion-toolkit'),
            ]
        );

        $repeater2->add_control(
            'yearly_desc', [
                'label' => esc_html__( 'Description', 'albion-toolkit' ),
                'type'=>Controls_Manager:: TEXTAREA,
            ]
        );
        $repeater2->add_control(
            'yearly_price', [
                'label' => esc_html__( 'Price Amount With Symbol', 'albion-toolkit' ),
                'type'=>Controls_Manager:: TEXT,
            ]
        );
        $repeater2->add_control(
            'yearly_duration', [
                'label' => esc_html__( 'Price Duration', 'albion-toolkit' ),
                'type'=>Controls_Manager:: TEXT,
            ]
        );

        $repeater2->add_control(
            'year_btn_text',
            [
                'label'=>esc_html__('Button Title', 'albion-toolkit'),
                'type'=>Controls_Manager:: TEXT,
            ]
        );

        $repeater2->add_control(
            'link_type2',
            [
                'label' => esc_html__( 'Link Type', 'albion-toolkit' ),
                'type' => Controls_Manager::SELECT,
                'label_block' => true,
                'options' => [
                    '1'  => esc_html__( 'Link To Page', 'albion-toolkit' ),
                    '2' => esc_html__( 'External Link', 'albion-toolkit' ),
                ],
            ]
        );

        $repeater2->add_control(
            'link_to_page2',
            [
                'label' => esc_html__( 'Link Page', 'albion-toolkit' ),
                'type' => Controls_Manager::SELECT,
                'label_block' => true,
                'options' => albion_toolkit_get_page_as_list(),
                'condition' => [
                    'link_type2' => '1',
                ]
            ]
        );

        $repeater2->add_control(
            'external_link2',
            [
                'label'=>esc_html__('External Link', 'albion-toolkit'),
                'type'=>Controls_Manager:: TEXT,
                'condition' => [
                    'link_type2' => '2',
                ]
            ]
        );
        $repeater2->add_control(
            'year_price_list', [
                'label' => esc_html__( 'Pricing List', 'albion-toolkit' ),
                'type'=>Controls_Manager:: WYSIWYG,
            ]
        );
        $repeater2->add_control(
			'active_card2',
			[
				'label' => esc_html__( 'Card active?', 'albion-toolkit' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'albion-toolkit' ),
				'label_off' => esc_html__( 'No', 'albion-toolkit' ),
				'return_value' => 'yes',
			]
		);

        $this->add_control(
            'all_yearly_plan',
            [
                'label' => esc_html__( 'Add Yearly Plan', 'albion-toolkit' ),
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater2->get_controls(),
            ]
        );
        $this-> end_controls_section();
        // End Yearly Plan controls

        // Start Style content controls
        $this-> start_controls_section(
            'heading_style',
            [
                'label'=>esc_html__('Section Heading', 'albion-toolkit'),
                'tab'=> Controls_Manager::TAB_STYLE,
                'condition' => [
                    'section_show' => 'yes',
                ]
            ]
        );

        $this->add_control(
            'title_style',
            [
                'label' => esc_html__( 'Title', 'albion-toolkit' ),
                'type' => Controls_Manager::HEADING,
            ]
        );
    
        $this->add_control(
            'title_color',
            [
                'label' => esc_html__( 'Color', 'albion-toolkit' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .section-title h2' => 'color: {{VALUE}}',
                ],
            ]
        );
    
        $this->add_responsive_control(
            'title_font_size',
            [
                'label' => esc_html__( 'Font Size', 'albion-toolkit' ),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 60,
                    ],
                ],
                'devices' => [ 'desktop', 'tablet', 'mobile' ],
                'unit' => 'px',
                'selectors' => [
                    '{{WRAPPER}} .section-title h2' => 'font-size: {{SIZE}}{{UNIT}}',
                ],
            ]
        );
    
        $this->add_control(
            'desc_style',
            [
                'label' => esc_html__( 'Description', 'albion-toolkit' ),
                'type' => Controls_Manager::HEADING,
            ]
        );
    
        $this->add_control(
            'desc_color',
            [
                'label' => esc_html__( 'Color', 'albion-toolkit' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .section-title p' => 'color: {{VALUE}}',
                ],
            ]
        );
    
        $this->add_responsive_control(
            'desc_size',
            [
                'label' => esc_html__( 'Font Size', 'albion-toolkit' ),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 30,
                    ],
                ],
                'devices' => [ 'desktop', 'tablet', 'mobile' ],
                'unit' => 'px',
                'selectors' => [
                    '{{WRAPPER}} .section-title p' => 'font-size: {{SIZE}}{{UNIT}}',
                ],
            ]
        );

        $this-> end_controls_section();

        $this-> start_controls_section(
            'pricing_style',
            [
                'label'=>esc_html__('Tab Button', 'albion-toolkit'),
                'tab'=> Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'tabbtn_font_size',
            [
                'label' => esc_html__( 'Font Size', 'albion-toolkit' ),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 30,
                    ],
                ],
                'devices' => [ 'desktop', 'tablet', 'mobile' ],
                'unit' => 'px',
                'selectors' => [
                    '{{WRAPPER}} .pricing-tab .tabs li a' => 'font-size: {{SIZE}}{{UNIT}}',
                ],
            ]
        );

        // Button Style //
        $this->start_controls_tabs( 'button_effects');

        $this->start_controls_tab( 'normal',
			[
				'label' => esc_html__( 'Normal', 'albion-toolkit' ),
			]
        );

        $this->add_control(
            'btn_color',
            [
                'label' => esc_html__( 'Color', 'albion-toolkit' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .pricing-tab .tabs li a' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'btn_bgcolor',
            [
                'label' => esc_html__( 'Background Color', 'albion-toolkit' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .pricing-tab .tabs li a' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab( 'hover',
            [
                'label' => esc_html__( 'Active And Hover', 'albion-toolkit' ),
            ]
        );

        $this->add_control(
            'btn_hcolor',
            [
                'label' => esc_html__( 'Color', 'albion-toolkit' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}}  .pricing-tab .tabs li.current a' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'btn_hbgcolor',
            [
                'label' => esc_html__( 'Background Color', 'albion-toolkit' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}}  .pricing-tab .tabs li.current a' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->end_controls_tabs();
        // End Button Style //

        $this-> end_controls_section();

        $this-> start_controls_section(
            'pricing_card_style',
            [
                'label'=>esc_html__('Pricing Card', 'albion-toolkit'),
                'tab'=> Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control(
            'price_type',
            [
                'label' => esc_html__( 'Pricing Type', 'albion-toolkit' ),
                'type' => Controls_Manager::HEADING,
            ]
        );
    
        $this->add_control(
            'type_color',
            [
                'label' => esc_html__( 'Color', 'albion-toolkit' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .single-pricing-box .pricing-header h3, .pricing-box .pricing-header h3' => 'color: {{VALUE}}',
                ],
            ]
        );
    
        $this->add_responsive_control(
            'type_size',
            [
                'label' => esc_html__( 'Font Size', 'albion-toolkit' ),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 40,
                    ],
                ],
                'devices' => [ 'desktop', 'tablet', 'mobile' ],
                'unit' => 'px',
                'selectors' => [
                    '{{WRAPPER}} .single-pricing-box .pricing-header h3, .pricing-box .pricing-header h3' => 'font-size: {{SIZE}}{{UNIT}}',
                ],
            ]
        );
        $this->add_control(
            'short_desc_type',
            [
                'label' => esc_html__( 'Pricing Description', 'albion-toolkit' ),
                'type' => Controls_Manager::HEADING,
            ]
        );
    
        $this->add_control(
            'short_desc_color',
            [
                'label' => esc_html__( 'Color', 'albion-toolkit' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .single-pricing-box .pricing-header p, .pricing-box .pricing-header p' => 'color: {{VALUE}}',
                ],
            ]
        );
    
        $this->add_responsive_control(
            'short_desc_size',
            [
                'label' => esc_html__( 'Font Size', 'albion-toolkit' ),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 20,
                    ],
                ],
                'devices' => [ 'desktop', 'tablet', 'mobile' ],
                'unit' => 'px',
                'selectors' => [
                    '{{WRAPPER}} .single-pricing-box .pricing-header p, .pricing-box .pricing-header p' => 'font-size: {{SIZE}}{{UNIT}}',
                ],
            ]
        );
        $this->add_control(
            'price_symbol',
            [
                'label' => esc_html__( 'Pricing Value', 'albion-toolkit' ),
                'type' => Controls_Manager::HEADING,
            ]
        );
    
        $this->add_control(
            'price_color',
            [
                'label' => esc_html__( 'Color', 'albion-toolkit' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .single-pricing-box .price, .pricing-box .price' => 'color: {{VALUE}}',
                ],
            ]
        );
    
        $this->add_responsive_control(
            'price_size',
            [
                'label' => esc_html__( 'Font Size', 'albion-toolkit' ),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 70,
                    ],
                ],
                'devices' => [ 'desktop', 'tablet', 'mobile' ],
                'unit' => 'px',
                'selectors' => [
                    '{{WRAPPER}} .single-pricing-box .price, .pricing-box .price' => 'font-size: {{SIZE}}{{UNIT}}',
                ],
            ]
        );

        $this->add_control(
            'price_duration',
            [
                'label' => esc_html__( 'Pricing Duration', 'albion-toolkit' ),
                'type' => Controls_Manager::HEADING,
            ]
        );
    
        $this->add_control(
            'duration_color',
            [
                'label' => esc_html__( 'Color', 'albion-toolkit' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .single-pricing-box .price span, .pricing-box .price span' => 'color: {{VALUE}}',
                ],
            ]
        );
    
        $this->add_responsive_control(
            'duration_size',
            [
                'label' => esc_html__( 'Font Size', 'albion-toolkit' ),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 30,
                    ],
                ],
                'devices' => [ 'desktop', 'tablet', 'mobile' ],
                'unit' => 'px',
                'selectors' => [
                    '{{WRAPPER}} .single-pricing-box .price span, .pricing-box .price span' => 'font-size: {{SIZE}}{{UNIT}}',
                ],
            ]
        );


        // Button Style //
        $this->add_control(
            'price_btn_heading',
            [
                'label' => esc_html__( 'Pricing Button', 'albion-toolkit' ),
                'type' => Controls_Manager::HEADING,
            ]
        );
        $this->start_controls_tabs( 'price_button_effects');

        $this->start_controls_tab( 'pricenormal',
			[
				'label' => esc_html__( 'Normal', 'albion-toolkit' ),
			]
        );

        $this->add_control(
            'pricebtn_color',
            [
                'label' => esc_html__( 'Color', 'albion-toolkit' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .btn-primary' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'pricebtn_bgcolor',
            [
                'label' => esc_html__( 'Background Color', 'albion-toolkit' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .single-pricing-box .buy-btn .btn-primary::after, .pricing-box .buy-btn .btn-primary::after ' => 'background: {{VALUE}}',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab( 'pricehover',
            [
                'label' => esc_html__( 'Active And Hover', 'albion-toolkit' ),
            ]
        );

        $this->add_control(
            'pricebtn_hbgcolor',
            [
                'label' => esc_html__( 'Background Color', 'albion-toolkit' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}}  .btn-primary' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->end_controls_tabs();
        // End Button Style //

        $this->add_control(
            'price_list',
            [
                'label' => esc_html__( 'Pricing List', 'albion-toolkit' ),
                'type' => Controls_Manager::HEADING,
            ]
        );
    
        $this->add_control(
            'price_list_color',
            [
                'label' => esc_html__( 'Color', 'albion-toolkit' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .single-pricing-box .pricing-features li, .pricing-box .pricing-features li' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'price_list_icon_color',
            [
                'label' => esc_html__( 'Icon Color', 'albion-toolkit' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .single-pricing-box .pricing-features li i, .pricing-features li i' => 'color: {{VALUE}}',
                ],
            ]
        );
    
        $this->add_responsive_control(
            'price_list_size',
            [
                'label' => esc_html__( 'Font Size', 'albion-toolkit' ),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 20,
                    ],
                ],
                'devices' => [ 'desktop', 'tablet', 'mobile' ],
                'unit' => 'px',
                'selectors' => [
                    '{{WRAPPER}} .single-pricing-box .pricing-features li, .pricing-box .pricing-features li' => 'font-size: {{SIZE}}{{UNIT}}',
                ],
            ]
        );

        $this-> end_controls_section();

    }

    protected function render() 
    {
        $settings = $this->get_settings_for_display();

         // Tag allowed for about content
         $price_text_allowed_tags = array(
            'a' =>array(
                'href' => array(),
                'title' => array(),
                'class' => array()
            ),
            'p' => array(),
            'em' => array(),
            'strong' => array()
        );
        ?>

        <!-- Start Pricing Area -->
        <?php if( $settings['choose_type'] == 1 ) { ?>
            <section class="pricing-area ptb-110 ">
                <div class="container">
                <?php 
                if ( 'yes' === $settings['section_show'] ) { ?>
                    <div class="section-title">
                        <?php echo wp_kses_post($settings['section_title']); ?>
                        <?php echo wp_kses_post($settings['section_desc']); ?>
                    </div>
                <?php } ?>

                    <div class="tab pricing-tab">
                        <ul class="tabs"> <?php
                            if($settings['monthly_plan_text'] !='') { ?>
                                <li><a href="#">
                                    <?php echo esc_html( $settings['monthly_plan_text']); ?>
                                </a></li> <?php
                            } ?> <?php 

                            if($settings['yearly_plan_text'] !='') { ?>
                                <li><a href="#">
                                    <?php echo esc_html( $settings['yearly_plan_text']); ?>
                                </a></li> <?php
                            }

                            if($settings['monthly_plan_text'] =='' && $settings['yearly_plan_text'] !='') { 
                                $display_block_Css = "display-block-css";
                            } else {
                                $display_block_Css = "";
                            }
                            
                            ?>
                        </ul>

                        <div class="tab-content">
                            <!-- Start Monthly -->
                            <div class="tabs-item">
                                <div class="row"> <?php
                                if ( $settings['all_monthly_plan']!='' ){
                                    $loop = 1;
                                    foreach ( $settings['all_monthly_plan'] as $item ) {
                                        // Count Loop
                                        if ($loop == 3) {
                                            $colcls = 'col-lg-4 col-md-6 col-sm-6 offset-lg-0 offset-md-3 offset-sm-3';
                                        }else {
                                            $colcls = 'col-lg-4 col-md-6 col-sm-6';
                                        }

                                        // Active class
                                        if ( 'yes' === $item['active_card'] ) {
                                            $active = "active";
                                        } else {
                                            $active = " ";
                                        }
            
                                        if($item['monthly_type']!='' || $item['monthly_price']!='') { 
                                            // Get Plan Button link
                                            $link_source = '';
                                            if($item['link_type'] == 1){
                                                $link_source = get_page_link($item['link_to_page']); 
                                            } else {
                                                $link_source = $item['external_link'];
                                            }?>

                                            <div class="<?php echo esc_attr( $colcls ); ?>">
                                                <div class="single-pricing-box <?php echo esc_attr( $active ); ?>">
                                                    <div class="pricing-header">
                                                        <?php echo wp_kses_post($item['monthly_type']); ?>
                                                        <p><?php echo wp_kses( $item['monthly_desc'],  $price_text_allowed_tags ); ?></p>
                                                    </div>

                                                    <div class="price">
                                                        <?php echo esc_html($item['monthly_price']); ?> <span><?php echo esc_html($item['monthly_duration']); ?></span>
                                                    </div> <?php
                                                    if($item['btn_text'] !='') { ?>
                                                    <div class="buy-btn">
                                                        <a href="<?php echo esc_url($link_source); ?>" class="btn btn-primary"><?php echo esc_html($item['btn_text']); ?></a>
                                                    </div><?php } ?>
                                                    
                                                    <?php echo wp_kses_post($item['mon_price_list']); ?>
                                                </div>
                                            </div><?php
                                        } 
                                    $loop++; 
                                    } 
                                } ?>
                                </div>
                            </div>
                            <!-- End Monthly -->

                            <!-- Start Yearly -->
                            <div class="tabs-item <?php echo esc_html($display_block_Css); ?>">
                                <div class="row"> <?php
                                if ( $settings['all_yearly_plan']!='' ){
                                    $loop2 = 1;
                                    foreach ( $settings['all_yearly_plan'] as $item2 ) {
                                        // Count Loop
                                        if ($loop2 == 3) {
                                            $colcls2 = 'col-lg-4 col-md-6 col-sm-6 offset-lg-0 offset-md-3 offset-sm-3';
                                        }else {
                                            $colcls2 = 'col-lg-4 col-md-6 col-sm-6';
                                        }

                                        // Active class
                                        if ( 'yes' === $item2['active_card2'] ) {
                                            $active2 = "active";
                                        } else {
                                            $active2 = " ";
                                        }
            
                                        if($item2['yearly_type']!='' || $item2['yearly_price']!='') { 
                                            // Get Plan Button link
                                            $link_source2 = '';
                                            if($item2['link_type2'] == 1){
                                                $link_source2 = get_page_link($item2['link_to_page2']); 
                                            } else {
                                                $link_source2 = $item2['external_link2'];
                                            }?>

                                            <div class="<?php echo esc_attr( $colcls2 ); ?>">
                                                <div class="single-pricing-box <?php echo esc_attr( $active2 ); ?>">
                                                    <div class="pricing-header">
                                                        <?php echo wp_kses_post($item2['yearly_type']); ?>
                                                        <p><?php echo wp_kses( $item2['yearly_desc'],  $price_text_allowed_tags ); ?></p>
                                                    </div>

                                                    <div class="price">
                                                        <?php echo esc_html($item2['yearly_price']); ?> <span><?php echo esc_html($item2['yearly_duration']); ?></span>
                                                    </div> <?php
                                                    if($item2['year_btn_text'] !='') { ?>
                                                    <div class="buy-btn">
                                                        <a href="<?php echo esc_url($link_source2); ?>" class="btn btn-primary"><?php echo esc_html($item2['year_btn_text']); ?></a>
                                                    </div><?php } ?>
                                                    
                                                    <?php echo wp_kses_post($item2['year_price_list']); ?>
                                                </div>
                                            </div><?php
                                        } 
                                    $loop2++; 
                                    } 
                                } ?>
                                </div>
                            </div>
                            <!-- End Yearly -->
                        </div>
                    </div>
                </div>

                <?php 
                if ( 'yes' === $settings['price_shape'] ) { ?>
                <div class="shape-img2">
                    <img src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/shape/2.svg' ); ?>" alt="<?php echo esc_attr__( 'Shape', 'albion-toolkit' ); ?>">
                </div>
                <div class="shape-img3">
                    <img src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/shape/3.png' ); ?>" alt="<?php echo esc_attr__( 'Shape', 'albion-toolkit' ); ?>">
                </div>
                <div class="shape-img4">
                    <img src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/shape/4.svg' ); ?>" alt="<?php echo esc_attr__( 'Shape', 'albion-toolkit' ); ?>">
                </div>
                <div class="shape-img5">
                    <img src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/shape/5.svg' ); ?>" alt="<?php echo esc_attr__( 'Shape', 'albion-toolkit' ); ?>">
                </div>
                <div class="shape-img7">
                    <img src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/shape/3.png' ); ?>" alt="<?php echo esc_attr__( 'Shape', 'albion-toolkit' ); ?>">
                </div>
                <div class="dot-shape1">
                    <img src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/shape/dot1.png' ); ?>" alt="<?php echo esc_attr__( 'Shape', 'albion-toolkit' ); ?>">
                </div>
                <div class="dot-shape2">
                    <img src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/shape/dot3.png' ); ?>" alt="<?php echo esc_attr__( 'Shape', 'albion-toolkit' ); ?>">
                </div>
                <div class="dot-shape4">
                    <img src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/shape/dot4.png' ); ?>" alt="<?php echo esc_attr__( 'Shape', 'albion-toolkit' ); ?>">
                </div>
                <div class="dot-shape5">
                    <img src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/shape/dot5.png' ); ?>" alt="<?php echo esc_attr__( 'Shape', 'albion-toolkit' ); ?>">
                </div>
                <div class="dot-shape6">
                    <img src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/shape/dot6.png' ); ?>" alt="<?php echo esc_attr__( 'Shape', 'albion-toolkit' ); ?>">
                </div><?php
                } ?>

            </section><?php
        } else { ?>
            <div class="pricing-area ptb-110 pt-0">
                <div class="container">
                <?php 
                if ( 'yes' === $settings['section_show'] ) { ?>
                    <div class="section-title">
                        <?php echo wp_kses_post($settings['section_title']); ?>
                        <?php echo wp_kses_post($settings['section_desc']); ?>
                    </div>
                <?php } ?>

                    <div class="tab pricing-tab bg-color">
                        <ul class="tabs"> <?php
                            if($settings['monthly_plan_text'] !='') { ?>
                                <li><a href="#">
                                    <?php echo esc_html( $settings['monthly_plan_text']); ?>
                                </a></li> <?php
                            } ?> <?php 

                            if($settings['yearly_plan_text'] !='') { ?>
                                <li><a href="#">
                                    <?php echo esc_html( $settings['yearly_plan_text']); ?>
                                </a></li> <?php
                            }

                            if($settings['monthly_plan_text'] =='' && $settings['yearly_plan_text'] !='') { 
                                $display_block_Css = "display-block-css";
                            } else {
                                $display_block_Css = "";
                            }
                            
                            ?>
                        </ul>

                        <div class="tab-content">
                            <!-- Start Monthly -->
                            <div class="tabs-item">
                                <div class="row"> <?php
                                if ( $settings['all_monthly_plan']!='' ){
                                    $loop = 1;
                                    foreach ( $settings['all_monthly_plan'] as $item ) {
                                        // Count Loop
                                        if ($loop == 3) {
                                            $colcls = 'col-lg-4 col-md-6 col-sm-6 offset-lg-0 offset-md-3 offset-sm-3';
                                        }else {
                                            $colcls = 'col-lg-4 col-md-6 col-sm-6';
                                        }

                                        // Active class
                                        if ( 'yes' === $item['active_card'] ) {
                                            $active = "active";
                                        } else {
                                            $active = " ";
                                        }
            
                                        if($item['monthly_type']!='' || $item['monthly_price']!='') { 
                                            // Get Plan Button link
                                            $link_source = '';
                                            if($item['link_type'] == 1){
                                                $link_source = get_page_link($item['link_to_page']); 
                                            } else {
                                                $link_source = $item['external_link'];
                                            }?>

                                            <div class="<?php echo esc_attr( $colcls ); ?>">
                                                <div class="pricing-box <?php echo esc_attr( $active ); ?>">
                                                    <div class="pricing-header">
                                                        <?php echo wp_kses_post($item['monthly_type']); ?>
                                                        <p><?php echo wp_kses( $item['monthly_desc'],  $price_text_allowed_tags ); ?></p>
                                                    </div>

                                                    <div class="price">
                                                        <?php echo esc_html($item['monthly_price']); ?> <span><?php echo esc_html($item['monthly_duration']); ?></span>
                                                    </div> <?php
                                                    if($item['btn_text'] !='') { ?>
                                                    <div class="buy-btn">
                                                        <a href="<?php echo esc_url($link_source); ?>" class="btn btn-primary"><?php echo esc_html($item['btn_text']); ?></a>
                                                    </div><?php } ?>
                                                    
                                                    <?php echo wp_kses_post($item['mon_price_list']); ?>
                                                </div>
                                            </div><?php
                                        } 
                                    $loop++; 
                                    } 
                                } ?>
                                </div>
                            </div>
                            <!-- End Monthly -->

                            <!-- Start Yearly -->
                            <div class="tabs-item <?php echo esc_html($display_block_Css); ?>">
                                <div class="row"> <?php
                                if ( $settings['all_yearly_plan']!='' ){
                                    $loop2 = 1;
                                    foreach ( $settings['all_yearly_plan'] as $item2 ) {
                                        // Count Loop
                                        if ($loop2 == 3) {
                                            $colcls2 = 'col-lg-4 col-md-6 col-sm-6 offset-lg-0 offset-md-3 offset-sm-3';
                                        }else {
                                            $colcls2 = 'col-lg-4 col-md-6 col-sm-6';
                                        }

                                        // Active class
                                        if ( 'yes' === $item2['active_card2'] ) {
                                            $active2 = "active";
                                        } else {
                                            $active2 = " ";
                                        }
            
                                        if($item2['yearly_type']!='' || $item2['yearly_price']!='') { 
                                            // Get Plan Button link
                                            $link_source2 = '';
                                            if($item2['link_type2'] == 1){
                                                $link_source2 = get_page_link($item2['link_to_page2']); 
                                            } else {
                                                $link_source2 = $item2['external_link2'];
                                            }?>

                                            <div class="<?php echo esc_attr( $colcls2 ); ?>">
                                                <div class="pricing-box <?php echo esc_attr( $active2 ); ?>">
                                                    <div class="pricing-header">
                                                        <?php echo wp_kses_post($item2['yearly_type']); ?>
                                                        <p><?php echo wp_kses( $item2['yearly_desc'],  $price_text_allowed_tags ); ?></p>
                                                    </div>

                                                    <div class="price">
                                                        <?php echo esc_html($item2['yearly_price']); ?> <span><?php echo esc_html($item2['yearly_duration']); ?></span>
                                                    </div> <?php
                                                    if($item2['year_btn_text'] !='') { ?>
                                                    <div class="buy-btn">
                                                        <a href="<?php echo esc_url($link_source2); ?>" class="btn btn-primary"><?php echo esc_html($item2['year_btn_text']); ?></a>
                                                    </div><?php } ?>
                                                    
                                                    <?php echo wp_kses_post($item2['year_price_list']); ?>
                                                </div>
                                            </div><?php
                                        } 
                                    $loop2++; 
                                    } 
                                } ?>
                                </div>
                            </div>
                            <!-- End Yearly -->
                        </div>
                    </div>
                </div>

                <?php 
                if ( 'yes' === $settings['price_shape'] ) { ?>
                    <div class="shape-img2">
                        <img src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/shape/2.svg' ); ?>" alt="<?php echo esc_attr__( 'Shape', 'albion-toolkit' ); ?>">
                    </div>
                    <div class="shape-img3">
                        <img src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/shape/3.png' ); ?>" alt="<?php echo esc_attr__( 'Shape', 'albion-toolkit' ); ?>">
                    </div>
                    <div class="shape-img5">
                        <img src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/shape/5.svg' ); ?>" alt="<?php echo esc_attr__( 'Shape', 'albion-toolkit' ); ?>">
                    </div>
                    <div class="shape-img7">
                        <img src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/shape/3.png' ); ?>" alt="<?php echo esc_attr__( 'Shape', 'albion-toolkit' ); ?>">
                    </div><?php
                } ?>
            </div>
        <?php } ?>
        <!-- End Pricing Area -->
    <?php
    } 
    protected function _content_template() {}

}
Plugin::instance()->widgets_manager->register_widget_type( new PricingWidget );