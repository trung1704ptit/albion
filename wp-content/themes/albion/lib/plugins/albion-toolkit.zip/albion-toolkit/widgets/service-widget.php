<?php
namespace Elementor;
class ServiceWidget extends Widget_Base{
    public function get_name(){
        return "service-widget";
    }
    public function get_title(){
        return "Services";
    }
    public function get_icon(){
        return "eicon-favorite";
    }
    public function get_categories(){
        return ['albioncategory'];
    }

    protected function _register_controls(){
        // Tab content controls
        $this-> start_controls_section(
            'section_content',
            [
                'label'=>esc_html__('Content', 'albion-toolkit'),
                'tab'=> Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'choose_type',
            [
                'label' => esc_html__( 'Choose Style', 'albion-toolkit' ),
                'type' => Controls_Manager::SELECT,
                'label_block' => true,
                'options' => [
                    '1'  => esc_html__( 'Style 1', 'albion-toolkit' ),
                    '2' => esc_html__( 'Style 2', 'albion-toolkit' ),
                ],
                'default' => '1',
            ]
        );

        $this->add_control(
            'section_show',
            [
                'label' => esc_html__( 'Section Show?', 'albion-toolkit' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Show', 'albion-toolkit' ),
                'label_off' => esc_html__( 'Hide', 'albion-toolkit' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'section_title',
            [
                'label'=>esc_html__('Title', 'albion-toolkit'),
                'type'=>Controls_Manager:: WYSIWYG,
                'condition' => [
                    'section_show' => 'yes',
                ],
                'description' => esc_html__('This text editor for h1 to h6 html tag','albion-toolkit'),
            ]
        );

        $this->add_control(
            'section_desc',
            [
                'label'=>esc_html__('Description', 'albion-toolkit'),
                'type'=>Controls_Manager:: WYSIWYG,
                'condition' => [
                    'section_show' => 'yes',
                ],
                'description' => esc_html__('This text editor for p, ul - ol list tag','albion-toolkit'),
            ]
        );

        $this->add_control(
            'count',
            [
                'label' => esc_html__( 'Post Per Page', 'albion-toolkit' ),
                'default' => esc_html__( '6', 'albion-toolkit' ),
                'type' => Controls_Manager::TEXT,
                'description' => esc_html__('if you went to see all post type -1','albion-toolkit')
            ]
        );
    
        $this->add_control(
            'order',
            [
                'label' => esc_html__( 'Select Order', 'albion-toolkit' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'DESC'  => esc_html__( 'DESC', 'albion-toolkit' ),
                    'ASC'  => esc_html__( 'ASC', 'albion-toolkit' ),
                ],
                'default' => 'DESC',
            ]
        );
        $this->add_control(
            'learn_more_text',
            [
                'label' => esc_html__( 'Learn More Text', 'albion-toolkit' ),
                'type' => Controls_Manager::TEXT,
                'default' => 'Read More',
            ]
        );

        $this->add_control(
			'service_shape',
			[
				'label' => esc_html__( 'Show Shapes', 'albion-toolkit' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'albion-toolkit' ),
				'label_off' => esc_html__( 'Hide', 'albion-toolkit' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
        );

        $this-> end_controls_section();

        // End Tab content controls

        // Start Style content controls
        $this-> start_controls_section(
            'content_style',
            [
                'label'=>esc_html__('Content', 'albion-toolkit'),
                'tab'=> Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
			'title_style',
			[
				'label' => esc_html__( 'Title', 'albion-toolkit' ),
                'type' => Controls_Manager::HEADING,
                'condition' => [
                    'section_show' => 'yes',
                ]
			]
        );

        $this->add_control(
            'title_color',
            [
                'label' => esc_html__( 'Color', 'albion-toolkit' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .section-title h2' => 'color: {{VALUE}}',
                ],
                'condition' => [
                    'section_show' => 'yes',
                ]
            ]
        );

        $this->add_responsive_control(
			'title_font_size',
			[
				'label' => esc_html__( 'Font Size', 'albion-toolkit' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 60,
					],
                ],
                'devices' => [ 'desktop', 'tablet', 'mobile' ],
                'unit' => 'px',
				'selectors' => [
					'{{WRAPPER}} .section-title h2' => 'font-size: {{SIZE}}{{UNIT}}',
                ],
                'condition' => [
                    'section_show' => 'yes',
                ]
			]
        );

        $this->add_control(
			'desc_style',
			[
				'label' => esc_html__( 'Description', 'albion-toolkit' ),
                'type' => Controls_Manager::HEADING,
                'condition' => [
                    'section_show' => 'yes',
                ]
			]
        );

        $this->add_control(
            'desc_color',
            [
                'label' => esc_html__( 'Color', 'albion-toolkit' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .section-title p' => 'color: {{VALUE}}',
                ],
                'condition' => [
                    'section_show' => 'yes',
                ]
            ]
        );

        $this->add_responsive_control(
			'desc_size',
			[
				'label' => esc_html__( 'Font Size', 'albion-toolkit' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 30,
					],
                ],
                'devices' => [ 'desktop', 'tablet', 'mobile' ],
                'unit' => 'px',
				'selectors' => [
					'{{WRAPPER}} .section-title p' => 'font-size: {{SIZE}}{{UNIT}}',
                ],
                'condition' => [
                    'section_show' => 'yes',
                ]
			]
        );

        $this->add_control(
			'card_style',
			[
				'label' => esc_html__( 'Services Style', 'albion-toolkit' ),
				'type' => Controls_Manager::HEADING,
			]
        );

        $this->add_control(
            'service_title',
            [
                'label' => esc_html__( 'Title Color', 'albion-toolkit' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .single-services-box h3 a, .services-tab-list .tabs li a' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_responsive_control(
			'service_title_size',
			[
				'label' => esc_html__( 'Font Size', 'albion-toolkit' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 35,
					],
                ],
                'devices' => [ 'desktop', 'tablet', 'mobile' ],
                'unit' => 'px',
				'selectors' => [
					'{{WRAPPER}} .single-services-box h3, .services-tab-list .tabs li a' => 'font-size: {{SIZE}}{{UNIT}}',
                ],
			]
        );

        $this->add_control(
            'service_para',
            [
                'label' => esc_html__( 'Content Color', 'albion-toolkit' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .single-services-box p, p' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_responsive_control(
			'service_para_size',
			[
				'label' => esc_html__( 'Content Font Size', 'albion-toolkit' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 20,
					],
                ],
                'devices' => [ 'desktop', 'tablet', 'mobile' ],
                'unit' => 'px',
				'selectors' => [
					'{{WRAPPER}} .single-services-box p, p' => 'font-size: {{SIZE}}{{UNIT}}',
                ],
			]
        );

        $this-> end_controls_section();
        // End Style content controls

    }
    // Register control section end here

    protected function render()
    {
        // Retrieve all controls value
        $settings = $this->get_settings_for_display();

        $args = array(
            'post_type' => 'service',
            'posts_per_page' => $settings['count'],
            'order' => $settings['order']
        );

        $services_array = new \WP_Query( $args ); ?>

        <!-- Start Services Area -->
        <?php if( $settings['choose_type'] == 1 ) { ?>
            <div class="services-area ptb-110">
                <div class="container">
                    <?php 
                    if ( 'yes' === $settings['section_show'] ) { ?>
                        <div class="section-title">
                            <?php echo wp_kses_post($settings['section_title']); ?>
                            <?php echo wp_kses_post($settings['section_desc']); ?>
                        </div>
                    <?php } ?>

                    <div class="row"> <?php

                    while($services_array->have_posts()): $services_array->the_post();
                        // ACF field access
                        if (class_exists( 'ACF') && get_field('choose_icon')){
                            $icon = get_field('choose_icon');
                        }else{
                            $icon = '';
                        } ?>
                        <div class="col-lg-4 col-md-6 col-sm-6">
                            <div class="single-services-box">
                                <div class="icon">
                                    <i class="<?php echo esc_attr($icon); ?>"></i>
                                </div>

                                <h3><a href="<?php echo esc_url(get_the_permalink(), 'albion-toolkit'); ?>"><?php the_title(); ?></a></h3>
                                <p><?php echo esc_html( wp_trim_words( get_the_excerpt(), 24, '' ) ); ?></p>
                            </div>
                        </div>
                        <?php
                        endwhile;
                        wp_reset_query();
                        ?>
                    </div>
                </div>
                <?php if ( 'yes' === $settings['service_shape'] ) { ?>
                    <div class="shape-img2">
                        <img src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/shape/2.svg' ); ?>" alt="<?php echo esc_attr__( 'Shape', 'albion-toolkit' ); ?>">
                    </div>
                    <div class="shape-img3">
                        <img src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/shape/3.png' ); ?>" alt="<?php echo esc_attr__( 'Shape', 'albion-toolkit' ); ?>">
                    </div>
                    <div class="shape-img4">
                        <img src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/shape/4.svg' ); ?>" alt="<?php echo esc_attr__( 'Shape', 'albion-toolkit' ); ?>">
                    </div>
                    <div class="shape-img5">
                        <img src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/shape/5.svg' ); ?>" alt="<?php echo esc_attr__( 'Shape', 'albion-toolkit' ); ?>">
                    </div>
                    <div class="shape-img7">
                        <img src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/shape/3.png' ); ?>" alt="<?php echo esc_attr__( 'Shape', 'albion-toolkit' ); ?>">
                    </div>
                    <div class="dot-shape1">
                        <img src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/shape/dot1.png' ); ?>" alt="<?php echo esc_attr__( 'Shape', 'albion-toolkit' ); ?>">
                    </div>
                    <div class="dot-shape2">
                        <img src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/shape/dot3.png' ); ?>" alt="<?php echo esc_attr__( 'Shape', 'albion-toolkit' ); ?>">
                    </div>
                    <div class="dot-shape4">
                        <img src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/shape/dot4.png' ); ?>" alt="<?php echo esc_attr__( 'Shape', 'albion-toolkit' ); ?>">
                    </div>
                    <div class="dot-shape5">
                        <img src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/shape/dot5.png' ); ?>" alt="<?php echo esc_attr__( 'Shape', 'albion-toolkit' ); ?>">
                    </div>
                    <div class="dot-shape6">
                        <img src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/shape/dot6.png' ); ?>" alt="<?php echo esc_attr__( 'Shape', 'albion-toolkit' ); ?>">
                    </div><?php
                } ?>
            </div><?php
        } else { ?>
            <div class="services-section ptb-110">
                <div class="container">
                    <?php 
                    if ( 'yes' === $settings['section_show'] ) { ?>
                        <div class="section-title">
                            <?php echo wp_kses_post($settings['section_title']); ?>
                            <?php echo wp_kses_post($settings['section_desc']); ?>
                        </div>
                    <?php } ?>

                    <div class="tab services-tab-list">
                        <div class="row">
                            <div class="col-lg-4 col-md-4">
                                <ul class="tabs">
                                    <?php while($services_array->have_posts()): $services_array->the_post();
                                        // ACF field access
                                        if (class_exists( 'ACF') && get_field('choose_icon')){
                                            $icon = get_field('choose_icon');
                                        }else{
                                            $icon = '';
                                        } ?>

                                        <li><a href="#">
                                            <i class="<?php echo esc_attr($icon); ?>"></i>
                                            <?php the_title(); ?>
                                        </a></li> 
                                    <?php
                                    endwhile;
                                    wp_reset_query();
                                    ?>
                                </ul>
                            </div>

                            <div class="col-lg-8 col-md-8">
                                <div class="tab-content">
                                    <?php while($services_array->have_posts()): $services_array->the_post(); ?>
                                        <div class="tabs-item">
                                            <div class="image">
                                                <img src="<?php the_post_thumbnail_url('full') ?>" alt="<?php echo esc_attr__('image', 'albion-toolkit')?>">
                                            </div>

                                            <div class="content">
                                                <p><?php the_excerpt(); ?></p>
                                                <a href="<?php echo esc_url(get_the_permalink(), 'albion-toolkit'); ?>" class="btn btn-primary"><?php echo esc_html( $settings['learn_more_text'] ); ?></a>
                                            </div>
                                        </div>
                                    <?php endwhile;
                                    wp_reset_query();
                                    ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <?php if ( 'yes' === $settings['service_shape'] ) { ?>
                    <div class="shape-img1">
                        <img src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/shape/1.png' ); ?>" alt="<?php echo esc_attr__( 'Shape', 'albion-toolkit' ); ?>">
                    </div>
                    <div class="shape-img3">
                        <img src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/shape/3.png' ); ?>" alt="<?php echo esc_attr__( 'Shape', 'albion-toolkit' ); ?>">
                    </div>
                    <div class="shape-img2">
                        <img src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/shape/2.svg' ); ?>" alt="<?php echo esc_attr__( 'Shape', 'albion-toolkit' ); ?>">
                    </div>
                    <div class="shape-img5">
                        <img src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/shape/5.svg' ); ?>" alt="<?php echo esc_attr__( 'Shape', 'albion-toolkit' ); ?>">
                    </div>
                    <div class="shape-img4">
                        <img src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/shape/4.svg' ); ?>" alt="<?php echo esc_attr__( 'Shape', 'albion-toolkit' ); ?>">
                    </div>
                    <div class="dot-shape1">
                        <img src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/shape/dot1.png' ); ?>" alt="<?php echo esc_attr__( 'Shape', 'albion-toolkit' ); ?>">
                    </div>
                    <div class="dot-shape2">
                        <img src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/shape/dot3.png' ); ?>" alt="<?php echo esc_attr__( 'Shape', 'albion-toolkit' ); ?>">
                    </div><?php
                } ?>
            </div><?php 
        } ?>
        
        <!-- End Services Area -->
        <?php
    }

    protected function _content_template() {}
}
Plugin::instance()->widgets_manager->register_widget_type( new ServiceWidget );