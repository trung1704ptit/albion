<?php
namespace Elementor;
class BannerWidget extends Widget_Base{
    public function get_name(){
        return "albion-widget";
    }
    public function get_title(){
        return "Banner Section";
    }
    public function get_icon(){
        return "eicon-banner";
    }
    public function get_categories(){
        return ['albioncategory'];
    }

    protected function _register_controls(){
        // Tab content controls
        $this-> start_controls_section(
            'section_content',
            [
                'label'=>esc_html__('Content', 'albion-toolkit'),
                'tab'=> Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'choose_type',
            [
                'label' => esc_html__( 'Choose Style', 'albion-toolkit' ),
                'type' => Controls_Manager::SELECT,
                'label_block' => true,
                'options' => [
                    '1'  => esc_html__( 'Style 1', 'albion-toolkit' ),
                    '2' => esc_html__( 'Style 2', 'albion-toolkit' ),
                    '3' => esc_html__( 'Style 3', 'albion-toolkit' ),
                ],
                'default' => '1',
            ]
        );

        $this->add_control(
            'banner_bg_image',
            [
                'label' => esc_html__('Banner Background Image', 'albion-toolkit' ),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $this->add_control(
            'banner_title',
            [
                'label'=>esc_html__('Title', 'albion-toolkit'),
                'type'=>Controls_Manager:: WYSIWYG,
                'description' => esc_html__('This text editor for h1 to h6 html tag','albion-toolkit'),
            ]
        );

        $this->add_control(
            'banner_desc',
            [
                'label'=>esc_html__('Description', 'albion-toolkit'),
                'type'=>Controls_Manager:: WYSIWYG,
                'description' => esc_html__('This text editor for p, ul - ol list tag','albion-toolkit'),
            ]
        );

        // Popover (group controls)
        $this->add_control(
            'button_popover',
            [
                'label' => esc_html__( 'Button', 'albion-toolkit' ),
                'type' => Controls_Manager::POPOVER_TOGGLE,
            ]
        );
        $this->start_popover();

        $this->add_control(
            'schedule_button_text',
            [
                'label'=>esc_html__('Schedule Button Text', 'albion-toolkit'),
                'type'=>Controls_Manager:: TEXT,
            ]
        );

        $this->add_control(
            'link_type',
            [
                'label' => esc_html__( 'Schedule Link Type', 'albion-toolkit' ),
                'type' => Controls_Manager::SELECT,
                'label_block' => true,
                'options' => [
                    '1'  => esc_html__( 'Link To Page', 'albion-toolkit' ),
                    '2' => esc_html__( 'External Link', 'albion-toolkit' ),
                ], 
            ]
        );

        $this->add_control(
            'link_to_page',
            [
                'label' => esc_html__( 'Link Page', 'albion-toolkit' ),
                'type' => Controls_Manager::SELECT,
                'label_block' => true,
                'options' => albion_toolkit_get_page_as_list(),
                'condition' => [
                    'link_type' => '1',
                ]
            ]
        );

        $this->add_control(
            'external_link',
            [
                'label'=>esc_html__('External Link', 'albion-toolkit'),
                'type'=>Controls_Manager:: TEXT,
                'condition' => [
                    'link_type' => '2',
                ]
            ]
        );

        $this->add_control(
            'started_button_text',
            [
                'label'=>esc_html__('Get Started Button Text', 'albion-toolkit'),
                'type'=>Controls_Manager:: TEXT,
            ]
        );

        $this->add_control(
            'started_link_type',
            [
                'label' => esc_html__( 'Link Type', 'albion-toolkit' ),
                'type' => Controls_Manager::SELECT,
                'label_block' => true,
                'options' => [
                    '1'  => esc_html__( 'Link To Page', 'albion-toolkit' ),
                    '2' => esc_html__( 'External Link', 'albion-toolkit' ),
                ], 
            ]
        );

        $this->add_control(
            'started_link_to_page',
            [
                'label' => esc_html__( 'Link Page', 'albion-toolkit' ),
                'type' => Controls_Manager::SELECT,
                'label_block' => true,
                'options' => albion_toolkit_get_page_as_list(),
                'condition' => [
                    'started_link_type' => '1',
                ]
            ]
        );

        $this->add_control(
            'started_ex_link',
            [
                'label'=>esc_html__('External Link', 'albion-toolkit'),
                'type'=>Controls_Manager:: TEXT,
                'condition' => [
                    'started_link_type' => '2',
                ]
            ]
        );

        $this->end_popover();

        $this->add_control(
			'services_post',
			[
				'label' => esc_html__( 'Featured Services', 'albion-toolkit' ),
                'type' => Controls_Manager::HEADING,
                'condition' => [
                    'choose_type' => '1',
                ]
			]
        );

        $this->add_control(
            'cat_name',
            [
                'label' => esc_html__( 'Select Category', 'albion-toolkit' ),
                'type' => Controls_Manager::SELECT,
                'options' => albion_toolkit_get_service_cat_list(),
                'description' => esc_html__('This Post shows 3 or less than 3 posts.','albion-toolkit'),
                'condition' => [
                    'choose_type' => '1',
                ]
            ]
        );
    
        $this->add_control(
            'order',
            [
                'label' => esc_html__( 'Select Order', 'albion-toolkit' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'DESC'  => esc_html__( 'DESC', 'albion-toolkit' ),
                    'ASC'  => esc_html__( 'ASC', 'albion-toolkit' ),
                ],
                'default' => 'DESC',
                'condition' => [
                    'choose_type' => '1',
                ]
            ]
        );

        $this->add_control(
			'banner_shape',
			[
				'label' => esc_html__( 'Show Shapes', 'albion-toolkit' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'albion-toolkit' ),
				'label_off' => esc_html__( 'Hide', 'albion-toolkit' ),
				'return_value' => 'yes',
                'default' => 'yes',
                'condition' => [
                    'choose_type!' => '1',
                ]
			]
        );

        $this->add_control(
			'banner_inner_shape',
			[
				'label' => esc_html__( 'Show Banner Right Shapes', 'albion-toolkit' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'albion-toolkit' ),
				'label_off' => esc_html__( 'Hide', 'albion-toolkit' ),
				'return_value' => 'yes',
                'default' => 'yes',
                'condition' => [
                    'choose_type!' => '1',
                ]
			]
        );

        $this-> end_controls_section();

        // End Tab content controls

        // Start Style content controls
        $this-> start_controls_section(
            'content_style',
            [
                'label'=>esc_html__('Content', 'albion-toolkit'),
                'tab'=> Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
			'title_style',
			[
				'label' => esc_html__( 'Title', 'albion-toolkit' ),
				'type' => Controls_Manager::HEADING,
			]
        );

        $this->add_control(
            'title_color',
            [
                'label' => esc_html__( 'Color', 'albion-toolkit' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .main-banner-content h1, .banner-content h1, .hero-banner-content h1' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_responsive_control(
			'title_font_size',
			[
				'label' => esc_html__( 'Font Size', 'albion-toolkit' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 80,
					],
                ],
                'devices' => [ 'desktop', 'tablet', 'mobile' ],
                'unit' => 'px',
				'selectors' => [
					'{{WRAPPER}} .main-banner-content h1, .banner-content h1, .hero-banner-content h1' => 'font-size: {{SIZE}}{{UNIT}}',
                ],
			]
        );

        $this->add_control(
			'desc_style',
			[
				'label' => esc_html__( 'Description', 'albion-toolkit' ),
				'type' => Controls_Manager::HEADING,
			]
        );

        $this->add_control(
            'desc_color',
            [
                'label' => esc_html__( 'Color', 'albion-toolkit' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .main-banner-content p, .banner-content p, .hero-banner-content p' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_responsive_control(
			'desc_size',
			[
				'label' => esc_html__( 'Font Size', 'albion-toolkit' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 20,
					],
                ],
                'devices' => [ 'desktop', 'tablet', 'mobile' ],
                'unit' => 'px',
				'selectors' => [
					'{{WRAPPER}} .main-banner-content p, .banner-content p, .hero-banner-content p' => 'font-size: {{SIZE}}{{UNIT}}',
                ],
			]
        );

        $this->add_control(
            'btn_color',
            [
                'label' => esc_html__( 'Button Color', 'albion-toolkit' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .btn-primary' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'started_btn_color',
            [
                'label' => esc_html__( 'Get Started Button Color', 'albion-toolkit' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .main-banner-content .btn-box .optional-btn, .banner-content .btn-box .optional-btn, .hero-banner-content .btn-box .optional-btn' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
			'featured_style',
			[
				'label' => esc_html__( 'Featured Services', 'albion-toolkit' ),
                'type' => Controls_Manager::HEADING,
                'condition' => [
                    'choose_type' => '1',
                ]
			]
        );

        $this->add_control(
            'featured_icon',
            [
                'label' => esc_html__( 'Icon Color', 'albion-toolkit' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .single-featured-services-box .icon' => 'color: {{VALUE}}',
                ],
                'condition' => [
                    'choose_type' => '1',
                ]
            ]
        );

        $this->add_control(
            'featured_title',
            [
                'label' => esc_html__( 'Title Color', 'albion-toolkit' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .single-featured-services-box h3 a' => 'color: {{VALUE}}',
                ],
                'condition' => [
                    'choose_type' => '1',
                ]
            ]
        );

        $this->add_responsive_control(
			'featured_title_size',
			[
				'label' => esc_html__( 'Font Size', 'albion-toolkit' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 50,
					],
                ],
                'devices' => [ 'desktop', 'tablet', 'mobile' ],
                'unit' => 'px',
				'selectors' => [
					'{{WRAPPER}} .single-featured-services-box h3' => 'font-size: {{SIZE}}{{UNIT}}',
                ],
                'condition' => [
                    'choose_type' => '1',
                ]
			]
        );

        $this->add_control(
            'featured_para',
            [
                'label' => esc_html__( 'Content Color', 'albion-toolkit' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .single-featured-services-box p' => 'color: {{VALUE}}',
                ],
                'condition' => [
                    'choose_type' => '1',
                ]
            ]
        );

        $this->add_responsive_control(
			'featured_para_size',
			[
				'label' => esc_html__( 'Content Font Size', 'albion-toolkit' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 20,
					],
                ],
                'devices' => [ 'desktop', 'tablet', 'mobile' ],
                'unit' => 'px',
				'selectors' => [
					'{{WRAPPER}} .single-featured-services-box p' => 'font-size: {{SIZE}}{{UNIT}}',
                ],
                'condition' => [
                    'choose_type' => '1',
                ]
			]
        );

        $this->add_control(
            'featured_icon_hover',
            [
                'label' => esc_html__( 'Icon Hover And Active Color', 'albion-toolkit' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .single-featured-services-box:hover .icon, .single-featured-services-box.active .icon' => 'color: {{VALUE}}',
                ],
                'condition' => [
                    'choose_type' => '1',
                ]
            ]
        );

        $this->add_control(
            'featured_card_hover',
            [
                'label' => esc_html__( 'Card Hover And Active Color', 'albion-toolkit' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .single-featured-services-box::before' => 'background-color: {{VALUE}}',
                ],
                'condition' => [
                    'choose_type' => '1',
                ]
            ]
        );

        $this-> end_controls_section();
        // End Style content controls

    }
    // Register control section end here

    protected function render()
    {
        // Retrieve all controls value
        $settings = $this->get_settings_for_display();

        if( $settings['cat_name'] != '' ):
            $args = array(
                'post_type' => 'service',
                'posts_per_page' => 3,
                'order' => $settings['order'],
                'tax_query' => array(
                    array(
                        'taxonomy' => 'service_cat',
                        'field' => 'slug',
                        'terms' => $settings['cat_name'],
                        'hide_empty' => false
                    )
                )
            );
        else:
            $args = array(
                'post_type' => 'service',
                'posts_per_page' => 3,
                'order' => $settings['order'],
            );
        endif;

        $services_array = new \WP_Query( $args );

        // Schedule Button Link
        $schedule_link = '';
        if($settings['link_type'] == 1){
            $schedule_link = get_page_link($settings['link_to_page']); 
        } else {
            $schedule_link = $settings['external_link'];
        }

        // Get Started Button Link
        $started_link = '';
        if($settings['started_link_type'] == 1){
            $started_link = get_page_link($settings['started_link_to_page']); 
        } else {
            $started_link = $settings['started_ex_link'];
        } ?>

        <!-- Start Main Banner Area -->
        <?php
            if( $settings['choose_type'] == 1 ) { ?>
                <div class="main-banner" style="background-image: url(<?php echo esc_url( $settings['banner_bg_image']['url']); ?> )">
                    <div class="d-table">
                        <div class="d-table-cell">
                            <div class="container-fluid">
                                <div class="main-banner-content">
                                    <?php echo wp_kses_post($settings['banner_title']); ?>
                                    <?php echo wp_kses_post($settings['banner_desc']); ?>

                                    <?php
                                    if($settings['schedule_button_text'] !='' || $settings['started_button_text'] !=''){ ?>
                                    <div class="btn-box">
                                        <a href="<?php echo esc_url($schedule_link); ?>" class="btn btn-primary"><?php echo esc_html($settings['schedule_button_text']); ?></a>

                                        <a href="<?php echo esc_url($started_link); ?>" class="optional-btn"><?php echo esc_html($settings['started_button_text']); ?></a>
                                    </div> <?php
                                    } ?>

                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="featured-services-area">
                        <div class="container">
                            <div class="row"> <?php
                            $loop = 1;
                            while($services_array->have_posts()): $services_array->the_post();
                                // ACF field access
                                if (class_exists( 'ACF') && get_field('choose_icon')){
                                    $icon = get_field('choose_icon');
                                }else{
                                    $icon = '';
                                }
                                if (class_exists( 'ACF') && get_field('card_active')){
                                    $active = "active";
                                }else{
                                    $active = '';
                                } 
                                // Grid
                                if($loop == 3){
                                    $col_cls = "col-lg-4 col-md-6 col-sm-6 offset-lg-0 offset-md-3 offset-sm-3";
                                } else {
                                    $col_cls = "col-lg-4 col-md-6 col-sm-6";
                                } ?>
                                <div class="<?php echo esc_attr($col_cls); ?>">
                                    <div class="single-featured-services-box <?php echo esc_attr($active); ?>">
                                        <div class="icon">
                                            <i class="<?php echo esc_attr($icon); ?>"></i>
                                        </div>

                                        <h3><a href="<?php echo esc_url(get_the_permalink(), 'albion-toolkit'); ?>"><?php the_title(); ?></a></h3>
                                        <p><?php the_excerpt(); ?></p>
                                    </div>
                                </div>
                            <?php
                            $loop++;
                            endwhile;
                            wp_reset_query();
                            ?>
                            </div>
                        </div>
                    </div>
                </div> <?php
            } elseif( $settings['choose_type'] == 2 ) { ?> 
                <div class="banner-section" style="background-image: url(<?php echo esc_url( $settings['banner_bg_image']['url']); ?> )">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="banner-content">
                                    <?php echo wp_kses_post($settings['banner_title']); ?>
                                    <?php echo wp_kses_post($settings['banner_desc']); ?>

                                    <?php if($settings['schedule_button_text'] !='' || $settings['started_button_text'] !=''){ ?>
                                        <div class="btn-box">
                                            <a href="<?php echo esc_url($schedule_link); ?>" class="btn btn-primary"><?php echo esc_html($settings['schedule_button_text']); ?></a>

                                            <a href="<?php echo esc_url($started_link); ?>" class="optional-btn"><?php echo esc_html($settings['started_button_text']); ?></a>
                                        </div> <?php
                                    } ?>
                                </div>
                            </div>

                            <?php if ( 'yes' === $settings['banner_inner_shape'] ) { ?>
                                <div class="col-lg-6">
                                    <div class="banner-image">
                                        <img src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/banner/1.png' ); ?>" alt="<?php echo esc_attr__( 'shape1', 'albion-toolkit' ); ?>">
                                        <img src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/banner/2.png' ); ?>" class="wow fadeIn" data-wow-delay="0.8s" alt="<?php echo esc_attr__( 'shape2', 'albion-toolkit' ); ?>">
                                        <img src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/banner/3.png' ); ?>" class="wow fadeInUp" data-wow-delay="0.8s" alt="<?php echo esc_attr__( 'shape3', 'albion-toolkit' ); ?>">

                                        <img src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/banner/4.png' ); ?>" class="wow fadeInLeft" data-wow-delay="0.8s" alt="<?php echo esc_attr__( 'shape4', 'albion-toolkit' ); ?>">

                                        <img src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/banner/5.png' ); ?>" class="wow fadeInLeft" data-wow-delay="0.8s" alt="<?php echo esc_attr__( 'shape5', 'albion-toolkit' ); ?>">
                                        <img src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/banner/6.png' ); ?>" class="wow fadeInUp" data-wow-delay="0.8s" alt="<?php echo esc_attr__( 'shape6', 'albion-toolkit' ); ?>">
                                        <img src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/banner/7.png' ); ?>" class="wow fadeIn" data-wow-delay="1s" alt="<?php echo esc_attr__( 'shape7', 'albion-toolkit' ); ?>">
                                        <img src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/banner/8.png' ); ?>" class="wow fadeInDown" data-wow-delay="0.3s" alt="<?php echo esc_attr__( 'shape8', 'albion-toolkit' ); ?>">
                                        <img src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/banner-image.png' ); ?>" class="main-pic wow fadeInUp" data-wow-delay="0.8s" alt="<?php echo esc_attr__( 'shape9', 'albion-toolkit' ); ?>">
                                    </div>
                                </div> <?php
                            } ?>

                        </div>
                    </div>

                    <?php if ( 'yes' === $settings['banner_shape'] ) { ?>
                        <div class="shape-img2">
                            <img src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/shape/2.svg' ); ?>" alt="<?php echo esc_attr__( 'About Shape', 'albion-toolkit' ); ?>">
                        </div>
                        <div class="shape-img3">
                            <img src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/shape/3.png' ); ?>" alt="<?php echo esc_attr__( 'About Shape', 'albion-toolkit' ); ?>">
                        </div>
                        <div class="shape-img5">
                            <img src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/shape/5.svg' ); ?>" alt="<?php echo esc_attr__( 'About Shape', 'albion-toolkit' ); ?>">
                        </div>
                        <div class="dot-shape1">
                            <img src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/shape/dot1.png' ); ?>" alt="<?php echo esc_attr__( 'About Shape', 'albion-toolkit' ); ?>">
                        </div>
                        <div class="dot-shape2">
                            <img src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/shape/dot3.png' ); ?>" alt="<?php echo esc_attr__( 'About Shape', 'albion-toolkit' ); ?>">
                        </div>

                    <?php } ?>

                </div>
                <?php
            } else { ?>
                <div class="hero-banner" style="background-image: url(<?php echo esc_url( $settings['banner_bg_image']['url']); ?> )">
                    <div class="container-fluid">
                        <div class="row align-items-center">
                            <div class="col-lg-6">
                                <div class="hero-banner-content">
                                    <?php echo wp_kses_post($settings['banner_title']); ?>
                                    <?php echo wp_kses_post($settings['banner_desc']); ?>

                                    <?php if($settings['schedule_button_text'] !='' || $settings['started_button_text'] !=''){ ?>
                                        <div class="btn-box">
                                            <a href="<?php echo esc_url($schedule_link); ?>" class="btn btn-primary"><?php echo esc_html($settings['schedule_button_text']); ?></a>

                                            <a href="<?php echo esc_url($started_link); ?>" class="optional-btn"><?php echo esc_html($settings['started_button_text']); ?></a>
                                        </div> <?php
                                    } ?>
                                </div>
                            </div>

                            <?php if ( 'yes' === $settings['banner_inner_shape'] ) { ?>
                                <div class="col-lg-6">
                                    <div class="hero-banner-image">
                                        <img src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/banner-image.png' ); ?>" class="wow zoomInUp" data-wow-delay="1s" alt="<?php echo esc_attr__( 'shape1', 'albion-toolkit' ); ?>">
                                    </div>
                                </div> <?php
                            } ?>
                        </div>

                    </div>

                    <?php if ( 'yes' === $settings['banner_shape'] ) { ?>
                        <div class="shape-img2">
                            <img src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/shape/2.svg' ); ?>" alt="<?php echo esc_attr__( 'About Shape', 'albion-toolkit' ); ?>">
                        </div>
                        <div class="shape-img3">
                            <img src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/shape/3.png' ); ?>" alt="<?php echo esc_attr__( 'About Shape', 'albion-toolkit' ); ?>">
                        </div>
                        <div class="shape-img5">
                            <img src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/shape/5.svg' ); ?>" alt="<?php echo esc_attr__( 'About Shape', 'albion-toolkit' ); ?>">
                        </div>
                        <div class="dot-shape1">
                            <img src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/shape/dot1.png' ); ?>" alt="<?php echo esc_attr__( 'About Shape', 'albion-toolkit' ); ?>">
                        </div>
                        <div class="dot-shape2">
                            <img src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/shape/dot3.png' ); ?>" alt="<?php echo esc_attr__( 'About Shape', 'albion-toolkit' ); ?>">
                        </div>
                    <?php } ?>

                </div> <?php
            } ?>
        <!-- End Main Banner Area -->
        <?php
    }

    protected function _content_template() {}
}
Plugin::instance()->widgets_manager->register_widget_type( new BannerWidget );