<?php
namespace Elementor;
class TeamWidget extends Widget_Base{
    public function get_name(){
        return "team-widget";
    }
    public function get_title(){
        return "Team Widget";
    }
    public function get_icon(){
        return "eicon-gallery-group";
    }
    public function get_categories(){
        return ['albioncategory'];
    }

    protected function _register_controls(){

    // Section controls
    $this-> start_controls_section(
        'albion_section',
        [
            'label'=>esc_html__('Section', 'albion-toolkit'),
            'tab'=> Controls_Manager::TAB_CONTENT,
        ]
    );

    $this->add_control(
        'section_show',
        [
            'label' => esc_html__( 'Section Show?', 'albion-toolkit' ),
            'type' => Controls_Manager::SWITCHER,
            'label_on' => esc_html__( 'Show', 'albion-toolkit' ),
            'label_off' => esc_html__( 'Hide', 'albion-toolkit' ),
            'return_value' => 'yes',
            'default' => 'yes',
        ]
    );

    $this->add_control(
        'section_title',
        [
            'label'=>esc_html__('Title', 'albion-toolkit'),
            'type'=>Controls_Manager:: WYSIWYG,
            'condition' => [
                'section_show' => 'yes',
            ],
            'description' => esc_html__('This text editor for h1 to h6 html tag','albion-toolkit'),
        ]
    );

    $this->add_control(
        'section_desc',
        [
            'label'=>esc_html__('Description', 'albion-toolkit'),
            'type'=>Controls_Manager:: WYSIWYG,
            'condition' => [
                'section_show' => 'yes',
            ],
            'description' => esc_html__('This text editor for p, ul - ol list tag','albion-toolkit'),
        ]
    );

    $this-> end_controls_section();
    // End Section controls

    // Start Partner section
    $this-> start_controls_section(
        'layout_section',
        [
            'label'=>esc_html__('Content', 'albion-toolkit'),
            'tab'=> Controls_Manager::TAB_CONTENT,
        ]
    );

    $repeater = new Repeater();

    $repeater->add_control(
        'member_img', [
            'label' => esc_html__( 'Image', 'albion-toolkit' ),
            'type' => Controls_Manager::MEDIA,
            'label_block' => true,
        ]
    );

    $repeater->add_group_control(
        Group_Control_Image_Size::get_type(),
        [
            'default' =>esc_html__('full','albion-toolkit'),
            'name' => 'imagesz'
        ]
    );

    $repeater->add_control(
        'name',
        [
            'label' => esc_html__( 'Member Name', 'albion-toolkit' ),
            'type' => Controls_Manager::WYSIWYG,
            'description' => esc_html__('This text editor for h1 to h6 html tag','albion-toolkit'),
        ]
    );
    $repeater->add_control(
        'designation',
        [
            'label' => esc_html__( 'Designation', 'albion-toolkit' ),
            'type' => Controls_Manager::TEXT,
        ]
    );
    $repeater->add_control(
        'flat_icon1',
        [
            'label' => esc_html__( 'Choose Social Share One', 'albion-toolkit' ),
            'type' => Controls_Manager::SELECT,
            'options' => [
                'flaticon-facebook-letter-logo'     => esc_html__( 'Facebook', 'albion-toolkit' ),
                'flaticon-twitter-logo-silhouette'  => esc_html__( 'Twitter', 'albion-toolkit' ),
                'flaticon-instagram-logo'           => esc_html__( 'Instagram', 'albion-toolkit' ),
                'flaticon-youtube'                  => esc_html__( 'Youtube', 'albion-toolkit' ),
            ],
        ]
    );
    $repeater->add_control(
        'url1',
        [
            'label' => esc_html__( 'URL', 'albion-toolkit' ),
            'type' => Controls_Manager::TEXT,
        ]
    );
    $repeater->add_control(
        'flat_icon2',
        [
            'label' => esc_html__( 'Choose Social Share Two', 'albion-toolkit' ),
            'type' => Controls_Manager::SELECT,
            'options' => [
                'flaticon-facebook-letter-logo'     => esc_html__( 'Facebook', 'albion-toolkit' ),
                'flaticon-twitter'  => esc_html__( 'Twitter', 'albion-toolkit' ),
                'flaticon-instagram-logo'           => esc_html__( 'Instagram', 'albion-toolkit' ),
                'flaticon-youtube'                  => esc_html__( 'Youtube', 'albion-toolkit' ),
            ],
        ]
    );
    $repeater->add_control(
        'url2',
        [
            'label' => esc_html__( 'URL', 'albion-toolkit' ),
            'type' => Controls_Manager::TEXT,
        ]
    );
    $repeater->add_control(
        'flat_icon3',
        [
            'label' => esc_html__( 'Choose Social Share Three', 'albion-toolkit' ),
            'type' => Controls_Manager::SELECT,
            'options' => [
                'flaticon-facebook-letter-logo'     => esc_html__( 'Facebook', 'albion-toolkit' ),
                'flaticon-twitter'                  => esc_html__( 'Twitter', 'albion-toolkit' ),
                'flaticon-instagram-logo'           => esc_html__( 'Instagram', 'albion-toolkit' ),
                'flaticon-youtube-play-button'      => esc_html__( 'Youtube', 'albion-toolkit' ),
            ],
        ]
    );
    $repeater->add_control(
        'url3',
        [
            'label' => esc_html__( 'URL', 'albion-toolkit' ),
            'type' => Controls_Manager::TEXT,
        ]
    );

    $this->add_control(
        'teams',
        [
            'label' => esc_html__( 'Add Team Information', 'albion-toolkit' ),
            'type' => Controls_Manager::REPEATER,
            'fields' => $repeater->get_controls(),
        ]
    );
    $this-> end_controls_section();

    // Start Style content controls
    $this-> start_controls_section(
        'heading_style',
        [
            'label'=>esc_html__('Section Heading', 'albion-toolkit'),
            'tab'=> Controls_Manager::TAB_STYLE,
            'condition' => [
                'section_show' => 'yes',
            ]
        ]
    );

    $this->add_control(
        'title_style',
        [
            'label' => esc_html__( 'Title', 'albion-toolkit' ),
            'type' => Controls_Manager::HEADING,
        ]
    );

    $this->add_control(
        'title_color',
        [
            'label' => esc_html__( 'Color', 'albion-toolkit' ),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .section-title h2' => 'color: {{VALUE}}',
            ],
        ]
    );

    $this->add_responsive_control(
        'title_font_size',
        [
            'label' => esc_html__( 'Font Size', 'albion-toolkit' ),
            'type' => Controls_Manager::SLIDER,
            'range' => [
                'px' => [
                    'min' => 0,
                    'max' => 60,
                ],
            ],
            'devices' => [ 'desktop', 'tablet', 'mobile' ],
            'unit' => 'px',
            'selectors' => [
                '{{WRAPPER}} .section-title h2' => 'font-size: {{SIZE}}{{UNIT}}',
            ],
        ]
    );

    $this->add_control(
        'desc_style',
        [
            'label' => esc_html__( 'Description', 'albion-toolkit' ),
            'type' => Controls_Manager::HEADING,
        ]
    );

    $this->add_control(
        'desc_color',
        [
            'label' => esc_html__( 'Color', 'albion-toolkit' ),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .section-title p' => 'color: {{VALUE}}',
            ],
        ]
    );

    $this->add_responsive_control(
        'desc_size',
        [
            'label' => esc_html__( 'Font Size', 'albion-toolkit' ),
            'type' => Controls_Manager::SLIDER,
            'range' => [
                'px' => [
                    'min' => 0,
                    'max' => 30,
                ],
            ],
            'devices' => [ 'desktop', 'tablet', 'mobile' ],
            'unit' => 'px',
            'selectors' => [
                '{{WRAPPER}} .section-title p' => 'font-size: {{SIZE}}{{UNIT}}',
            ],
        ]
    );

    $this-> end_controls_section();
    // End Style section controls

    // Start Style content controls
    $this-> start_controls_section(
        'team_style',
        [
            'label'=>esc_html__('Content', 'albion-toolkit'),
            'tab'=> Controls_Manager::TAB_STYLE,
        ]
    );

    $this->add_control(
        'member_name',
        [
            'label' => esc_html__( 'Member Name', 'albion-toolkit' ),
            'type' => Controls_Manager::HEADING,
        ]
    );
    $this->add_control(
        'name_color',
        [
            'label' => esc_html__( 'Color', 'albion-toolkit' ),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .single-team-box .content h3' => 'color: {{VALUE}}',
            ],
        ]
    );
    $this->add_responsive_control(
        'name_sz',
        [
            'label' => esc_html__( 'Font Size', 'albion-toolkit' ),
            'type' => Controls_Manager::SLIDER,
            'range' => [
                'px' => [
                    'min' => 0,
                    'max' => 40,
                ],
            ],
            'devices' => [ 'desktop', 'tablet', 'mobile' ],
            'unit' => 'px',
            'selectors' => [
                '{{WRAPPER}} .single-team-box .content h3' => 'font-size: {{SIZE}}{{UNIT}}',
            ],
        ]
    );
    $this->add_control(
        'member_desig',
        [
            'label' => esc_html__( 'Member Designation', 'albion-toolkit' ),
            'type' => Controls_Manager::HEADING,
        ]
    );
    $this->add_control(
        'desig_color',
        [
            'label' => esc_html__( 'Color', 'albion-toolkit' ),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .single-team-box .content span' => 'color: {{VALUE}}',
            ],
        ]
    );
    $this->add_responsive_control(
        'desig_sz',
        [
            'label' => esc_html__( 'Font Size', 'albion-toolkit' ),
            'type' => Controls_Manager::SLIDER,
            'range' => [
                'px' => [
                    'min' => 0,
                    'max' => 25,
                ],
            ],
            'devices' => [ 'desktop', 'tablet', 'mobile' ],
            'unit' => 'px',
            'selectors' => [
                '{{WRAPPER}} .single-team-box .content span' => 'font-size: {{SIZE}}{{UNIT}}',
            ],
        ]
    );
    $this-> end_controls_section();

    $this-> start_controls_section(
        'team_hover_style',
        [
            'label'=>esc_html__('Card Hover Style', 'albion-toolkit'),
            'tab'=> Controls_Manager::TAB_STYLE,
        ]
    );

    $this->add_control(
        'member_share',
        [
            'label' => esc_html__( 'Social Share', 'albion-toolkit' ),
            'type' => Controls_Manager::HEADING,
        ]
    );
    $this->add_control(
        'share_color',
        [
            'label' => esc_html__( 'Color', 'albion-toolkit' ),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .single-team-box .image .social a' => 'color: {{VALUE}}',
            ],
        ]
    );
    $this->add_control(
        'share_hcolor',
        [
            'label' => esc_html__( 'Hover Color', 'albion-toolkit' ),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .single-team-box .image .social a:hover' => 'color: {{VALUE}}',
            ],
        ]
    );
    $this->add_control(
        'share_bg',
        [
            'label' => esc_html__( 'Background', 'albion-toolkit' ),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .single-team-box .image .social' => 'background-color: {{VALUE}}',
            ],
        ]
    );

    $this->add_control(
        'member_info',
        [
            'label' => esc_html__( 'Member Information', 'albion-toolkit' ),
            'type' => Controls_Manager::HEADING,
        ]
    );
    $this->add_control(
        'member_name_color',
        [
            'label' => esc_html__( 'Name Color', 'albion-toolkit' ),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .single-team-box:hover .content h3' => 'color: {{VALUE}}',
            ],
        ]
    );
    $this->add_control(
        'designation_color',
        [
            'label' => esc_html__( 'Designation Color', 'albion-toolkit' ),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .single-team-box:hover .content span' => 'color: {{VALUE}}',
            ],
        ]
    );
    $this->add_control(
        'box_bg',
        [
            'label' => esc_html__( 'Content Background', 'albion-toolkit' ),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .single-team-box:hover .content' => 'background-color: {{VALUE}}',
            ],
        ]
    );

    $this-> end_controls_section();
    
}
    // Register control section end here

    protected function render() 
    {
        // Retrieve all controls value
        $settings = $this->get_settings_for_display();
        ?>

        <!-- Start Team Area -->
        <div class="team-area ptb-110">
            <div class="container">
            <?php 
            if ( 'yes' === $settings['section_show'] ) { ?>
                <div class="section-title">
                    <?php echo wp_kses_post($settings['section_title']); ?>
                    <?php echo wp_kses_post($settings['section_desc']); ?>
                </div>
            <?php } ?>

                <div class="row">
                <?php
                if ( $settings['teams']!='' ){ 
                    foreach ( $settings['teams'] as $item ) {
                        if($item['name']!='' || $item['member_img']!=''){ ?>
                        <div class="col-lg-3 col-md-6 col-sm-6">
                            <div class="single-team-box">
                                <div class="image">
                                    <?php echo Group_Control_Image_Size::get_attachment_image_html($item,'imagesz','member_img');

                                    if($item['flat_icon1']!='' || $item['flat_icon2']!='' || $item['flat_icon3']!='') { ?>
                                        <div class="social">
                                            <?php
                                                if($item['flat_icon1']!=''){ ?>
                                                    <a href="<?php echo esc_url($item['url1']);?>" target="_blank"><i class="<?php echo esc_attr($item['flat_icon1']);?>"></i></a><?php 
                                                } 
                                                if($item['flat_icon2']!=''){ ?>
                                                    <a href="<?php echo esc_url($item['url2']);?>" target="_blank"><i class="<?php echo esc_attr($item['flat_icon2']);?>"></i></a><?php 
                                                } 
                                                if($item['flat_icon3']!=''){ ?>
                                                    <a href="<?php echo esc_url($item['url3']);?>" target="_blank"><i class="<?php echo esc_attr($item['flat_icon3']);?>"></i></a><?php 
                                                } 
                                            ?>
                                        </div> <?php
                                    } ?>
                                </div>
                                <?php
                                if($item['name'] !='' || $item['designation'] ) { ?>
                                    <div class="content">
                                        <?php echo wp_kses_post($item['name']); ?>
                                        <span><?php echo esc_html($item['designation']);?></span>
                                    </div> <?php
                                } ?>
                                
                            </div>
                        </div><?php
                    } } } ?>
                </div>
            </div>
        </div>
        <!-- End Team Area -->
    <?php    
    }

    protected function _content_template() {}
}
Plugin::instance()->widgets_manager->register_widget_type( new TeamWidget );