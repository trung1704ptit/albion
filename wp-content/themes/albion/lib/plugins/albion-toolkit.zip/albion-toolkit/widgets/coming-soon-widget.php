<?php 
namespace Elementor;
class ComingSoonWidget extends Widget_Base{
    public function get_name(){
        return "coming-soon-widget";
    }
    public function get_title(){
        return "Coming Soon";
    }
    public function get_icon(){
        return "fa fa-creative-commons";
    }
    public function get_categories(){
        return ['albioncategory'];
    }

    protected function _register_controls(){
        // Start Left Content
        $this-> start_controls_section(
            'comingsoon_right',
            [
                'label'=>esc_html__('Right Content', 'albion-toolkit'),
                'tab'=> Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'bg_image',
            [
                'label' => esc_html__('Background Image', 'albion-toolkit' ),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ]
            ]
        );

        $this->add_control(
            'image',
            [
                'label' => esc_html__( 'Image For Responsive Device', 'albion-toolkit' ),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Image_Size::get_type(),
            [
                'default' =>'full',
                'name' => 'imagesz',
            ]
        );
        $this-> end_controls_section();
        // End Left Content

        // Start Right Content
        $this-> start_controls_section(
            'comingsoon_section',
            [
                'label'=>esc_html__('Left Content', 'albion-toolkit'),
                'tab'=> Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'title',
            [
                'label'=> esc_html__('Title','albion-toolkit'),
                'type'=>Controls_Manager:: WYSIWYG,
                'description' => esc_html__('This text editor for h1 to h6 html tag','albion-toolkit'),
            ]
        );
        $this->add_control(
            'fname',
            [
                'label'=> esc_html__('Name Placeholder','albion-toolkit'),
                'type'=>Controls_Manager:: TEXT,
                'default'=> esc_html__('Your Name','albion-toolkit'),
            ]
        );
        $this->add_control(
            'emailadd',
            [
                'label'=> esc_html__('Email Placeholder','albion-toolkit'),
                'type'=>Controls_Manager:: TEXT,
                'default'=> esc_html__('Your Email','albion-toolkit'),
            ]
        );
        $this->add_control(
            'btn',
            [
                'label'=> esc_html__('Button Text','albion-toolkit'),
                'type'=>Controls_Manager:: TEXT,
            ]
        );
        $this->add_control(
            'desc',
            [
                'label'=> esc_html__('Description','albion-toolkit'),
                'type'=>Controls_Manager:: TEXTAREA,
            ]
        );

        $repeater = new Repeater();

        $repeater->add_control(
            'icon',
            [
                'label' => esc_html__( 'Social Icons', 'albion-toolkit' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'fab fa-twitter'  => esc_html__( 'Twitter', 'albion-toolkit' ),
                    'fab fa-youtube'  => esc_html__( 'Youtube', 'albion-toolkit' ),
                    'fab fa-facebook-f'  => esc_html__( 'Facebook', 'albion-toolkit' ),
                    'fab fa-linkedin-in'  => esc_html__( 'Linkedin', 'albion-toolkit' ),
                    'fab fa-instagram'  => esc_html__( 'Instagram', 'albion-toolkit' ),
                ],
            ]
        );
        $repeater->add_control(
            'social_link',
            [
                'label' => esc_html__( 'URL', 'albion-toolkit' ),
                'type' => Controls_Manager::TEXT,
            ]
        );
        $repeater->add_control(
            'social_color',
            [
                'label' => esc_html__( 'Choose Color', 'albion-toolkit' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    '1'  => esc_html__( 'Facebook Color', 'albion-toolkit' ),
                    '2'  => esc_html__( 'Youtube Color', 'albion-toolkit' ),
                    '3'  => esc_html__( 'Twitter Color', 'albion-toolkit' ),
                    '4'  => esc_html__( 'Linkedin Color', 'albion-toolkit' ),
                    '5'  => esc_html__( 'Instagram Color', 'albion-toolkit' ),
                ],
            ]
        );

        $this->add_control(
            'social_list',
            [
                'label' => esc_html__( 'Add Social List', 'albion-toolkit' ),
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
            ]
        );
        $this-> end_controls_section();
        // End Right Content


        $this-> start_controls_section(
            'coming_style',
            [
                'label'=>esc_html__('Content', 'albion-toolkit'),
                'tab'=> Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control(
			'title_style',
			[
				'label' => esc_html__( 'Title', 'albion-toolkit' ),
				'type' => Controls_Manager::HEADING,
			]
        );

        $this->add_control(
            'title_color',
            [
                'label' => esc_html__( 'Color', 'albion-toolkit' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .coming-soon-content h3' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_responsive_control(
			'title_size',
			[
				'label' => esc_html__( 'Font Size', 'albion-toolkit' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 70,
					],
                ],
                'devices' => [ 'desktop', 'tablet', 'mobile' ],
                'unit' => 'px',
				'selectors' => [
					'{{WRAPPER}}  .coming-soon-content h3' => 'font-size: {{SIZE}}{{UNIT}}',
                ],
			]
        );

        $this->add_control(
			'btn_style',
			[
				'label' => esc_html__( 'Button', 'albion-toolkit' ),
				'type' => Controls_Manager::HEADING,
			]
        );

        $this->add_control(
            'btn_color',
            [
                'label' => esc_html__( 'Color', 'albion-toolkit' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .btn-primary' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'btn_bgcolor',
            [
                'label' => esc_html__( 'Background Color', 'albion-toolkit' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .btn-primary' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'btn_hcolor',
            [
                'label' => esc_html__( 'Hover Color', 'albion-toolkit' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .btn-primary:hover, .btn-primary:focus' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'btn_hbgcolor',
            [
                'label' => esc_html__( 'Hover Background Color', 'albion-toolkit' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .btn-primary:hover, .btn-primary:focus' => 'background-color: {{VALUE}} !important',
                ],
            ]
        );

        $this->add_responsive_control(
			'btn_size',
			[
				'label' => esc_html__( 'Font Size', 'albion-toolkit' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 70,
					],
                ],
                'devices' => [ 'desktop', 'tablet', 'mobile' ],
                'unit' => 'px',
				'selectors' => [
					'{{WRAPPER}}  .btn-primary' => 'font-size: {{SIZE}}{{UNIT}}',
                ],
			]
        );
        
        $this->add_control(
			'timer_style',
			[
				'label' => esc_html__( 'Timer', 'albion-toolkit' ),
				'type' => Controls_Manager::HEADING,
			]
        );
        $this->add_control(
            'timer_color',
            [
                'label' => esc_html__( 'Color', 'albion-toolkit' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .coming-soon-area .coming-soon-time #timer div' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_responsive_control(
			'timer_size',
			[
				'label' => esc_html__( 'Font Size', 'albion-toolkit' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 60,
					],
                ],
                'devices' => [ 'desktop', 'tablet', 'mobile' ],
                'unit' => 'px',
				'selectors' => [
					'{{WRAPPER}}  .coming-soon-area .coming-soon-time #timer div' => 'font-size: {{SIZE}}{{UNIT}}',
                ],
			]
        );
        $this-> end_controls_section();

    }

    protected function render() 
    {
    $settings = $this->get_settings_for_display();

    global $albion_opt;

    // Sticky Black Logo
	if(isset($albion_opt['black_logo']['url']) && $albion_opt['black_logo']['url'] !='' ) {
		$black_logo = $albion_opt['black_logo']['url'];
	}else {
		$black_logo = "null";
	} ?>
    
    <div class="coming-soon-area">
        <div class="container-fluid p-0">
            <div class="row m-0">
                <div class="col-lg-6 col-md-12 p-0">
                    <div class="coming-soon-time" style="background-image: url(<?php echo esc_url( $settings['bg_image']['url']); ?> )">
                        <?php echo Group_Control_Image_Size::get_attachment_image_html($settings,'imagesz','image'); ?>

                        <div id="timer">
                            <div id="days"></div>
                            <div id="hours"></div>
                            <div id="minutes"></div>
                            <div id="seconds"></div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-6 col-md-12 p-0">
                    <div class="coming-soon-content">
                        <div class="d-table">
                            <div class="d-table-cell">
                                <div class="logo">
                                    <a href="<?php echo esc_url( home_url( '/' ) ); ?>">
                                        <?php
                                        // Black Logo
                                        if ( $black_logo != 'null' ) { ?>
                                            <img src="<?php echo esc_url($black_logo); ?>" alt="<?php bloginfo( 'title' ); ?>"><?php
                                        }else{ ?>
                                            <h2><?php bloginfo( 'name' ); ?></h2>
                                        <?php }  ?>
                                    </a>
                                </div>

                                <?php echo wp_kses_post($settings['title']); ?>
                                <form class="newsletter-form" data-toggle="validator" method="post" action="<?php echo get_bloginfo();?>/?na=s" onsubmit="return newsletter_check(this)">
                                    <div class="form-group">
                                        <input type="text" class="form-control" name="nn" placeholder="<?php echo esc_attr($settings['fname']);?>" required autocomplete="off">
                                    </div>

                                    <div class="form-group">
                                        <input type="email" class="form-control" placeholder="<?php echo esc_attr($settings['emailadd']);?>" name="ne" required autocomplete="off">
                                    </div>
                                    
                                    <?php 
                                    if($settings['btn']!=''){ ?>
                                        <button type="submit" class="btn btn-primary"><?php echo esc_html($settings['btn']);?></button> <?php
                                    } ?>

                                    <p><?php echo esc_html($settings['desc']);?></p>
                                </form>

                                <div class="social">
                                    <ul>
                                        <?php
                                        if ( $settings['social_list']!='' ){
                                            foreach ( $settings['social_list'] as $item ) {

                                                if ($item['social_color'] == 1) {
                                                    $cls="facebook";
                                                } elseif ($item['social_color'] == 2) {
                                                    $cls="youtube";
                                                } elseif ($item['social_color'] == 3) {
                                                    $cls="twitter";
                                                } elseif ($item['social_color'] == 4) {
                                                    $cls="linkedin";
                                                }else {
                                                    $cls="instagram";
                                                }

                                                if($item['icon']!='') { ?>
                                                <li>
                                                    <a href="<?php echo esc_url( $item['social_link'] ); ?>" target="_blank" class="<?php echo esc_attr( $cls ); ?>"><i class="<?php echo esc_attr( $item['icon'] ); ?>"></i></a>
                                                    
                                                </li><?php
                                        } } }?>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php
    }
    protected function _content_template() {}
}
Plugin::instance()->widgets_manager->register_widget_type( new ComingSoonWidget );