<?php
namespace Elementor;
class SingleServiceWidget extends Widget_Base{
    public function get_name(){
        return "single-service-widget";
    }
    public function get_title(){
        return "Single Service";
    }
    public function get_icon(){
        return "eicon-text";
    }
    public function get_categories(){
        return ['albioncategory'];
    }

    protected function _register_controls(){
        // Tab content controls
        $this-> start_controls_section(
            'service_overview',
            [
                'label'=>esc_html__('Services Overview', 'albion-toolkit'),
                'tab'=> Controls_Manager::TAB_CONTENT,
            ]
        );
        $this->add_control(
            'service_title',
            [
                'label'=>esc_html__('Service Details Title', 'albion-toolkit'),
                'type'=>Controls_Manager:: WYSIWYG,
                'description' => esc_html__('This text editor for h1 to h6 html tag','albion-toolkit'),
            ]
        );
        $this->add_control(
            'service_overview_desc',
            [
                'label'=>esc_html__('Description', 'albion-toolkit'),
                'type'=>Controls_Manager:: WYSIWYG,
                'description' => esc_html__('This text editor for p, ul - ol list tag','albion-toolkit'),
            ]
        );
        $this->add_control(
            'single_right_image',
            [
                'label' => esc_html__('Right Image', 'albion-toolkit' ),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ]
            ]
        );

        $this->add_group_control(
            Group_Control_Image_Size::get_type(),
            [
                'default' =>esc_html__('full','albion-toolkit'),
                'name' => 'rightimgsz'
            ]
        );
        $this-> end_controls_section();

        // services details overview bottom
        $this-> start_controls_section(
            'service_overview_two',
            [
                'label'=>esc_html__('Single Service Overview Two', 'albion-toolkit'),
                'tab'=> Controls_Manager::TAB_CONTENT,
            ]
        );
        $this->add_control(
            'single_left_image',
            [
                'label' => esc_html__('Left Image', 'albion-toolkit' ),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ]
            ]
        );
        
        $this->add_group_control(
            Group_Control_Image_Size::get_type(),
            [
                'default' =>esc_html__('full','albion-toolkit'),
                'name' => 'leftimgsz'
            ]
        );

        $this->add_control(
            'service_details_title',
            [
                'label'=>esc_html__('Service Details Title', 'albion-toolkit'),
                'type'=>Controls_Manager:: WYSIWYG,
                'description' => esc_html__('This text editor for h1 to h6 html tag','albion-toolkit'),
            ]
        );

        $this->add_control(
            'service_details_desc',
            [
                'label'=>esc_html__('Description', 'albion-toolkit'),
                'type'=>Controls_Manager:: WYSIWYG,
                'description' => esc_html__('This text editor for p, ul - ol list tag','albion-toolkit'),
            ]
        );

        $repeater = new Repeater();

        $repeater->add_control(
            'faq_title', [
                'label' => esc_html__( 'FAQ Title', 'albion-toolkit' ),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
            ]
        );
    
        $repeater->add_control(
            'faq_details', [
                'label' => esc_html__( 'FAQ Details', 'albion-toolkit' ),
                'type' => Controls_Manager::WYSIWYG,
                'label_block' => true,
                'description' => esc_html__('This text editor for p, ul - ol list tag','albion-toolkit'),
            ]
        );
    
        $this->add_control(
            'faq_content',
            [
                'label' => esc_html__( 'Add FAQ Content', 'albion-toolkit' ),
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
            ]
        );
        $this-> end_controls_section();

        // End Tab content controls

        // Start Style content controls
        $this-> start_controls_section(
            'single_service_style',
            [
                'label'=>esc_html__('Content', 'albion-toolkit'),
                'tab'=> Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
			'title_style',
			[
				'label' => esc_html__( 'Single Service Title', 'albion-toolkit' ),
				'type' => Controls_Manager::HEADING,
			]
        );

        $this->add_control(
            'single_service_title_color',
            [
                'label' => esc_html__( 'Color', 'albion-toolkit' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .services-details-overview .services-details-desc h3' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_responsive_control(
			'single_title_font_size',
			[
				'label' => esc_html__( 'Font Size', 'albion-toolkit' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 40,
					],
                ],
                'devices' => [ 'desktop', 'tablet', 'mobile' ],
                'unit' => 'px',
				'selectors' => [
					'{{WRAPPER}} .services-details-overview .services-details-desc h3' => 'font-size: {{SIZE}}{{UNIT}}',
                ],
			]
        );

        $this->add_control(
			'description_style',
			[
				'label' => esc_html__( 'Description', 'albion-toolkit' ),
				'type' => Controls_Manager::HEADING,
			]
        );

        $this->add_control(
            'single_desc_color',
            [
                'label' => esc_html__( 'Color', 'albion-toolkit' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} p' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_responsive_control(
			'single_desc_font_size',
			[
				'label' => esc_html__( 'Font Size', 'albion-toolkit' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 20,
					],
                ],
                'devices' => [ 'desktop', 'tablet', 'mobile' ],
                'unit' => 'px',
				'selectors' => [
					'{{WRAPPER}} p' => 'font-size: {{SIZE}}{{UNIT}}',
                ],
			]
        );

        $this->add_control(
			'accordion_style',
			[
				'label' => esc_html__( 'Accordion Style', 'albion-toolkit' ),
				'type' => Controls_Manager::HEADING,
			]
        );

        $this->add_control(
            'accordion_title_color',
            [
                'label' => esc_html__( 'Title Color', 'albion-toolkit' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .services-details-overview .services-details-desc .services-details-accordion .accordion .accordion-title' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_responsive_control(
            'accordion_title_sz',
            [
                'label' => esc_html__( 'Font Size', 'albion-toolkit' ),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 30,
                    ],
                ],
                'devices' => [ 'desktop', 'tablet', 'mobile' ],
                'unit' => 'px',
                'selectors' => [
                    '{{WRAPPER}} .services-details-overview .services-details-desc .services-details-accordion .accordion .accordion-title' => 'font-size: {{SIZE}}{{UNIT}}',
                ],
            ]
        );
        $this->add_control(
            'accordion_icon_color',
            [
                'label' => esc_html__( 'Icon Color', 'albion-toolkit' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .services-details-overview .services-details-desc .services-details-accordion .accordion .accordion-title i' => 'color: {{VALUE}}',
                ],
            ]
        );
    
        $this->add_control(
            'accordion_icon_bg',
            [
                'label' => esc_html__( 'Title Icon Background', 'albion-toolkit' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .services-details-overview .services-details-desc .services-details-accordion .accordion .accordion-title i' => 'background-color: {{VALUE}}',
                ],
            ]
        );
    
        $this->add_control(
            'accordion_desc_color',
            [
                'label' => esc_html__( 'Description Color', 'albion-toolkit' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .services-details-overview .services-details-desc .services-details-accordion .accordion .accordion-content' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_responsive_control(
            'accordion_desc_sz',
            [
                'label' => esc_html__( 'Font Size', 'albion-toolkit' ),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 25,
                    ],
                ],
                'devices' => [ 'desktop', 'tablet', 'mobile' ],
                'unit' => 'px',
                'selectors' => [
                    '{{WRAPPER}} .services-details-overview .services-details-desc .services-details-accordion .accordion .accordion-content' => 'font-size: {{SIZE}}{{UNIT}}',
                ],
            ]
        );

        $this-> end_controls_section();
    }
    // Register control section end here

    protected function render()
    {
        // Retrieve all controls value
        $settings = $this->get_settings_for_display();

        // Tag allowed for about content
        $service_para_allowed_tags = array(
            'a' =>array(
                'href' => array(),
                'title' => array(),
                'class' => array()
            ),
            'p' => array(),
            'br' => array(),
            'em' => array(),
            'strong' => array()
        ); ?>

        <!-- Start Services Details Area -->
            <div class="services-details-overview">
                <div class="services-details-desc">
                    <?php echo wp_kses_post($settings['service_title']); ?>
                    <?php echo wp_kses_post($settings['service_overview_desc']); ?>
                </div>

                <div class="services-details-image wow fadeInUp">
                <?php echo Group_Control_Image_Size::get_attachment_image_html($settings,'rightimgsz','single_right_image'); ?>
                </div>
            </div>

            <div class="services-details-overview">
                <div class="services-details-image wow fadeInUp">
                <?php echo Group_Control_Image_Size::get_attachment_image_html($settings,'leftimgsz','single_left_image'); ?>
                </div>

                <div class="services-details-desc">
                    <?php echo wp_kses_post($settings['service_details_title']); ?>
                    <?php echo wp_kses_post($settings['service_details_desc']); ?>

                    <div class="services-details-accordion">
                        <ul class="accordion">
                            <?php
                            if ( $settings['faq_content']!='' ){
                                $loop = 1;
                                foreach ( $settings['faq_content'] as $item ) {
                                    if ($loop == 1) {
                                        $active = 'active';
                                        $show = 'show';
                                    }else {
                                        $active = '';
                                        $show = '';
                                    }

                                    if($item['faq_title']!='' || $item['faq_details']!='') { ?>
                                    <li class="accordion-item">
                                        <a class="accordion-title <?php echo esc_attr($active); ?>" href="javascript:void(0)"><?php echo esc_html($item['faq_title']); ?> <i class="fa fa-plus"></i></a>
                                        <?php echo wp_kses_post($item['faq_details']); ?>
                                    </li><?php
                                    } 
                                $loop++; 
                                } 
                            } ?>

                        </ul>
                    </div>
                </div>
            </div>
        <!-- End Services Details Area -->
        <?php
    }

    protected function _content_template() {}
}
Plugin::instance()->widgets_manager->register_widget_type( new SingleServiceWidget );