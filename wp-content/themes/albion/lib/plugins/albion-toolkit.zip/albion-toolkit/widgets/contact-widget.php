<?php namespace Elementor;

class ContactWidget extends Widget_Base{
    public function get_name(){
        return "contact-widget";
    }
    public function get_title(){
        return "Contact Widget";
    }
    public function get_icon(){
        return "eicon-form-horizontal";
    }
    public function get_categories(){
        return ['albioncategory'];
    }

    protected function _register_controls(){

    // Start FAQ Contact Controls
    $this-> start_controls_section(
        'top_content',
        [
            'label'=>esc_html__('Contact Content', 'albion-toolkit'),
            'tab'=> Controls_Manager::TAB_CONTENT,
        ]
    );
    
    $this->add_control(
        'top_title',
        [
            'label' => esc_html__( 'Top Title', 'albion-toolkit' ),
            'type' => Controls_Manager::TEXT,
        ]
    );

    $this->add_control(
        'section_title',
        [
            'label' => esc_html__( 'Title', 'albion-toolkit' ),
            'type' => Controls_Manager::WYSIWYG,
            'description' => esc_html__('This text editor for h1 to h6 html tag','albion-toolkit'),
        ]
    );
    $this->add_control(
        'section_desc',
        [
            'label' => esc_html__( 'Description', 'albion-toolkit' ),
            'type' => Controls_Manager::WYSIWYG,
            'description' => esc_html__('This text editor for p, ul - ol list tag','albion-toolkit'),
        ]
    );

    $this->add_control(
        'left_image',
        [
            'label' => esc_html__( 'Left Image', 'albion-toolkit' ),
            'type' => Controls_Manager::MEDIA,
            'default' => [
                'url' => Utils::get_placeholder_image_src(),
            ],
        ]
    );

    $this->add_group_control(
        Group_Control_Image_Size::get_type(),
        [
            'default' =>'full',
            'name' => 'leftimgsz',
        ]
    );

    $this->add_control(
        'contact_shortcode',
        [
            'label' => esc_html__( 'Contact Form Shortcode', 'albion-toolkit' ),
            'type' => Controls_Manager::TEXT,
        ]
    );
    $this-> end_controls_section();

    $this-> start_controls_section(
        'bottom_content',
        [
            'label'=>esc_html__('Contact Information', 'albion-toolkit'),
            'tab'=> Controls_Manager::TAB_CONTENT,
        ]
    );

    $this->add_control(
        'section_sub_title',
        [
            'label' => esc_html__( 'Contact Subtitle', 'albion-toolkit' ),
            'type' => Controls_Manager::WYSIWYG,
            'description' => esc_html__('This text editor for h1 to h6 html tag','albion-toolkit'),
        ]
    );

    $this->add_control(
        'phone_number',
        [
            'label' => esc_html__( 'Contact Number', 'albion-toolkit' ),
            'type' => Controls_Manager::TEXT,
        ]
    );

    
    $this->add_control(
        'or_text',
        [
            'label' => esc_html__( 'OR', 'albion-toolkit' ),
            'type' => Controls_Manager::TEXT,
        ]
    );

    $this->add_control(
        'gmail_address',
        [
            'label' => esc_html__( 'Mail Address', 'albion-toolkit' ),
            'type' => Controls_Manager::TEXT,
        ]
    );

    
    $repeater = new Repeater();

    $repeater->add_control(
        'icon',
        [
            'label' => esc_html__( 'Social Icons', 'albion-toolkit' ),
            'type' => Controls_Manager::ICON,
            'include' => [
                'fab fa-twitter',
                'fab fa-youtube',
                'fab fa-facebook-f',
                'fab fa-linkedin-in',
                'fab fa-instagram',
                'fab fa-flickr',
                'fab fa-google-plus',
                'fab fa-pinterest',
                'fab fa-reddit',
                'fab fa-twitch',
                'fab fa-vimeo',
            ],
        ]
    );
    $repeater->add_control(
        'social_url',
        [
            'label' => esc_html__( 'URL', 'albion-toolkit' ),
            'type' => Controls_Manager::TEXT,
        ]
    );
    $this->add_control(
        'icon_list',
        [
            'label' => esc_html__( 'Add Social List', 'albion-toolkit' ),
            'type' => Controls_Manager::REPEATER,
            'fields' => $repeater->get_controls(),
        ]
    );

    $this-> end_controls_section();
    // End Contact Controls

    // Start Contact Style
    $this-> start_controls_section(
        'contact_style',
        [
            'label'=>esc_html__('Content', 'albion-toolkit'),
            'tab'=> Controls_Manager::TAB_STYLE,
        ]
    );
    $this->add_control(
        'toptitle_style',
        [
            'label' => esc_html__( 'Top Title', 'albion-toolkit' ),
            'type' => Controls_Manager::HEADING,
        ]
    );
    $this->add_control(
        'con_top_color',
        [
            'label' => esc_html__( 'Color', 'albion-toolkit' ),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .section-title span' => 'color: {{VALUE}}',
            ],
        ]
    );
    $this->add_responsive_control(
        'con_top_font_size',
        [
            'label' => esc_html__( 'Font Size', 'albion-toolkit' ),
            'type' => Controls_Manager::SLIDER,
            'range' => [
                'px' => [
                    'min' => 0,
                    'max' => 30,
                ],
            ],
            'devices' => [ 'desktop', 'tablet', 'mobile' ],
            'unit' => 'px',
            'selectors' => [
                '{{WRAPPER}} .section-title span' => 'font-size: {{SIZE}}{{UNIT}}',
            ],
        ]
    );

    // Title Style
    $this->add_control(
        'con_title_style',
        [
            'label' => esc_html__( 'Title', 'albion-toolkit' ),
            'type' => Controls_Manager::HEADING,
        ]
    );
    $this->add_control(
        'con_title_color',
        [
            'label' => esc_html__( 'Color', 'albion-toolkit' ),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .section-title h2' => 'color: {{VALUE}}',
            ],
        ]
    );
    $this->add_responsive_control(
        'con_title_font_size',
        [
            'label' => esc_html__( 'Font Size', 'albion-toolkit' ),
            'type' => Controls_Manager::SLIDER,
            'range' => [
                'px' => [
                    'min' => 0,
                    'max' => 60,
                ],
            ],
            'devices' => [ 'desktop', 'tablet', 'mobile' ],
            'unit' => 'px',
            'selectors' => [
                '{{WRAPPER}} .section-title h2' => 'font-size: {{SIZE}}{{UNIT}}',
            ],
        ]
    );

    // Description style
    $this->add_control(
        'con_desc_style',
        [
            'label' => esc_html__( 'Description', 'albion-toolkit' ),
            'type' => Controls_Manager::HEADING,
        ]
    );
    $this->add_control(
        'con_desc_color',
        [
            'label' => esc_html__( 'Color', 'albion-toolkit' ),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .section-title p' => 'color: {{VALUE}}',
            ],
        ]
    );
    $this->add_responsive_control(
        'con_desc_size',
        [
            'label' => esc_html__( 'Font Size', 'albion-toolkit' ),
            'type' => Controls_Manager::SLIDER,
            'range' => [
                'px' => [
                    'min' => 0,
                    'max' => 30,
                ],
            ],
            'devices' => [ 'desktop', 'tablet', 'mobile' ],
            'unit' => 'px',
            'selectors' => [
                '{{WRAPPER}} .section-title p' => 'font-size: {{SIZE}}{{UNIT}}',
            ],
        ]
    );

    // Button
    $this->add_control(
        'con_btn_style',
        [
            'label' => esc_html__( 'Button', 'albion-toolkit' ),
            'type' => Controls_Manager::HEADING,
        ]
    );
    $this->add_control(
        'con_btn_color',
        [
            'label' => esc_html__( 'Color', 'albion-toolkit' ),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .btn-primary' => 'color: {{VALUE}}',
            ],
        ]
    );
    $this->add_control(
        'con_btn_bgcolor',
        [
            'label' => esc_html__( 'Background Color', 'albion-toolkit' ),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .btn-primary' => 'background-color: {{VALUE}}',
            ],
        ]
    );
    $this->add_control(
        'con_btn_hcolor',
        [
            'label' => esc_html__( 'Hover Color', 'albion-toolkit' ),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .btn-primary:hover, .btn-primary:focus' => 'color: {{VALUE}} !important',
            ],
        ]
    );
    $this->add_control(
        'con_btn_hbgcolor',
        [
            'label' => esc_html__( 'Hover Background Color', 'albion-toolkit' ),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .btn-primary:hover, .btn-primary:focus' => 'background-color: {{VALUE}} !important',
            ],
        ]
    );
    // End Button

    // Subtitle style
    $this->add_control(
        'con_subtitle_style',
        [
            'label' => esc_html__( 'Subtitle', 'albion-toolkit' ),
            'type' => Controls_Manager::HEADING,
        ]
    );
    $this->add_control(
        'con_subtitle_color',
        [
            'label' => esc_html__( 'Color', 'albion-toolkit' ),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .contact-info .contact-info-content h3' => 'color: {{VALUE}}',
            ],
        ]
    );
    $this->add_responsive_control(
        'con_subtitle_size',
        [
            'label' => esc_html__( 'Font Size', 'albion-toolkit' ),
            'type' => Controls_Manager::SLIDER,
            'range' => [
                'px' => [
                    'min' => 0,
                    'max' => 40,
                ],
            ],
            'devices' => [ 'desktop', 'tablet', 'mobile' ],
            'unit' => 'px',
            'selectors' => [
                '{{WRAPPER}} .contact-info .contact-info-content h3' => 'font-size: {{SIZE}}{{UNIT}}',
            ],
        ]
    );

    // Number style
    $this->add_control(
        'con_num_style',
        [
            'label' => esc_html__( 'Contact Number', 'albion-toolkit' ),
            'type' => Controls_Manager::HEADING,
        ]
    );
    $this->add_control(
        'con_num_color',
        [
            'label' => esc_html__( 'Color', 'albion-toolkit' ),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .contact-info .contact-info-content h2 a' => 'color: {{VALUE}}',
            ],
        ]
    );
    $this->add_control(
        'con_num_hcolor',
        [
            'label' => esc_html__( 'Hover Color', 'albion-toolkit' ),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .contact-info .contact-info-content h2 a:hover' => 'color: {{VALUE}}',
            ],
        ]
    );
    $this->add_responsive_control(
        'con_num_size',
        [
            'label' => esc_html__( 'Font Size', 'albion-toolkit' ),
            'type' => Controls_Manager::SLIDER,
            'range' => [
                'px' => [
                    'min' => 0,
                    'max' => 50,
                ],
            ],
            'devices' => [ 'desktop', 'tablet', 'mobile' ],
            'unit' => 'px',
            'selectors' => [
                '{{WRAPPER}} .contact-info .contact-info-content h2 a' => 'font-size: {{SIZE}}{{UNIT}}',
            ],
        ]
    );

    // OR style
    $this->add_control(
        'or_style',
        [
            'label' => esc_html__( 'OR Text', 'albion-toolkit' ),
            'type' => Controls_Manager::HEADING,
        ]
    );
    $this->add_control(
        'con_or_color',
        [
            'label' => esc_html__( 'Color', 'albion-toolkit' ),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .contact-info .contact-info-content h2 span' => 'color: {{VALUE}}',
            ],
        ]
    );
    $this->add_responsive_control(
        'con_or_size',
        [
            'label' => esc_html__( 'Font Size', 'albion-toolkit' ),
            'type' => Controls_Manager::SLIDER,
            'range' => [
                'px' => [
                    'min' => 0,
                    'max' => 30,
                ],
            ],
            'devices' => [ 'desktop', 'tablet', 'mobile' ],
            'unit' => 'px',
            'selectors' => [
                '{{WRAPPER}} .contact-info .contact-info-content h2 span' => 'font-size: {{SIZE}}{{UNIT}}',
            ],
        ]
    );

    // gmail style
    $this->add_control(
        'con_gmail_style',
        [
            'label' => esc_html__( 'Gmail', 'albion-toolkit' ),
            'type' => Controls_Manager::HEADING,
        ]
    );
    $this->add_control(
        'con_gmail_color',
        [
            'label' => esc_html__( 'Color', 'albion-toolkit' ),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .contact-info .contact-info-content h2 a:not(:first-child)' => 'color: {{VALUE}}',
            ],
        ]
    );
    $this->add_control(
        'con_gmail_hcolor',
        [
            'label' => esc_html__( 'Hover Color', 'albion-toolkit' ),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .contact-info .contact-info-content h2 a:not(:first-child):hover' => 'color: {{VALUE}}',
            ],
        ]
    );

    // Social style
    $this->add_control(
        'con_social_style',
        [
            'label' => esc_html__( 'Social', 'albion-toolkit' ),
            'type' => Controls_Manager::HEADING,
        ]
    );
    $this->add_control(
        'con_social_color',
        [
            'label' => esc_html__( 'Color', 'albion-toolkit' ),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .contact-info .contact-info-content .social li a' => 'color: {{VALUE}}',
            ],
        ]
    );
    $this->add_control(
        'con_social_border',
        [
            'label' => esc_html__( 'Border Color', 'albion-toolkit' ),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .contact-info .contact-info-content .social li a' => 'border-color: {{VALUE}}',
            ],
        ]
    );
    $this->add_control(
        'con_social_hcolor',
        [
            'label' => esc_html__( 'Hover Color', 'albion-toolkit' ),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .contact-info .contact-info-content .social li a:hover' => 'color: {{VALUE}}',
            ],
        ]
    );
    $this->add_control(
        'con_social_hbg',
        [
            'label' => esc_html__( 'Hover Background Color', 'albion-toolkit' ),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .contact-info .contact-info-content .social li a:hover' => 'background-color: {{VALUE}}',
            ],
        ]
    );
    $this->add_control(
        'con_social_hborder',
        [
            'label' => esc_html__( 'Hover Border Color', 'albion-toolkit' ),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .contact-info .contact-info-content .social li a:hover' => 'border-color: {{VALUE}}',
            ],
        ]
    );

    $this-> end_controls_section();
    
}
    // Register control section end here

    protected function render() 
    {
        $settings = $this->get_settings_for_display(); ?>

        <div class="contact-area ptb-110">
            <div class="container">
                <div class="section-title">
                    <span><?php echo esc_html($settings['top_title']); ?></span>

                    <?php echo wp_kses_post($settings['section_title']); ?>
                    <?php echo wp_kses_post($settings['section_desc']); ?>
                </div>

                <div class="contact-form">
                    <div class="row align-items-center">
                        <div class="col-lg-5 col-md-12">
                            <div class="contact-image">
                                <?php echo Group_Control_Image_Size::get_attachment_image_html($settings,'leftimgsz','left_image'); ?>
                            </div>
                        </div>

                        <div class="col-lg-7 col-md-12">
                        <?php $form = $settings['contact_shortcode']; 
                            echo do_shortcode($form); ?>
                        </div>
                    </div>
                </div>

                <div class="contact-info">
                    <div class="contact-info-content">
                        <?php echo wp_kses_post($settings['section_sub_title']); ?>
                        <h2 class="contact-information">
                            <a href="<?php echo esc_attr__("tel:","albion-toolkit")?><?php echo wp_kses_post(str_replace(' ', '', $settings['phone_number']), "albion-toolkit") ?>"><?php echo esc_html($settings['phone_number']); ?></a>

                            <span><?php echo esc_html($settings['or_text']); ?></span>

                            <a href="<?php echo esc_attr__("mailto:","albion-toolkit")?><?php echo esc_url($settings['gmail_address']); ?>"><?php echo esc_html($settings['gmail_address']); ?></a>
                        </h2>

                        <ul class="social">
                            <?php
                            if ( $settings['icon_list']!='' ){ 
                                foreach ( $settings['icon_list'] as $item ) {
                                    if($item['icon']!=''){ ?>
                                    <li><a href="<?php echo esc_url($item['social_url']); ?>" target="_blank"><i class="<?php echo esc_attr($item['icon']); ?>"></i></a></li>
                                <?php
                            } } }?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    <?php    
    }

    protected function _content_template() {}
}
Plugin::instance()->widgets_manager->register_widget_type( new ContactWidget );