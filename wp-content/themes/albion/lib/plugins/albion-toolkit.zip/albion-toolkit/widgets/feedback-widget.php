<?php
namespace Elementor;
class TestimonialWidget extends Widget_Base{
    public function get_name(){
        return "testimonial-widget";
    }
    public function get_title(){
        return "Testimonial Widget";
    }
    public function get_icon(){
        return "eicon-testimonial-carousel";
    }
    public function get_categories(){
        return ['albioncategory'];
    }

    protected function _register_controls(){
    
        $this-> start_controls_section(
            'albion_testimonial',
            [
                'label'=>esc_html__('Testimonials', 'albion-toolkit'),
                'tab'=> Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'choose_type',
            [
                'label' => esc_html__( 'Choose Style', 'albion-toolkit' ),
                'type' => Controls_Manager::SELECT,
                'label_block' => true,
                'options' => [
                    '1'  => esc_html__( 'Style 1', 'albion-toolkit' ),
                    '2' => esc_html__( 'Style 2', 'albion-toolkit' ),
                ],
                'default' => '1',
            ]
        );

        $this->add_control(
            'section_title',
            [
                'label'=>esc_html__('Title', 'albion-toolkit'),
                'type'=>Controls_Manager:: WYSIWYG,
                'condition' => [
                    'choose_type' => '2',
                ],
                'description' => esc_html__('This text editor for h1 to h6 html tag','albion-toolkit'),
            ]
        );

        $this->add_control(
            'section_desc',
            [
                'label'=>esc_html__('Description', 'albion-toolkit'),
                'type'=>Controls_Manager:: WYSIWYG,
                'condition' => [
                    'choose_type' => '2',
                ],
                'description' => esc_html__('This text editor for p, ul - ol list tag','albion-toolkit'),
            ]
        );

        $repeater = new Repeater();

        $repeater->add_control(
            'feedback', [
                'label' => esc_html__( 'Feedback', 'albion-toolkit' ),
                'type'=>Controls_Manager:: WYSIWYG,
                'description' => esc_html__('This text editor for p, ul - ol list tag','albion-toolkit'),
            ]
        );
        $repeater->add_control(
            'title', [
                'label' => esc_html__( 'Title', 'albion-toolkit' ),
                'type'=>Controls_Manager:: WYSIWYG,
                'description' => esc_html__('This text editor for h1 to h6 html tag','albion-toolkit'),
            ]
        );
        $repeater->add_control(
            'designation', [
                'label' => esc_html__( 'Designation', 'albion-toolkit' ),
                'type'=>Controls_Manager:: TEXT,
            ]
        );

        $repeater->add_control(
            'image',
            [
                'label' => esc_html__( 'Image', 'albion-toolkit' ),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $repeater->add_group_control(
            Group_Control_Image_Size::get_type(),
            [
                'default' =>'full',
                'name' => 'imagesz', 
            ]
        );

        $this->add_control(
            'all_feedback',
            [
                'label' => esc_html__( 'All Feedback', 'albion-toolkit' ),
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'condition' => [
                    'choose_type' => '1',
                ]
            ]
        );

        $repeater2 = new Repeater();

        $repeater2->add_control(
            'title2', [
                'label' => esc_html__( 'Title', 'albion-toolkit' ),
                'type'=>Controls_Manager:: WYSIWYG,
                'description' => esc_html__('This text editor for h1 to h6 html tag','albion-toolkit'),
            ]
        );
        $repeater2->add_control(
            'designation2', [
                'label' => esc_html__( 'Designation', 'albion-toolkit' ),
                'type'=>Controls_Manager:: TEXT,
            ]
        );

        $repeater2->add_control(
            'feedback2', [
                'label' => esc_html__( 'Feedback', 'albion-toolkit' ),
                'type'=>Controls_Manager:: WYSIWYG,
                'description' => esc_html__('This text editor for p, ul - ol list tag','albion-toolkit'),
            ]
        );

        $repeater2->add_control(
            'c_image',
            [
                'label' => esc_html__( 'Image', 'albion-toolkit' ),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $repeater2->add_group_control(
            Group_Control_Image_Size::get_type(),
            [
                'default' =>'full',
                'name' => 'imagesz2', 
            ]
        );

        $repeater2->add_control(
            'rating',
            [
                'label' => esc_html__( 'Rating', 'albion-toolkit' ),
                'type' => Controls_Manager::SELECT,
                'label_block' => true,
                'options' => [
                    '1'  => esc_html__( '1', 'albion-toolkit' ),
                    '2' => esc_html__( '2', 'albion-toolkit' ),
                    '3' => esc_html__( '3', 'albion-toolkit' ),
                    '4' => esc_html__( '4', 'albion-toolkit' ),
                    '5' => esc_html__( '5', 'albion-toolkit' ),
                ],
                'default' => '5',
            ]
        );

        $this->add_control(
            'all_feedback2',
            [
                'label' => esc_html__( 'All Feedback', 'albion-toolkit' ),
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'condition' => [
                    'choose_type' => '2',
                ]
            ]
        );
        $this->add_control(
			'section_color_img',
			[
				'label' => esc_html__( 'Color Image Show?', 'albion-toolkit' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'albion-toolkit' ),
				'label_off' => esc_html__( 'Hide', 'albion-toolkit' ),
				'return_value' => 'yes',
                'default' => 'yes',
                'condition' => [
                    'choose_type' => '1',
                ]
			]
        );
        $this->add_control(
			'section_shape',
			[
				'label' => esc_html__( 'Show Shapes', 'albion-toolkit' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'albion-toolkit' ),
				'label_off' => esc_html__( 'Hide', 'albion-toolkit' ),
				'return_value' => 'yes',
                'default' => 'yes',
                'condition' => [
                    'choose_type' => '2',
                ]
			]
        );
        $this-> end_controls_section();

        // Start Style Controls
        $this-> start_controls_section(
            'feedback_style',
            [
                'label'=>esc_html__('Feedback', 'albion-toolkit'),
                'tab'=> Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
			'title_style',
			[
				'label' => esc_html__( 'Title', 'albion-toolkit' ),
                'type' => Controls_Manager::HEADING,
                'condition' => [
                    'choose_type' => '2',
                ]
			]
        );

        $this->add_control(
            'sectitle_color',
            [
                'label' => esc_html__( 'Color', 'albion-toolkit' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .section-title h2' => 'color: {{VALUE}}',
                ],
                'condition' => [
                    'choose_type' => '2',
                ]
            ]
        );

        $this->add_responsive_control(
			'sectitle_font_size',
			[
				'label' => esc_html__( 'Font Size', 'albion-toolkit' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 60,
					],
                ],
                'devices' => [ 'desktop', 'tablet', 'mobile' ],
                'unit' => 'px',
				'selectors' => [
					'{{WRAPPER}} .section-title h2' => 'font-size: {{SIZE}}{{UNIT}}',
                ],
                'condition' => [
                    'choose_type' => '2',
                ]
			]
        );

        $this->add_control(
			'secdesc_style',
			[
				'label' => esc_html__( 'Description', 'albion-toolkit' ),
                'type' => Controls_Manager::HEADING,
                'condition' => [
                    'choose_type' => '2',
                ]
			]
        );

        $this->add_control(
            'secdesc_color',
            [
                'label' => esc_html__( 'Color', 'albion-toolkit' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .section-title p' => 'color: {{VALUE}}',
                ],
                'condition' => [
                    'choose_type' => '2',
                ]
            ]
        );

        $this->add_responsive_control(
			'secdesc_size',
			[
				'label' => esc_html__( 'Font Size', 'albion-toolkit' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 30,
					],
                ],
                'devices' => [ 'desktop', 'tablet', 'mobile' ],
                'unit' => 'px',
				'selectors' => [
					'{{WRAPPER}} .section-title p' => 'font-size: {{SIZE}}{{UNIT}}',
                ],
                'condition' => [
                    'choose_type' => '2',
                ]
			]
        );

        $this->add_control(
            'client_feed',
            [
                'label' => esc_html__( 'Feedback', 'albion-toolkit' ),
                'type' => Controls_Manager::HEADING,
            ]
        );

        $this->add_control(
            'feedback_color',
            [
                'label' => esc_html__( 'Color', 'albion-toolkit' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .feedback-item p, .single-testimonials-item p' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_responsive_control(
            'font_sz',
            [
                'label' => esc_html__( 'Font Size', 'albion-toolkit' ),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 40,
                    ],
                ],
                'devices' => [ 'desktop', 'tablet', 'mobile' ],
                'unit' => 'px',
                'selectors' => [
                    '{{WRAPPER}} .feedback-item p, .single-testimonials-item p' => 'font-size: {{SIZE}}{{UNIT}}',
                ],
            ]
        );

        $this->add_control(
            'client_title',
            [
                'label' => esc_html__( 'Title', 'albion-toolkit' ),
                'type' => Controls_Manager::HEADING,
            ]
        );
        $this->add_control(
            'title_color',
            [
                'label' => esc_html__( 'Color', 'albion-toolkit' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .feedback-item .client-info h3, .single-testimonials-item .client-info h3' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_responsive_control(
            'titlefont_sz',
            [
                'label' => esc_html__( 'Font Size', 'albion-toolkit' ),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 40,
                    ],
                ],
                'devices' => [ 'desktop', 'tablet', 'mobile' ],
                'unit' => 'px',
                'selectors' => [
                    '{{WRAPPER}} .feedback-item .client-info h3, .single-testimonials-item .client-info h3' => 'font-size: {{SIZE}}{{UNIT}}',
                ],
            ]
        );

        $this->add_control(
            'client_desigantion',
            [
                'label' => esc_html__( 'Designation', 'albion-toolkit' ),
                'type' => Controls_Manager::HEADING,
            ]
        );
        $this->add_control(
            'designation_color',
            [
                'label' => esc_html__( 'Color', 'albion-toolkit' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .feedback-item .client-info span, .single-testimonials-item .client-info span' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_responsive_control(
            'desigfont_sz',
            [
                'label' => esc_html__( 'Font Size', 'albion-toolkit' ),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 25,
                    ],
                ],
                'devices' => [ 'desktop', 'tablet', 'mobile' ],
                'unit' => 'px',
                'selectors' => [
                    '{{WRAPPER}} .feedback-item .client-info span, .single-testimonials-item .client-info span' => 'font-size: {{SIZE}}{{UNIT}}',
                ],
            ]
        );

        $this-> end_controls_section();
    }

    protected function render() 
    {
        $settings = $this->get_settings_for_display(); ?>

        <!-- Start Feedback Area -->
        <?php if( $settings['choose_type'] == 1 ) { 
            if ( 'yes' === $settings['section_color_img'] ) { 
                $slidecls = "feedback-slides-bg";

            } else {
                $slidecls = "feedback-slides-bg-color";
            } ?>
            <div class="feedback-area">
                <div class="feedback-slides <?php echo esc_attr( $slidecls ); ?> owl-carousel owl-theme"> <?php

                if ( $settings['all_feedback']!='') { 
                foreach( $settings['all_feedback'] as $index=>$item ){ 
                    if($item['feedback']!='' || $item['title']!='') { ?>
                        <div class="row m-0">
                            <div class="col-lg-6 col-md-12 p-0">
                                <div class="feedback-item">
                                    <?php echo wp_kses_post($item['feedback']); ?>
                                    <div class="client-info">
                                        <div class="client-pic">
                                            <?php echo Group_Control_Image_Size::get_attachment_image_html($item,'imagesz','image'); ?>
                                        </div>
                                        <?php echo wp_kses_post($item['title']); ?>
                                        <span><?php echo esc_html($item['designation']); ?></span>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-6 col-md-12 p-0">
                                <div class="client-image bg1" style="background-image: url(<?php echo esc_url( $item['image']['url']); ?> )">
                                </div>
                            </div>
                        </div> <?php
                        }
                    }
                } ?>

                </div>
            </div> <?php
        } else { ?>
            <div class="testimonials-area  ptb-110">
                <div class="container">
                    <div class="section-title">
                        <?php echo wp_kses_post($settings['section_title']); ?>
                        <?php echo wp_kses_post($settings['section_desc']); ?>
                    </div>
                    <div class="testimonials-slides owl-carousel owl-theme"> <?php

                        if ( $settings['all_feedback2']!='') { 
                            foreach( $settings['all_feedback2'] as $item ){ 
                                if($item['feedback2']!='' || $item['title2']!='') { ?>
                                    <div class="single-testimonials-item">
                                        <div class="client-info">
                                            <?php echo Group_Control_Image_Size::get_attachment_image_html($item,'imagesz2','c_image'); ?>
                                           
                                            <?php echo wp_kses_post($item['title2']); ?>
                                            <span><?php echo esc_html($item['designation2']); ?></span>
                                        </div>
                                        <?php echo wp_kses_post($item['feedback2']); ?>

                                        <div class="rating">
                                            <?php if( $item['rating'] == 1 ) { ?>
                                                <i class="fas fa-star"></i> <?php
                                            } ?>
                                            <?php if( $item['rating'] == 2 ) { ?>
                                                <i class="fas fa-star"></i>
                                                <i class="fas fa-star"></i> <?php
                                            } ?>
                                            <?php if( $item['rating'] == 3 ) { ?>
                                                <i class="fas fa-star"></i>
                                                <i class="fas fa-star"></i>
                                                <i class="fas fa-star"></i> <?php
                                            } ?>
                                            <?php if( $item['rating'] == 4 ) { ?>
                                                <i class="fas fa-star"></i>
                                                <i class="fas fa-star"></i>
                                                <i class="fas fa-star"></i>
                                                <i class="fas fa-star"></i> <?php
                                            } ?>
                                            <?php if( $item['rating'] == 5 ) { ?>
                                                <i class="fas fa-star"></i>
                                                <i class="fas fa-star"></i>
                                                <i class="fas fa-star"></i>
                                                <i class="fas fa-star"></i>
                                                <i class="fas fa-star"></i> <?php
                                            } ?>
                                            
                                        </div>
                                    </div> <?php
                                }
                            }
                        } ?>

                    </div>
                </div>

                <?php if ( 'yes' === $settings['section_shape'] ) { ?>
                    <div class="shape-img1">
                        <img src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/shape/1.png' ); ?>" alt="<?php echo esc_attr__( 'Shape', 'albion-toolkit' ); ?>">
                    </div>
                    <div class="shape-img3">
                        <img src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/shape/3.png' ); ?>" alt="<?php echo esc_attr__( 'Shape', 'albion-toolkit' ); ?>">
                    </div>
                    <div class="shape-img2">
                        <img src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/shape/2.svg' ); ?>" alt="<?php echo esc_attr__( 'Shape', 'albion-toolkit' ); ?>">
                    </div>
                    <div class="shape-img5">
                        <img src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/shape/5.svg' ); ?>" alt="<?php echo esc_attr__( 'Shape', 'albion-toolkit' ); ?>">
                    </div>
                    <div class="shape-img4">
                        <img src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/shape/4.svg' ); ?>" alt="<?php echo esc_attr__( 'Shape', 'albion-toolkit' ); ?>">
                    </div>
                    <div class="dot-shape1">
                        <img src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/shape/dot1.png' ); ?>" alt="<?php echo esc_attr__( 'Shape', 'albion-toolkit' ); ?>">
                    </div>
                    <div class="dot-shape2">
                        <img src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/shape/dot3.png' ); ?>" alt="<?php echo esc_attr__( 'Shape', 'albion-toolkit' ); ?>">
                    </div><?php
                } ?>
            </div> <?php
        } ?>
        <!-- End Feedback Area -->
    <?php
    } 
    protected function _content_template() {}

}
Plugin::instance()->widgets_manager->register_widget_type( new TestimonialWidget );