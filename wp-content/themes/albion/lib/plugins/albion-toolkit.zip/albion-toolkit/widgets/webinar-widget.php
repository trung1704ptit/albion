<?php
namespace Elementor;
class WebinarWidget extends Widget_Base{
    public function get_name(){
        return "webinar-widget";
    }
    public function get_title(){
        return "Webinar Section";
    }
    public function get_icon(){
        return "eicon-play";
    }
    public function get_categories(){
        return ['albioncategory'];
    }

    protected function _register_controls(){
        // Tab content controls
        $this-> start_controls_section(
            'section_content',
            [
                'label'=>esc_html__('Content', 'albion-toolkit'),
                'tab'=> Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'we_title',
            [
                'label'=>esc_html__('Title', 'albion-toolkit'),
                'type'=>Controls_Manager:: WYSIWYG,
                'description' => esc_html__('This text editor for h1 to h6 html tag','albion-toolkit'),
            ]
        );

        $this->add_control(
            'we_desc',
            [
                'label'=>esc_html__('Description', 'albion-toolkit'),
                'type'=>Controls_Manager:: WYSIWYG,
                'description' => esc_html__('This text editor for p, ul - ol list tag','albion-toolkit'),
            ]
        );

        $this->add_control(
            'btn_text',
            [
                'label'=>esc_html__('Button Title', 'albion-toolkit'),
                'type'=>Controls_Manager:: TEXT,
            ]
        );

        $this->add_control(
            'link_type',
            [
                'label' => esc_html__( 'Link Type', 'albion-toolkit' ),
                'type' => Controls_Manager::SELECT,
                'label_block' => true,
                'options' => [
                    '1'  => esc_html__( 'Link To Page', 'albion-toolkit' ),
                    '2' => esc_html__( 'External Link', 'albion-toolkit' ),
                ],
            ]
        );

        $this->add_control(
            'link_to_page',
            [
                'label' => esc_html__( 'Link Page', 'albion-toolkit' ),
                'type' => Controls_Manager::SELECT,
                'label_block' => true,
                'options' => albion_toolkit_get_page_as_list(),
                'condition' => [
                    'link_type' => '1',
                ]
            ]
        );

        $this->add_control(
            'external_link',
            [
                'label'=>esc_html__('External Link', 'albion-toolkit'),
                'type'=>Controls_Manager:: TEXT,
                'condition' => [
                    'link_type' => '2',
                ]
            ]
        );

        $this->add_control(
            'bg_image',
            [
                'label' => esc_html__('Right Background Image', 'albion-toolkit' ),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ]
            ]
        );

        $this->add_control(
            'right_image',
            [
                'label' => esc_html__('Right Image For Responsive Device', 'albion-toolkit' ),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ]
            ]
        );

        $this->add_group_control(
            Group_Control_Image_Size::get_type(),
            [
                'default' =>esc_html__('full','albion-toolkit'),
                'name' => 'image_sz'
            ]
        );

        $this->add_control(
            'video_url',
            [
                'label'=>esc_html__('Video URL', 'albion-toolkit'),
                'type'=>Controls_Manager:: TEXT,
            ]
        );
        $this-> end_controls_section();

        // End Tab content controls

        // Start Style content controls
        $this-> start_controls_section(
            'content_style',
            [
                'label'=>esc_html__('Content', 'albion-toolkit'),
                'tab'=> Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
			'title_style',
			[
				'label' => esc_html__( 'Title', 'albion-toolkit' ),
				'type' => Controls_Manager::HEADING,
			]
        );

        $this->add_control(
            'title_color',
            [
                'label' => esc_html__( 'Color', 'albion-toolkit' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .webinar-content h2' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_responsive_control(
			'title_font_size',
			[
				'label' => esc_html__( 'Font Size', 'albion-toolkit' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 60,
					],
                ],
                'devices' => [ 'desktop', 'tablet', 'mobile' ],
                'unit' => 'px',
				'selectors' => [
					'{{WRAPPER}} .webinar-content h2' => 'font-size: {{SIZE}}{{UNIT}}',
                ],
			]
        );

        $this->add_control(
			'description_style',
			[
				'label' => esc_html__( 'Description', 'albion-toolkit' ),
				'type' => Controls_Manager::HEADING,
			]
        );

        $this->add_control(
            'desc_color',
            [
                'label' => esc_html__( 'Color', 'albion-toolkit' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .webinar-content p' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_responsive_control(
			'desc_font_size',
			[
				'label' => esc_html__( 'Font Size', 'albion-toolkit' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 20,
					],
                ],
                'devices' => [ 'desktop', 'tablet', 'mobile' ],
                'unit' => 'px',
				'selectors' => [
					'{{WRAPPER}} .webinar-content p' => 'font-size: {{SIZE}}{{UNIT}}',
                ],
			]
        );

        // Button Style //
        $this->add_control(
			'button_style',
			[
				'label' => esc_html__( 'Watch More Button', 'albion-toolkit' ),
                'type' => Controls_Manager::HEADING,
			]
        );
        $this->start_controls_tabs( 'button_effects');

        $this->start_controls_tab( 'normal',
			[
				'label' => esc_html__( 'Normal', 'albion-toolkit' ),
			]
        );

        $this->add_control(
            'btn_color',
            [
                'label' => esc_html__( 'Color', 'albion-toolkit' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .btn-primary' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'btn_bgcolor',
            [
                'label' => esc_html__( 'Background Color', 'albion-toolkit' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .btn-primary' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab( 'hover',
            [
                'label' => esc_html__( 'Hover', 'albion-toolkit' ),
            ]
        );

        $this->add_control(
            'btn_hcolor',
            [
                'label' => esc_html__( 'Color', 'albion-toolkit' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}}  .btn-primary:hover, .btn-primary:focus' => 'color: {{VALUE}} !important',
                ],
            ]
        );

        $this->add_control(
            'btn_hbgcolor',
            [
                'label' => esc_html__( 'Background Color', 'albion-toolkit' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}}  .btn-primary:hover, .btn-primary:focus' => 'background-color: {{VALUE}} !important',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->end_controls_tabs();
        // End Button Style //

        $this->add_control(
			'video_style',
			[
				'label' => esc_html__( 'Video Style', 'albion-toolkit' ),
                'type' => Controls_Manager::HEADING,
			]
        );
        $this->add_control(
            'video_color',
            [
                'label' => esc_html__( 'Color', 'albion-toolkit' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .webinar-video-image .video-btn' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_control(
            'video_bgcolor',
            [
                'label' => esc_html__( 'Background', 'albion-toolkit' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .webinar-video-image .video-btn' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'video_hcolor',
            [
                'label' => esc_html__( 'Hover Color', 'albion-toolkit' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .webinar-video-image .video-btn:hover, .webinar-video-image .video-btn:focus' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_control(
            'video_hbgcolor',
            [
                'label' => esc_html__( 'Background Hover', 'albion-toolkit' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .webinar-video-image .video-btn:hover, .webinar-video-image .video-btn:focus' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this-> end_controls_section();
    }
    // Register control section end here

    protected function render()
    {
        // Retrieve all controls value
        $settings = $this->get_settings_for_display();

        // Tag allowed for about content
        $web_text_allowed_tags = array(
            'a' =>array(
                'href' => array(),
                'title' => array(),
                'class' => array()
            ),
            'p' => array(),
            'br' => array(),
            'em' => array(),
            'strong' => array()
        );

        // Discover Button link
        $link_source = '';
        if($settings['link_type'] == 1){
            $link_source = get_page_link($settings['link_to_page']); 
        } else {
            $link_source = $settings['external_link'];
        } ?>

        <!-- Start Webinar Area -->
        <div class="webinar-area">
            <div class="row m-0">
                <div class="col-lg-6 p-0">
                    <div class="webinar-content">
                        <?php echo wp_kses_post($settings['we_title']); ?>
                        <?php echo wp_kses_post($settings['we_desc']); ?>
                        <?php 
                        if($settings['btn_text'] !='') { ?>
                            <a href="<?php echo esc_url($link_source); ?>" class="btn btn-primary"><?php echo esc_html($settings['btn_text']); ?></a>
                        <?php
                        } ?>
                    </div>
                </div>

                <div class="col-lg-6 p-0">
                    <div class="webinar-video-image" style="background-image: url(<?php echo esc_url( $settings['bg_image']['url']); ?> )">
                        <?php echo Group_Control_Image_Size::get_attachment_image_html($settings,'image_sz','right_image'); ?>
                        <a href="<?php echo esc_url($settings['video_url']); ?>" class="video-btn popup-youtube"><i class="flaticon-play-button"></i></a>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Webinar Area -->
        <?php
    }

    protected function _content_template() {}
}
Plugin::instance()->widgets_manager->register_widget_type( new WebinarWidget );