<?php
namespace Elementor;
class FunfactsWidget extends Widget_Base{
    public function get_name(){
        return "funfact-widget";
    }
    public function get_title(){
        return "Funfacts Widget";
    }
    public function get_icon(){
        return "eicon-counter-circle";
    }
    public function get_categories(){
        return ['albioncategory'];
    }

    protected function _register_controls(){

    // Start Partner section
    $this-> start_controls_section(
        'funfact_section',
        [
            'label'=>esc_html__('Content', 'albion-toolkit'),
            'tab'=> Controls_Manager::TAB_CONTENT,
        ]
    );

    $this->add_control(
        'title', [
            'label' => esc_html__( 'Title', 'albion-toolkit' ),
            'type' => Controls_Manager::WYSIWYG,
            'label_block' => true,
            'description' => esc_html__('This text editor for h1 to h6 html tag','albion-toolkit'),
        ]
    );
    $this->add_control(
        'desc', [
            'label' => esc_html__( 'Description', 'albion-toolkit' ),
            'type' => Controls_Manager::WYSIWYG,
            'label_block' => true,
            'description' => esc_html__('This text editor for p, ul - ol list tag','albion-toolkit'),
        ]
    );

    $repeater = new Repeater();

    $repeater->add_control(
        'count_num', [
            'label' => esc_html__( 'Count Number', 'albion-toolkit' ),
            'type' => Controls_Manager::TEXT,
            'label_block' => true,
        ]
    );
    
    $repeater->add_control(
        'symbol', [
            'label' => esc_html__( 'Counter Symbol', 'albion-toolkit' ),
            'type' => Controls_Manager::TEXT,
            'label_block' => true,
        ]
    );
    $repeater->add_control(
        'funfacts_title', [
            'label' => esc_html__( 'Single Funfacts Title', 'albion-toolkit' ),
            'type' => Controls_Manager::TEXT,
            'label_block' => true,
        ]
    );

    $this->add_control(
        'funfacts_list',
        [
            'label' => esc_html__( 'Add Funfacts list', 'albion-toolkit' ),
            'type' => Controls_Manager::REPEATER,
            'fields' => $repeater->get_controls(),
        ]
    );
    $this->add_control(
        'contact_cta', [
            'label' => esc_html__( 'Contact CTA Title', 'albion-toolkit' ),
            'type' => Controls_Manager::WYSIWYG,
            'label_block' => true,
            'description' => esc_html__('This text editor for h1 to h6 html tag','albion-toolkit'),
        ]
    );
    $this->add_control(
        'contact_cta_note', [
            'label' => esc_html__( 'Contact CTA Short Note', 'albion-toolkit' ),
            'type' => Controls_Manager::WYSIWYG,
            'label_block' => true,
            'description' => esc_html__('This text editor for p, ul - ol list tag','albion-toolkit'),
        ]
    );
    $this->add_control(
        'contact_cta_btn', [
            'label' => esc_html__( 'Contact Button Text', 'albion-toolkit' ),
            'type' => Controls_Manager::TEXT,
            'label_block' => true,
        ]
    );
    $this->add_control(
        'link_type',
        [
            'label' => esc_html__( 'Link Type', 'albion-toolkit' ),
            'type' => Controls_Manager::SELECT,
            'label_block' => true,
            'options' => [
                '1'  => esc_html__( 'Link To Page', 'albion-toolkit' ),
                '2' => esc_html__( 'External Link', 'albion-toolkit' ),
            ], 
        ]
    );

    $this->add_control(
        'link_to_page',
        [
            'label' => esc_html__( 'Link Page', 'albion-toolkit' ),
            'type' => Controls_Manager::SELECT,
            'label_block' => true,
            'options' => albion_toolkit_get_page_as_list(),
            'condition' => [
                'link_type' => '1',
            ]
        ]
    );

    $this->add_control(
        'external_link',
        [
            'label'=>esc_html__('External Link', 'albion-toolkit'),
            'type'=>Controls_Manager:: TEXT,
            'condition' => [
                'link_type' => '2',
            ]
        ]
    );
    $this->add_control(
        'section_shape',
        [
            'label' => esc_html__( 'Show Shapes', 'albion-toolkit' ),
            'type' => Controls_Manager::SWITCHER,
            'label_on' => esc_html__( 'Show', 'albion-toolkit' ),
            'label_off' => esc_html__( 'Hide', 'albion-toolkit' ),
            'return_value' => 'yes',
            'default' => 'yes',
        ]
    );
    $this-> end_controls_section();

    // Start Style content controls
    $this-> start_controls_section(
        'content_style',
        [
            'label'=>esc_html__('Content Style', 'albion-toolkit'),
            'tab'=> Controls_Manager::TAB_STYLE,
        ]
    );
    $this->add_control(
        'title_color',
        [
            'label' => esc_html__( 'Title Color', 'albion-toolkit' ),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .section-title h2' => 'color: {{VALUE}}',
            ],
        ]
    );
    $this->add_responsive_control(
        'title_size',
        [
            'label' => esc_html__( 'Title Font Size', 'albion-toolkit' ),
            'type' => Controls_Manager::SLIDER,
            'range' => [
                'px' => [
                    'min' => 0,
                    'max' => 50,
                ],
            ],
            'devices' => [ 'desktop', 'tablet', 'mobile' ],
            'unit' => 'px',
            'selectors' => [
                '{{WRAPPER}} .section-title h2' => 'font-size: {{SIZE}}{{UNIT}}',
            ],
        ]
    );
    $this->add_responsive_control(
        'desc_size',
        [
            'label' => esc_html__( 'Description Font Size', 'albion-toolkit' ),
            'type' => Controls_Manager::SLIDER,
            'range' => [
                'px' => [
                    'min' => 0,
                    'max' => 20,
                ],
            ],
            'devices' => [ 'desktop', 'tablet', 'mobile' ],
            'unit' => 'px',
            'selectors' => [
                '{{WRAPPER}} .section-title p' => 'font-size: {{SIZE}}{{UNIT}}',
            ],
        ]
    );

    $this->add_responsive_control(
        'count_number_size',
        [
            'label' => esc_html__( 'Counter Number Font Size', 'albion-toolkit' ),
            'type' => Controls_Manager::SLIDER,
            'range' => [
                'px' => [
                    'min' => 0,
                    'max' => 40,
                ],
            ],
            'devices' => [ 'desktop', 'tablet', 'mobile' ],
            'unit' => 'px',
            'selectors' => [
                '{{WRAPPER}} .single-funfacts h3' => 'font-size: {{SIZE}}{{UNIT}}',
            ],
        ]
    );
    $this->add_responsive_control(
        'title_f_size',
        [
            'label' => esc_html__( 'Funfacts Title Font Size', 'albion-toolkit' ),
            'type' => Controls_Manager::SLIDER,
            'range' => [
                'px' => [
                    'min' => 0,
                    'max' => 20,
                ],
            ],
            'devices' => [ 'desktop', 'tablet', 'mobile' ],
            'unit' => 'px',
            'selectors' => [
                '{{WRAPPER}} .single-funfacts p' => 'font-size: {{SIZE}}{{UNIT}}',
            ],
        ]
    );
    $this->add_control(
        'cta_title_color',
        [
            'label' => esc_html__( 'Contact Title Color', 'albion-toolkit' ),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .contact-cta-box h3' => 'color: {{VALUE}}',
            ],
        ]
    );
    $this->add_responsive_control(
        'cta_title_size',
        [
            'label' => esc_html__( 'Contact Title Font Size', 'albion-toolkit' ),
            'type' => Controls_Manager::SLIDER,
            'range' => [
                'px' => [
                    'min' => 0,
                    'max' => 30,
                ],
            ],
            'devices' => [ 'desktop', 'tablet', 'mobile' ],
            'unit' => 'px',
            'selectors' => [
                '{{WRAPPER}} .contact-cta-box h3' => 'font-size: {{SIZE}}{{UNIT}}',
            ],
        ]
    );
    $this->add_responsive_control(
        'cta_con_size',
        [
            'label' => esc_html__( 'Contact Notes Font Size', 'albion-toolkit' ),
            'type' => Controls_Manager::SLIDER,
            'range' => [
                'px' => [
                    'min' => 0,
                    'max' => 20,
                ],
            ],
            'devices' => [ 'desktop', 'tablet', 'mobile' ],
            'unit' => 'px',
            'selectors' => [
                '{{WRAPPER}} .contact-cta-box p' => 'font-size: {{SIZE}}{{UNIT}}',
            ],
        ]
    );
    $this-> end_controls_section(); 
}
    // Register control section end here

    protected function render() {
        $settings = $this->get_settings_for_display(); 
        
        //  Button Link
        $btn_link = '';
        if($settings['link_type'] == 1){
            $btn_link = get_page_link($settings['link_to_page']); 
        } else {
            $btn_link = $settings['external_link'];
        } ?>
        <!-- Start FunFacts Area -->
        <div class="fun-facts-area ptb-110">

            <div class="container">
                <div class="section-title">
                    <?php echo wp_kses_post($settings['title']); ?>
                    <?php echo wp_kses_post($settings['desc']); ?>
                </div>

                <div class="row">
                    <?php if ( $settings['funfacts_list']!='' ){
                        foreach ( $settings['funfacts_list'] as $item ) {
                            if($item['count_num']!='' || $item['funfacts_title']!='') { ?>
                                <div class="col-lg-3 col-md-3 col-6 col-sm-3">
                                    <div class="single-funfacts">
                                        <h3><span class="odometer" data-count="<?php echo esc_attr($item['count_num']); ?>"><?php echo esc_html__('00','albion-toolkit'); ?></span><span><?php echo esc_html($item['symbol']); ?></span></h3>
                                        <p><?php echo esc_html($item['funfacts_title']); ?></p>
                                    </div>
                                </div> <?php
                            }
                        }
                    } ?>
                </div>

                <div class="contact-cta-box">

                    <?php echo wp_kses_post($settings['contact_cta']); ?>
                    <?php echo wp_kses_post($settings['contact_cta_note']); ?>

                    <?php
                        if($settings['contact_cta_btn'] !=''){ ?>
                            <a href="<?php echo esc_url($btn_link); ?>" class="btn btn-primary"><?php echo esc_html( $settings['contact_cta_btn']); ?><span></span></a> 
                        <?php 
                    } ?>

                </div>
            </div>

            <?php if ( 'yes' === $settings['section_shape'] ) { ?>
                <div class="shape-map1">
                    <img src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/map.png' ); ?>" alt="<?php echo esc_attr__( 'Shape', 'albion-toolkit' ); ?>">
                </div>
                <div class="shape-img3">
                    <img src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/shape/3.png' ); ?>" alt="<?php echo esc_attr__( 'Shape', 'albion-toolkit' ); ?>">
                </div>
                <div class="shape-img2">
                    <img src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/shape/2.svg' ); ?>" alt="<?php echo esc_attr__( 'Shape', 'albion-toolkit' ); ?>">
                </div>
                <div class="shape-img5">
                    <img src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/shape/5.svg' ); ?>" alt="<?php echo esc_attr__( 'Shape', 'albion-toolkit' ); ?>">
                </div>
                <div class="shape-img4">
                    <img src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/shape/4.svg' ); ?>" alt="<?php echo esc_attr__( 'Shape', 'albion-toolkit' ); ?>">
                </div>
                <div class="dot-shape1">
                    <img src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/shape/dot1.png' ); ?>" alt="<?php echo esc_attr__( 'Shape', 'albion-toolkit' ); ?>">
                </div>
                <div class="dot-shape2">
                    <img src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/shape/dot3.png' ); ?>" alt="<?php echo esc_attr__( 'Shape', 'albion-toolkit' ); ?>">
                </div>
                <?php
            } ?>
        </div>
        <!-- End FunFacts Area -->
    <?php    
    }
    protected function _content_template() {}
}
Plugin::instance()->widgets_manager->register_widget_type( new FunfactsWidget );