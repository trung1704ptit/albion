<?php
namespace Elementor;
class AboutWidget extends Widget_Base{
    public function get_name(){
        return "about-widget";
    }
    public function get_title(){
        return "About Section";
    }
    public function get_icon(){
        return "eicon-info-box";
    }
    public function get_categories(){
        return ['albioncategory'];
    }

    protected function _register_controls(){
        // Tab content controls
        $this-> start_controls_section(
            'section_content',
            [
                'label'=>esc_html__('Content', 'albion-toolkit'),
                'tab'=> Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'choose_type',
            [
                'label' => esc_html__( 'Choose Style', 'albion-toolkit' ),
                'type' => Controls_Manager::SELECT,
                'label_block' => true,
                'options' => [
                    '1'  => esc_html__( 'Style 1', 'albion-toolkit' ),
                    '2' => esc_html__( 'Style 2', 'albion-toolkit' ),
                    '3' => esc_html__( 'Style 3', 'albion-toolkit' ),
                ], 
            ]
        );

        $this->add_control(
            'left_image_one',
            [
                'label' => esc_html__('Left Image', 'albion-toolkit' ),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Image_Size::get_type(),
            [
                'default' =>esc_html__('full','albion-toolkit'),
                'name' => 'image_onesz'
            ]
        );

        $this->add_control(
            'left_image_two',
            [
                'label' => esc_html__('Left Image Two', 'albion-toolkit' ),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'condition' => [
                    'choose_type!' => '3',
                ]
            ]
        );
        
        $this->add_group_control(
            Group_Control_Image_Size::get_type(),
            [
                'default' =>esc_html__('full','albion-toolkit'),
                'name' => 'image_twosz',
                'condition' => [
                    'choose_type!' => '3',
                ]
            ]
        );

        $this->add_control(
            'about_title',
            [
                'label'=>esc_html__('Title', 'albion-toolkit'),
                'type'=>Controls_Manager:: WYSIWYG,
                'description' => esc_html__('This text editor for h1 to h6 html tag','albion-toolkit'),
            ]
        );

        $this->add_control(
            'about_desc',
            [
                'label'=>esc_html__('Description', 'albion-toolkit'),
                'type'=>Controls_Manager:: WYSIWYG,
                'description' => esc_html__('This text editor for p, ul - ol list tag','albion-toolkit'),
            ]
        );

        $this->add_control(
			'about_btn',
			[
				'label' => esc_html__( 'Show Discover Button?', 'albion-toolkit' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'albion-toolkit' ),
				'label_off' => esc_html__( 'Hide', 'albion-toolkit' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
        );

        $this->add_control(
            'btn_text',
            [
                'label'=>esc_html__('Button Title', 'albion-toolkit'),
                'type'=>Controls_Manager:: TEXT,
                'condition' => [
                    'about_btn' => 'yes',
                ]
            ]
        );

        $this->add_control(
            'link_type',
            [
                'label' => esc_html__( 'Link Type', 'albion-toolkit' ),
                'type' => Controls_Manager::SELECT,
                'label_block' => true,
                'options' => [
                    '1'  => esc_html__( 'Link To Page', 'albion-toolkit' ),
                    '2' => esc_html__( 'External Link', 'albion-toolkit' ),
                ], 
                'condition' => [
                    'about_btn' => 'yes',
                ]
            ]
        );

        $this->add_control(
            'link_to_page',
            [
                'label' => esc_html__( 'Link Page', 'albion-toolkit' ),
                'type' => Controls_Manager::SELECT,
                'label_block' => true,
                'options' => albion_toolkit_get_page_as_list(),
                'condition' => [
                    'link_type' => '1',
                    'about_btn' => 'yes',
                ]
            ]
        );

        $this->add_control(
            'external_link',
            [
                'label'=>esc_html__('External Link', 'albion-toolkit'),
                'type'=>Controls_Manager:: TEXT,
                'condition' => [
                    'link_type' => '2',
                    'about_btn' => 'yes',
                ]
            ]
        );

        $this->add_control(
			'about_shape',
			[
				'label' => esc_html__( 'Show Shapes', 'albion-toolkit' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'albion-toolkit' ),
				'label_off' => esc_html__( 'Hide', 'albion-toolkit' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
        );

        $this->add_control(
            'about_card_content',
            [
                'label' => esc_html__( 'About Card', 'albion-toolkit' ),
                'type' => Controls_Manager::HEADING,
                'condition' => [
                    'choose_type' => '2',
                ]
            ]
        );

        $repeater = new Repeater();

        $repeater->add_control(
            'card_title', [
                'label' => esc_html__( 'Card Title', 'albion-toolkit' ),
                'type' => Controls_Manager::WYSIWYG,
                'label_block' => true,
                'description' => esc_html__('This text editor for h1 to h6 html tag','albion-toolkit'),
            ]
        );
    
        $repeater->add_control(
            'card_details', [
                'label' => esc_html__( 'Card Details', 'albion-toolkit' ),
                'type' => Controls_Manager::WYSIWYG,
                'label_block' => true,
                'description' => esc_html__('This text editor for p, ul - ol list tag','albion-toolkit'),
            ]
        );
        $this->add_control(
            'card_content',
            [
                'label' => esc_html__( 'Add Card Content', 'albion-toolkit' ),
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'condition' => [
                    'choose_type' => '2',
                ]
            ]
        );

        // About Style
        $this->add_control(
            'list_content',
            [
                'label' => esc_html__( 'About Feature Lists', 'albion-toolkit' ),
                'type' => Controls_Manager::HEADING,
                'condition' => [
                    'choose_type' => '3',
                ]
            ]
        );

        $repeater2 = new Repeater();

        $repeater2->add_control(
            'list_title', [
                'label' => esc_html__( 'Lists Title', 'albion-toolkit' ),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
            ]
        );
    
        $this->add_control(
            'feature_lists',
            [
                'label' => esc_html__( 'Add Feature List', 'albion-toolkit' ),
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater2->get_controls(),
                'condition' => [
                    'choose_type' => '3',
                ]
            ]
        );
        $this-> end_controls_section();

        // End Tab content controls

        // Start Style content controls
        $this-> start_controls_section(
            'content_style',
            [
                'label'=>esc_html__('Content', 'albion-toolkit'),
                'tab'=> Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
			'title_style',
			[
				'label' => esc_html__( 'Title', 'albion-toolkit' ),
				'type' => Controls_Manager::HEADING,
			]
        );

        $this->add_control(
            'title_color',
            [
                'label' => esc_html__( 'Color', 'albion-toolkit' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .about-content h2' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_responsive_control(
			'title_font_size',
			[
				'label' => esc_html__( 'Font Size', 'albion-toolkit' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 60,
					],
                ],
                'devices' => [ 'desktop', 'tablet', 'mobile' ],
                'unit' => 'px',
				'selectors' => [
					'{{WRAPPER}} .about-content h2' => 'font-size: {{SIZE}}{{UNIT}}',
                ],
			]
        );

        $this->add_control(
			'description_style',
			[
				'label' => esc_html__( 'Description', 'albion-toolkit' ),
				'type' => Controls_Manager::HEADING,
			]
        );

        $this->add_control(
            'desc_color',
            [
                'label' => esc_html__( 'Color', 'albion-toolkit' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .about-content p' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_responsive_control(
			'desc_font_size',
			[
				'label' => esc_html__( 'Font Size', 'albion-toolkit' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 60,
					],
                ],
                'devices' => [ 'desktop', 'tablet', 'mobile' ],
                'unit' => 'px',
				'selectors' => [
					'{{WRAPPER}} .about-content p' => 'font-size: {{SIZE}}{{UNIT}}',
                ],
			]
        );

        $this->add_control(
			'feature_list_style',
			[
				'label' => esc_html__( 'Feature Lists', 'albion-toolkit' ),
                'type' => Controls_Manager::HEADING,
                'condition' => [
                    'choose_type' => '3',
                ]
			]
        );

        $this->add_control(
            'feature_list_color',
            [
                'label' => esc_html__( 'Color', 'albion-toolkit' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .about-content .features-list li span' => 'color: {{VALUE}}',
                ],
                'condition' => [
                    'choose_type' => '3',
                ]
            ]
        );

        $this->add_responsive_control(
			'feature_list_font_size',
			[
				'label' => esc_html__( 'Font Size', 'albion-toolkit' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 25,
					],
                ],
                'devices' => [ 'desktop', 'tablet', 'mobile' ],
                'unit' => 'px',
				'selectors' => [
					'{{WRAPPER}} .about-content .features-list li span' => 'font-size: {{SIZE}}{{UNIT}}',
                ],
                'condition' => [
                    'choose_type' => '3',
                ]
			]
        );

        // Button Style //
        $this->add_control(
			'button_style',
			[
				'label' => esc_html__( 'Discover Button', 'albion-toolkit' ),
                'type' => Controls_Manager::HEADING,
                'condition' => [
                    'about_btn' => 'yes',
                ]
			]
        );
        $this->start_controls_tabs( 'button_effects',
            [
                'condition' => [
                    'about_btn' => 'yes',
                ]
            ]
        );

        $this->start_controls_tab( 'normal',
			[
				'label' => esc_html__( 'Normal', 'albion-toolkit' ),
			]
        );

        $this->add_control(
            'btn_color',
            [
                'label' => esc_html__( 'Color', 'albion-toolkit' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .btn-primary' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'btn_bgcolor',
            [
                'label' => esc_html__( 'Background Color', 'albion-toolkit' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .btn-primary' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab( 'hover',
            [
                'label' => esc_html__( 'Hover', 'albion-toolkit' ),
            ]
        );

        $this->add_control(
            'btn_hcolor',
            [
                'label' => esc_html__( 'Color', 'albion-toolkit' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}}  .btn-primary:hover, .btn-primary:focus' => 'color: {{VALUE}} !important',
                ],
            ]
        );

        $this->add_control(
            'btn_hbgcolor',
            [
                'label' => esc_html__( 'Background Color', 'albion-toolkit' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}}  .btn-primary:hover, .btn-primary:focus' => 'background-color: {{VALUE}} !important',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->end_controls_tabs();
        // End Button Style //

        $this->add_control(
			'card_style',
			[
				'label' => esc_html__( 'About Card Style', 'albion-toolkit' ),
                'type' => Controls_Manager::HEADING,
                'condition' => [
                    'choose_type' => '2',
                ]
			]
        );
        $this->add_control(
            'card_title_color',
            [
                'label' => esc_html__( 'Title Color', 'albion-toolkit' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .about-text h3' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_responsive_control(
			'card_titlefont_size',
			[
				'label' => esc_html__( 'Title Font Size', 'albion-toolkit' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 40,
					],
                ],
                'devices' => [ 'desktop', 'tablet', 'mobile' ],
                'unit' => 'px',
				'selectors' => [
					'{{WRAPPER}} .about-text h3' => 'font-size: {{SIZE}}{{UNIT}}',
                ],
			]
        );

        $this->add_control(
            'card_desc_color',
            [
                'label' => esc_html__( 'Description Color', 'albion-toolkit' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .about-text p' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_responsive_control(
			'card_descfont_size',
			[
				'label' => esc_html__( 'Description Font Size', 'albion-toolkit' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 20,
					],
                ],
                'devices' => [ 'desktop', 'tablet', 'mobile' ],
                'unit' => 'px',
				'selectors' => [
					'{{WRAPPER}} .about-text p' => 'font-size: {{SIZE}}{{UNIT}}',
                ],
			]
        );

        $this-> end_controls_section();
    }
    // Register control section end here

    protected function render()
    {
        // Retrieve all controls value
        $settings = $this->get_settings_for_display();

        // Discover Button link
        $link_source = '';
        if($settings['link_type'] == 1){
            $link_source = get_page_link($settings['link_to_page']); 
        } else {
            $link_source = $settings['external_link'];
        } ?>

        <!-- Start About Area -->
        <?php if( $settings['choose_type'] == 1 || $settings['choose_type'] == 2 ) { ?>
            <div class="about-area ptb-110">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-lg-6 col-md-12">
                            <div class="about-image">
                                <?php echo Group_Control_Image_Size::get_attachment_image_html($settings,'image_onesz','left_image_one'); ?>
                                <?php echo Group_Control_Image_Size::get_attachment_image_html($settings,'image_twosz','left_image_two'); ?>
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-12">
                            <div class="about-content">
                                <?php echo wp_kses_post($settings['about_title']); ?>
                                <?php echo wp_kses_post( $settings['about_desc']); ?>

                                <?php 
                                if ( 'yes' === $settings['about_btn'] ) { 
                                    if($settings['btn_text'] !='') { ?>
                                    <a href="<?php echo esc_url($link_source); ?>" class="btn btn-primary"><?php echo esc_html($settings['btn_text']); ?></a>
                                <?php } 
                                } ?>
                            </div>
                        </div>
                    </div>

                    <!-- style two -->
                    <?php
                    if($settings['choose_type'] == 2) { ?>
                        <div class="about-inner-area">
                            <div class="row"> <?php

                            if ( $settings['card_content']!='' ){
                                $loop = 1;
                                foreach ( $settings['card_content'] as $item ) {
                                    if ($loop == 3) {
                                        $colcls = 'col-lg-4 col-md-6 col-sm-6 offset-lg-0 offset-md-3 offset-sm-3';
                                    }else {
                                        $colcls = 'col-lg-4 col-md-6 col-sm-6';
                                    }

                                    if($item['card_title']!='' || $item['card_details']!='') { ?>
                                    <div class="<?php echo esc_attr( $colcls ); ?>">
                                        <div class="about-text">
                                            <?php echo wp_kses_post($item['card_title']); ?>
                                            <?php echo wp_kses_post($item['card_details']); ?>
                                        </div>
                                    </div><?php
                                    } 
                                $loop++; 
                                } 
                            } ?>
                            
                            </div>
                        </div><?php
                    } ?>

                </div>

                <?php 
                if ( 'yes' === $settings['about_shape'] ) { ?>
                <div class="shape-img1">
                    <img src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/shape/1.png' ); ?>" alt="<?php echo esc_attr__( 'About Shape', 'albion-toolkit' ); ?>">
                </div>
                <div class="shape-img2">
                    <img src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/shape/2.svg' ); ?>" alt="<?php echo esc_attr__( 'About Shape', 'albion-toolkit' ); ?>">
                </div>
                <div class="shape-img3">
                    <img src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/shape/3.png' ); ?>" alt="<?php echo esc_attr__( 'About Shape', 'albion-toolkit' ); ?>">
                </div>
                <div class="shape-img4">
                    <img src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/shape/4.svg' ); ?>" alt="<?php echo esc_attr__( 'About Shape', 'albion-toolkit' ); ?>">
                </div>
                <div class="shape-img5">
                    <img src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/shape/5.svg' ); ?>" alt="<?php echo esc_attr__( 'About Shape', 'albion-toolkit' ); ?>">
                </div>
                <div class="shape-img6">
                    <img src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/shape/6.png' ); ?>" alt="<?php echo esc_attr__( 'About Shape', 'albion-toolkit' ); ?>">
                </div>
                <div class="dot-shape1">
                    <img src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/shape/dot1.png' ); ?>" alt="<?php echo esc_attr__( 'About Shape', 'albion-toolkit' ); ?>">
                </div>
                <div class="dot-shape2">
                    <img src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/shape/dot3.png' ); ?>" alt="<?php echo esc_attr__( 'About Shape', 'albion-toolkit' ); ?>">
                </div><?php
                } ?>

            </div> <?php
        } else { ?>
            <div class="about-area pt-0 ptb-110">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-lg-6 col-md-12">
                            <div class="about-img">
                                <?php echo Group_Control_Image_Size::get_attachment_image_html($settings,'image_onesz','left_image_one'); ?>
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-12">
                            <div class="about-content">
                                <?php echo wp_kses_post($settings['about_title']); ?>
                                <?php echo wp_kses_post( $settings['about_desc']); ?>

                                <ul class="features-list">
                                    <?php if ( $settings['feature_lists']!='' ){
                                        foreach ( $settings['feature_lists'] as $list ) {
                                            if( $list['list_title']!='' ) { ?>
                                                <li><span><i class="flaticon-tick"></i> <?php echo esc_html($list['list_title']); ?></span></li>
                                                <?php
                                            } 
                                        } 
                                    } ?>
                                </ul>

                                <?php if ( 'yes' === $settings['about_btn'] ) { 
                                    if($settings['btn_text'] !='') { ?>
                                        <a href="<?php echo esc_url($link_source); ?>" class="btn btn-primary"><?php echo esc_html( $settings['btn_text'] ); ?></a>
                                <?php } 
                                } ?>
                            </div>
                        </div>
                    </div>

                </div>

                <?php 
                if ( 'yes' === $settings['about_shape'] ) { ?>
                    <div class="shape-img1">
                        <img src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/shape/1.png' ); ?>" alt="<?php echo esc_attr__( 'About Shape', 'albion-toolkit' ); ?>">
                    </div>
                    <div class="shape-img3">
                        <img src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/shape/3.png' ); ?>" alt="<?php echo esc_attr__( 'About Shape', 'albion-toolkit' ); ?>">
                    </div>
                    <div class="shape-img4">
                        <img src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/shape/4.svg' ); ?>" alt="<?php echo esc_attr__( 'About Shape', 'albion-toolkit' ); ?>">
                    </div><?php
                } ?>
            </div>
        <?php } ?>
        <!-- End About Area -->
        <?php
    }

    protected function _content_template() {}
}
Plugin::instance()->widgets_manager->register_widget_type( new AboutWidget );